package com.app.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.AuthRequest;
import com.app.dto.SignupRequest;
import com.app.dto.addNewCustomerDto;
import com.app.entities.Customer;
import com.app.service.CustomerService;

@RestController
@RequestMapping("/Customer")
@Validated
@CrossOrigin(origins = "*")
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	
//	@Autowired
//	private CustomerService CustService;
// 
	
	@GetMapping
	public ResponseEntity<?> allCustomers() {
		System.out.println("find all Users" );
		
		return ResponseEntity.status(HttpStatus.FOUND).body(customerService.getAllCustomer());
	}
	
	@PostMapping
	public ResponseEntity<?> addNewCustomer(@RequestBody @Valid addNewCustomerDto dto) {
		System.out.println("add new Customer " + dto);
		return ResponseEntity.status(HttpStatus.CREATED).body(customerService.addNewCustomer(dto));
	}
	
	
	@GetMapping(value="/{CustomerId}")
	public ResponseEntity<?> finById(@PathVariable Long CustomerId ) {
	//public ResponseEntity<?> findUserById( Long Id ) {
		System.out.println("find user having id--" + CustomerId);
		
		return ResponseEntity.status(HttpStatus.OK).body(customerService.getCustomer(CustomerId));
	}
	
	
	@GetMapping(value="/customerDashBoard/{CustomerId}")
	public ResponseEntity<?> CustomerDashboard(@PathVariable Long CustomerId ) {
	//public ResponseEntity<?> findUserById( Long Id ) {
		System.out.println("find user having id--" + CustomerId);
		
		return ResponseEntity.status(HttpStatus.OK).body(customerService.customerdashboardView(CustomerId));
	}
	
//	@PostMapping("/signIn")
//	public ResponseEntity<?> authenticate(@RequestBody @Valid AuthRequest request) {
//		System.out.println("in sign in " + request);
//
//		return new ResponseEntity<>(TechnicianService.authenticateTechnician(request), HttpStatus.OK);
//
//	}
	
	@PostMapping("/signIn")
	public ResponseEntity<?> authenticateCust(@RequestBody @Valid AuthRequest request) {
		System.out.println("in sign in " + request);

		return new ResponseEntity<>(customerService.authenticateCust(request), HttpStatus.OK);

	}

	// add a method to hire / signup new Customer
	// Req : http://host:port/Customers/signup method=POST
	// req payload : all Cust details except id
	// resp : resp dto all Cust dtls except password
	@PostMapping("/signup")
	public ResponseEntity<?> hireCustomer(@RequestBody @Valid Customer request) {
		System.out.println("in hire Cust " + request);
		// invoke service layer
		return ResponseEntity.status(HttpStatus.CREATED).body(customerService.signupCust(request));
	}
	
	@PutMapping
	public Customer updateCustDetails(@RequestBody Customer detachedCust) {
		System.out.println("in update Cust " + detachedCust.getCustomerId());// not null
		// validate
		customerService.getCustDetails(detachedCust.getCustomerId());
		// => Cust exists by the id --> continue to update
		return customerService.addCustDetails(detachedCust);
	}
	
	
	
	
}
