package com.app.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.entities.Inventory;
import com.app.service.InventoryService;


@RestController // mandatory class level anno , consists of =@Controller : cls level
				// +@ResponseBody : ret type of req handling
				// methods(@RequestMapping/@GetMapping...)
@RequestMapping("/inventory")
@CrossOrigin(origins = "*")
public class InventoryController {
	// dep : service layer i.f

	@Autowired
	private InventoryService inventoryService;

	public InventoryController() {
		System.out.println("in ctor of " + getClass());
	}

	// add a method : REST API end point , to get all orderss
	// Req : http://host:port/Orderss , method ; GET
	//ADMIN
	@GetMapping
	public List<Inventory> listAllItems() {
		return inventoryService.getAllItems();
	}

	// add a method : REST API end point , to add new orders details
	// Req : http://host:port/Orderss , method ; POST
	//BACKUP----TO ADD ORDER TO A CUSTOMER  
	@PostMapping("/addItem")
	public boolean saveItemDetails(@RequestBody Inventory item)
	// @RequestBody : mandatory method arg level annotation for de-ser / un
	// marshalling
	// => json ---> java
	{
		Inventory i=inventoryService.addItem(item);
		System.out.println("item is added successfully  " + i.getInventoryId() );// id : null (transient)
		return true;
	}

//	// add a method : REST API end point , to delete orders details
//	// Req : http://host:port/Orderss/ordersId , method : DELETE
//	@DeleteMapping("/{ordersId}")
//	// @PathVariable : method arg level anno , for binding URI torderslate var to req
//	// handling method arg.
//	public ApiResponse deleteordersDetails(@PathVariable Long ordersId) {
//		System.out.println("in del orders " + ordersId);
//		return ordersService.deleteOrderDetails(ordersId);
//	}
//
//	// add a method : REST API end point , to get orders details by id
//	// Req : http://host:port/Orderss/ordersId , method : GET
//	@GetMapping("/{id}")
//	public Orders getordersDetailsById(@PathVariable Long id) {
//		System.out.println("in get orders dtls " + id);
//		return ordersService.getOrderDetails(id);
//	}
//	// add a method : REST API end point , to get orders details by id
//	// Req : http://host:port/Orderss/ordersId , method : GET
//
//	@PutMapping
//	public Orders updateOrdersDetails(@RequestBody Orders detachedorders) {
//		System.out.println("in update orders " + detachedorders.getId());// not null
//		// validate
//		ordersService.getOrderDetails(detachedorders.getId());
//		// => orders exists by the id --> continue to update
//		return ordersService.addOrderDetails(detachedorders);
//	}
//
////	@PostMapping("/createorder/{CustId}")
////	public Orders CreateOrder(@RequestBody List<ServiceCatalogue> servicelist,@PathVariable Long CustId)
////	// @RequestBody : mandatory method arg level annotation for de-ser / un
////	// marshalling
////	// => json ---> java
////	{
////		
////	//	orders.setSelectedCustomer(customerservice.getCustDetails(CustId));
////        	return	ordersService.CreateOrder(servicelist, CustId);
////		//System.out.println("in save orders " + orders.getId());// id : null (transient)
//////		return ordersService.addOrderDetails(orders);
////	}
//	
//	
//	@PostMapping("/addorder")
//    public String createOrder(@RequestBody List<Long> serviceIdList) {
//        List<Long> services= serviceIdList;
//      
//        List<ServiceTable> products = sts.getAllServices(services);
//
//        Orders order = new Orders();
//        
//        ///demo date
//         String orderBookingdateString = "2023-08-17"; // Replace this with your date string
//         String servicingBookingdateString = "2023-08-18";
//        // Define the desired date format
//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//        
//        // Parse the string into a LocalDate
//        LocalDate localDate = LocalDate.parse(orderBookingdateString, formatter);
//        LocalDate localDate1 = LocalDate.parse(servicingBookingdateString, formatter);
//        
//        
//        order.setOrderBookingDate(localDate);
//        order.setServicingDate(localDate1);
//        
//        order.setServiceCatalogueList(products);
//        
//       order.setSelectedCustomer(customerservice.getCustDetails(2L));
//
//        ordersService.createNewOrder(order);
//        return "Order created successfully";
//    }
//}
//	
//	
////	 @PostMapping("/orders/{CustId}")
////	 public ResponseEntity<?> CreateNewOrderWithServices(@RequestBody List<Long> servicelist,@PathVariable Long CustId) {
////			//System.out.println("in hire Cust " + );
////			// invoke service layer
////			return ResponseEntity.status(HttpStatus.CREATED).body(ordersService.AddNewOrder(servicelist, CustId));
////		}
////	
//	// add a method : REST API end point , to orders signin
//	// Req : http://host:port/Orderss/signin method=POST
//	// req payload : req dto
//	// resp : resp dto
////	@PostMapping("/signIn")
////	public ResponseEntity<?> authenticateorders(@RequestBody @Valid AuthRequest request) {
////		System.out.println("in sign in " + request);
////
////		return new ResponseEntity<>(ordersService.authenticateorders(request), HttpStatus.OK);
////
////	}
//
//	// add a method to hire / signup new Orders
//	// Req : http://host:port/Orderss/signup method=POST
//	// req payload : all orders details except id
//	// resp : resp dto all orders dtls except password
////	@PostMapping("/signup")
////	public ResponseEntity<?> hireOrders(@RequestBody @Valid SignupRequest request) {
////		System.out.println("in hire orders " + request);
////		// invoke service layer
////		return ResponseEntity.status(HttpStatus.CREATED).body(ordersService.signuporders(request));
////	}
//
//	// add a method list all orders names drawing sal > min sal
//	// Req : http://host:port/Orderss/salary/{minSal} , method=GET
//	
//	
//	
////	@GetMapping("/salary/{minSal}")
////	public ResponseEntity<?> listordersNamesBySalary(@PathVariable double minSal) {
////		System.out.println("in list orders names " + minSal);
////		return ResponseEntity.ok(ordersService.getordersNamesBySalarySanket(minSal));
////	}
//
}
