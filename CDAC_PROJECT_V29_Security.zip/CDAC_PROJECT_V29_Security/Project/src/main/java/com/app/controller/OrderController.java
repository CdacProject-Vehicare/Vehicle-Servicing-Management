package com.app.controller;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.criteria.Order;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dto.CountDto;
import com.app.dto.OrdersDto;
import com.app.dto.VehicleDetailsResponseDTO;
import com.app.entities.Customer;
import com.app.entities.Orders;
import com.app.entities.Vehicle;
import com.app.entities.VehicleTypeEnum;
import com.app.respository.CustomerRepo;
import com.app.respository.OrderRepo;
import com.app.respository.VehicleRepo;
import com.app.service.OrderService;
import com.app.service.VehicleService;

@RestController
@RequestMapping("/ordercontroller")
@Validated
@CrossOrigin(origins = "*")
public class OrderController {
		
	@Autowired
	private OrderService ser;
	
	@Autowired
	private OrderRepo repo;
	
	@Autowired
	private VehicleRepo vRepo;
	
	@Autowired
	private CustomerRepo custRepo;
	
	@Autowired
	private VehicleService vehicleservice;
	@Autowired 
	private ModelMapper mapper;
	
	@PostMapping
	public void insertOrder(@RequestBody OrdersDto dto)
	{	
		System.out.println("in insert order");
		//Customer c=custRepo.findByUserId(dto.getCustomerId());
		
		Customer c=custRepo.findByCustomerId(dto.getCustomerId());
		//System.out.println(customer.getUser());
		Orders o=mapper.map(dto, Orders.class);
	
		o.setCustomer(c);
		o.setOdate(LocalDate.now());
		Orders o1=ser.addOrder(o);
//		Vehicle v1=new Vehicle();
//		v1.setVehicleMfg(dto.getVehicleMfg());
//		v1.setVehicleName(dto.getVehicleName());
//		v1.setVehicleNo(dto.getVehicleNo());
//		v1.setVehicleType(VehicleTypeEnum.THREEWHEELER);
//		vehicleservice.insertVehicle(o1.getOrderId(),v1);
//		
	}
	
	@PostMapping("/insertVehicleToOrder/{orderId}")
	public Vehicle insertVehicleToOrder(@RequestBody OrdersDto dto,@PathVariable Long orderId)
	{
		//Orders o1=repo.findById(orderId).orElseThrow();
		Vehicle v1=new Vehicle();
		v1.setVehicleMfg(dto.getVehicleMfg());
		v1.setVehicleName(dto.getVehicleName());
		v1.setVehicleNo(dto.getVehicleNo());
		v1.setVehicleType(VehicleTypeEnum.FOURWHEELER);
		vehicleservice.insertVehicle(orderId,v1);
	     return v1;
	}

	
	@GetMapping("/getVehicleDetails/{orderId}")
	public VehicleDetailsResponseDTO getVehicleDetailsOfOrders(@PathVariable Long orderId)
	{
		
		  Vehicle v1= vRepo.findById(orderId).orElseThrow();
		VehicleDetailsResponseDTO vdr=new VehicleDetailsResponseDTO();
		vdr.setVehicleId(v1.getVehicleId());
		vdr.setVehicleMfg(v1.getVehicleMfg());
		vdr.setVehicleName(v1.getVehicleName());
		vdr.setVehicleNo(v1.getVehicleNo());
	    vdr.setVehicleType("FOURWHEELER");
		
		return vdr;
	}
	
	
	
	@GetMapping()
	public List<Orders> getAllOrders()
	{
		return repo.findAll();
	}
	
	@GetMapping("/orderstatistics")
	public CountDto getAllOrdersStatistics()
	{
		return ser.OrderStatistics();
	}
	
	
	
	@GetMapping("/{orderId}")
	public Orders searchOrders(@PathVariable Long orderId)
	{
		return repo.findByOrderId(orderId);
	}
	
	
	@PutMapping("/updateOrderStatus/{orderId}/{status}")
	public Orders UpdateOrders(@PathVariable String status,@PathVariable Long orderId)
	{
		
		return ser.UpdateOrderStatus(orderId, status);
	}
	
	@PutMapping("/updateOrderPaymentStatus/{orderId}/{status}")
	public Orders UpdateOrdersPayment(@PathVariable String status,@PathVariable Long orderId)
	{
		
		return ser.UpdateOrderPaymentStatus(orderId, status);
	}
}
