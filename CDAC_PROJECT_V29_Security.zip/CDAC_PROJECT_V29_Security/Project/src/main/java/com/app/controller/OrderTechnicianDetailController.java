package com.app.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dto.OrderDetailsDto;
import com.app.dto.OrderTechnicianDetailsDto;
import com.app.dto.UpdateWorkLogDTO;
import com.app.entities.OrderDetails;
import com.app.entities.Orders;
import com.app.entities.Product;
import com.app.respository.OrderDetailRepo;
import com.app.respository.OrderRepo;
import com.app.respository.ProductRepo;
import com.app.service.OrderDetailsService;
import com.app.service.OrderService;
import com.app.service.OrderTechnicianDetailsService;

@RestController
@RequestMapping("/orderTechnicianDetailscontroller")
@Validated
@CrossOrigin(origins = "*")
public class OrderTechnicianDetailController {
	@Autowired
	private OrderTechnicianDetailsService orderTechnicianDetailService;
	
	
	@PostMapping
	public ResponseEntity<?> addOrderDetail(@RequestBody OrderTechnicianDetailsDto dto) {
	
		return ResponseEntity.status(HttpStatus.CREATED).body(orderTechnicianDetailService.addTechnicianToOrder(dto));
	}
	
	@GetMapping("/{orderId}")
	public ResponseEntity<?> getOrderDetailByOrderId(@PathVariable Long orderId) {
	
		return ResponseEntity.status(HttpStatus.CREATED).body(orderTechnicianDetailService.getOrderTechnicianDetailsByOrderId(orderId));
	}
	
	
	@GetMapping
	public ResponseEntity<?> getOrderDetails() {
	
		return ResponseEntity.status(HttpStatus.CREATED).body(orderTechnicianDetailService.getAllOrderTechnicianDetails());
	}
	
	@GetMapping("/technician/{technicianId}")
	public ResponseEntity<?> getTechnicianDashBoardOrderDetails(@PathVariable Long technicianId) {
	
		return ResponseEntity.status(HttpStatus.OK).body(orderTechnicianDetailService.getAllOrderTechnicianDetailsForTechnicianDashBoard(technicianId));
	}
	
	
	
	
	@PutMapping("/{orderId}")  
	public ResponseEntity<?> updateWorklogByOrderId(@PathVariable Long orderId,@RequestBody  UpdateWorkLogDTO worklogText) {
		
		return ResponseEntity.status(HttpStatus.CREATED).body(orderTechnicianDetailService.updateWorklog(orderId,worklogText.getText()));
	}
	
	
}
