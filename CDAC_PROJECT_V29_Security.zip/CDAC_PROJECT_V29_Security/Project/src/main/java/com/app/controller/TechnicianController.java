package com.app.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.AdminAllOrdersDto;
import com.app.dto.ApiResponse;
import com.app.dto.AuthRequest;
import com.app.dto.SignupRequest;
import com.app.entities.Technician;
import com.app.service.OrderDetailsService;
import com.app.service.TechnicianService;


@RestController // mandatory class level anno , consists of =@Controller : cls level
				// +@ResponseBody : ret type of req handling
				// methods(@RequestMapping/@GetMapping...)
@RequestMapping("/technician")
@CrossOrigin(origins = "*")
public class TechnicianController {
	// dep : service layer i.f
	@Autowired
	private TechnicianService TechnicianService;
	
	@Autowired
	private OrderDetailsService orderServiceDetails;	
	

	public TechnicianController() {
		System.out.println("in ctor of " + getClass());
	}

	// add a method : REST API end point , to get all Technicians
	// Req : http://host:port/Technicianloyees , method ; GET
	@GetMapping
	public List<Technician> listAllTechnicians() {
		return TechnicianService.getAllTechnicians();
	}
	
	
	@GetMapping("/AllOrderDetailsTechnician/{technicianId}")
	public List<AdminAllOrdersDto> GetAllOrderDetailsTechnician(@PathVariable Long technicianId) {
		return orderServiceDetails.TechnicainDashBoardAllOrderDetails(technicianId);
	}

//	// add a method : REST API end point , to add new Technician details
//	// Req : http://host:port/Technicianloyees , method ; POST
//	@PostMapping()
//	public Technician saveTechnicianDetails(@RequestBody Technician technician)
//	// @RequestBody : mandatory method arg level annotation for de-ser / un
//	// marshalling
//	// => json ---> java
//	{
//		System.out.println("in save technician " + technician.getTechnicianId());// id : null (transient)
//		return TechnicianService.addTechnicianDetails(technician);
//	}

	// add a method : REST API end point , to delete Technician details
	// Req : http://host:port/Technicianloyees/TechnicianId , method : DELETE
	@DeleteMapping("/{TechnicianId}")
	// @PathVariable : method arg level anno , for binding URI tTechnicianlate var to req
	// handling method arg.
	public ApiResponse deleteTechnicianDetails(@PathVariable Long TechnicianId) {
		System.out.println("in del Technician " + TechnicianId);
		return TechnicianService.deleteTechnicianDetails(TechnicianId);
	}

	// add a method : REST API end point , to get Technician details by id
	// Req : http://host:port/Technicianloyees/TechnicianId , method : GET
	@GetMapping("/{id}")
	public Technician getTechnicianDetailsById(@PathVariable Long id) {
		System.out.println("in get Technician dtls " + id);
		return TechnicianService.getTechnicianDetails(id);    //	Technician addTechnicianDetails(Technician Technician);

	}
	
	@GetMapping("/orders/{id}")
	public List<AdminAllOrdersDto> getTechnicianOrderDetailsById(@PathVariable Long id) {
		System.out.println("in get Technician dtls " + id);
		return TechnicianService.getAllOrderDetailsforTechnician(id);    //	Technician addTechnicianDetails(Technician Technician);

	}
	
	
//	@GetMapping("/orders/{id}")
//	public List<AdminAllOrdersDto> getTechnicianDashBorad(@PathVariable Long id) {
//		System.out.println("in get Technician dtls " + id);
//		return TechnicianService.getAllOrderDetailsforTechnician(id);    //	Technician addTechnicianDetails(Technician Technician);
//
//	}
	
	
	// add a method : REST API end point , to get Technician details by id
	// Req : http://host:port/Technicianloyees/TechnicianId , method : GET

	@PutMapping()
	public Technician updateTechnicianDetails(@RequestBody Technician detachedtechnician) {
		System.out.println("in update technician " + detachedtechnician.getTechnicianId());// not null
		// validate
		TechnicianService.getTechnicianDetails(detachedtechnician.getTechnicianId());
		// => Technician exists by the id --> continue to update
		return TechnicianService.addTechnicianDetails(detachedtechnician);
	}

	// add a method : REST API end point , to Technician signin
	// Req : http://host:port/Technicianloyees/signin method=POST
	// req payload : req dto
	// resp : resp dto
	@PostMapping("/signIn")
	public ResponseEntity<?> authenticateTechnician(@RequestBody @Valid AuthRequest request) {
		System.out.println("in sign in " + request);

		return new ResponseEntity<>(TechnicianService.authenticateTechnician(request), HttpStatus.OK);

	}

	
	@PostMapping("/signup")
	public ResponseEntity<?> hireTechnicianloyee(@RequestBody @Valid SignupRequest request) {
		System.out.println("in hire Technician " + request);
		// invoke service layer
		return ResponseEntity.status(HttpStatus.CREATED).body(TechnicianService.signupTechnician2(request));
	}

	// add a method list all Technician names drawing sal > min sal
	// Req : http://host:port/Technicianloyees/salary/{minSal} , method=GET
//	@GetMapping("/salary/{minSal}")
//	public ResponseEntity<?> listTechnicianNamesBySalary(@PathVariable double minSal) {
//		System.out.println("in list Technician names " + minSal);
//		return ResponseEntity.ok(TechnicianService.getTechnicianNamesBySalarySanket(minSal));
//	}

}
