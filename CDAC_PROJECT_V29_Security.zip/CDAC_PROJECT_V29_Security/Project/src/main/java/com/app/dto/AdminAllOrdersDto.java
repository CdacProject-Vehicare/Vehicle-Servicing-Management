package com.app.dto;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString

public class AdminAllOrdersDto {
	//private Long orderDetailsId;

	//@JsonProperty(access = Access.READ_ONLY) //used during serialization
	private Long orderId;
	
	public AdminAllOrdersDto(Long orderId, Long orderDetailsId, String customerFirstname, String customerLastName, Long productId,
			String productName, double price, String status, String paymentstatus) {
		super();
		this.orderId = orderId;
		this.orderDetailsId = orderDetailsId;
		this.customerFirstname = customerFirstname;
		this.customerLastName = customerLastName;
		this.productId=productId;
		this.productName = productName;
		this.price = price;
		//this.technicianAssigned = technicianAssigned;
		this.status = status;
//		this.vehicleNo = vehicleNo;
//		this.vehicleName = vehicleName;
		this.paymentstatus = paymentstatus;
	}
	
	public AdminAllOrdersDto(Long orderId, Long orderDetailsId, String customerFirstname, String customerLastName, Long productId,
			String productName, double price, String status, String vehicleNo,
			String vehicleName, String paymentstatus) {
		super();
		this.orderId = orderId;
		this.orderDetailsId = orderDetailsId;
		this.customerFirstname = customerFirstname;
		this.customerLastName = customerLastName;
		this.productId=productId;
		this.productName = productName;
		this.price = price;
		//this.technicianAssigned = technicianAssigned;
		this.status = status;
		this.vehicleNo = vehicleNo;
		this.vehicleName = vehicleName;
		this.paymentstatus = paymentstatus;
	}

	public AdminAllOrdersDto(Long orderId, Long orderDetailsId) {
		super();
		this.orderId = orderId;
		this.orderDetailsId = orderDetailsId;
	}

	public AdminAllOrdersDto(Long orderId, Long orderDetailsId, String customerFirstname, String customerLastName) {
		super();
		this.orderId = orderId;
		this.orderDetailsId = orderDetailsId;
		this.customerFirstname = customerFirstname;
		this.customerLastName = customerLastName;
	}

	private Long orderDetailsId;
	
	
	private String customerFirstname;
	
	private String customerLastName;
	
	private Long productId;
	
	private String productName;
	
	private double price;
	
	private String technicianAssigned;
	
	private String status;
	
	private String vehicleNo;
	
	private String vehicleName;
	
	private String paymentstatus;
	
	
}
