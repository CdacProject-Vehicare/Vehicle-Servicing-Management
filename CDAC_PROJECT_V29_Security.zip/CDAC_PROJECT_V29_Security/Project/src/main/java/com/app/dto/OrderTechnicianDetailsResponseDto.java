package com.app.dto;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString

public class OrderTechnicianDetailsResponseDto {
	//private Long orderDetailsId;

	//@JsonProperty(access = Access.READ_ONLY) //used during serialization
	private Long orderId;
	
	
	private Long technicianId;
	
	private String technicianName;
	
	private String worklog; 
	
	private LocalDate expectedCompletionDate;
}
