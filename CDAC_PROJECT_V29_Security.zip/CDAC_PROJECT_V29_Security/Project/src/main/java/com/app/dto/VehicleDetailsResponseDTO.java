package com.app.dto;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class VehicleDetailsResponseDTO {
	
	
		  private Long vehicleId;
		  
		  private String vehicleMfg;
		  
		  private String vehicleName;
		  
		  private String VehicleNo;
		  
		  private String vehicleType;
//		  "vehicleMfg": "lambo",
//		  "vehicleName": "g6",		 
//		  "vehicleNo": "mustang",
//		  "vehicleType": "TWOWHEELER"

		
		
}