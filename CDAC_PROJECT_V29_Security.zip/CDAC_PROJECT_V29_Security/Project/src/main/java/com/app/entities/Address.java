package com.app.entities;

import javax.persistence.Embeddable;

@Embeddable
public class Address {
	private Long Address_Id; 
	private Long  user_id;
	private Long plot_no; 
	private String streetName; 
	private String  city;
	private String district;
	private String state ;
	private Long pincode ;
}
