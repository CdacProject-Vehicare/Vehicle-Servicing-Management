package com.app.entities;

public enum Designation {
	  TRAINEE,JUNIOR,SENIOR
}
