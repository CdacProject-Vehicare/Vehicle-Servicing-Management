package com.app.entities;

import java.time.LocalDate;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "feedback") // to specify table name
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString(exclude = "order")
public class Feedback {
	
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "feedback_id")
	private Long feedbackId;
	
	@Column(name = "rating")
	private Double rating;
	@Column(name = "remarks",length = 200)
	private String remarks;
	@Column(name = "feedback_date")
	private LocalDate feedbackDate;
	
	// uni dir association Address 1--->1 Employee
	@OneToOne
	@JoinColumn(name = "order_id")
	@MapsId // to tell hibernate to use a shared PK between emps n adr table + add FK
			// constraint
	private Orders order;

	


}
