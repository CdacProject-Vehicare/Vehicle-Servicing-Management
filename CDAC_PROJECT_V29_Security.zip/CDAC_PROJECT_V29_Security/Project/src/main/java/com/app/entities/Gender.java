package com.app.entities;

public enum Gender {
M,F,O
}
