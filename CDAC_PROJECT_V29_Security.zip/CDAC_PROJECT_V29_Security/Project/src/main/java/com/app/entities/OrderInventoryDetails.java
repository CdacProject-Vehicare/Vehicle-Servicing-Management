package com.app.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity 
@Table(name = "Orders_Inventory_details") 
@NoArgsConstructor
@Getter
@Setter
//@ToString(exclude= {"product","orders"})

public class OrderInventoryDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "odi_id")
	private Long odinventoryId;
	
	@ManyToOne
	@JoinColumn(name="od_id")
	private OrderDetails orderdetails;
	
	@ManyToOne
	@JoinColumn(name="invntory_id")
	private Inventory inventory;
		
	private int quantityUsed;
	
	
}
