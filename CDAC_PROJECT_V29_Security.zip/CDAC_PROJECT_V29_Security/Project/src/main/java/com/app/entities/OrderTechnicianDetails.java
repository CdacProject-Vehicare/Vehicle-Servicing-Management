package com.app.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity 
@Table(name = "Orders_Technician_details") 
@NoArgsConstructor
@Getter
@Setter
@ToString(exclude= {"technician","orders"})

public class OrderTechnicianDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "od_id")
	private Long odId;
	
	@ManyToOne
	@JoinColumn(name="o_id")
	private Orders orders;
	
	@ManyToOne
	@JoinColumn(name="technician_id")
	private Technician technician;
	
	
	private String Worklog;
	//add worklog column to track worklog of technicians.......................
		
//	private Long quantity;
//	
//	private Long amount;
}
