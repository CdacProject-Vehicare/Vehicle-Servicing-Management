package com.app.entities;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.persistence.CascadeType;
//all specs Java EE supplied
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Entity
@Table(name = "technician") // to specify table name
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString(exclude = "password")
public class Technician {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="technician_id")
	private Long technicianId;
	
	@Column(length = 20) // varchar(20)
	private String firstName;
	@Column( length = 20)
	private String lastName;
	@Column(length = 30, unique = true) // unique constraint
	private String email;
	@Column(length = 20, nullable = false) // NOT NULL constraint
	//@JsonProperty(access = Access.WRITE_ONLY)//property will be used for de-ser ONLY
	private String password;		
	private LocalDate joinDate;
	private double salary;
	@Column(length = 30)
	private String location;
	@Column(length = 30)
	private String department;
	
	@Enumerated(EnumType.STRING)
	@Column(length = 20)
	//@NotNull(message = "designation must be supplied!!!!")
	private Designation designation;
	
	
	private String role;
	
	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name= "user_id")
	private User user;
	
//	@OneToOne
//	@JoinColumn(name = "product_id")
//	@MapsId 
//	private Product product;
//	
	@OneToMany(mappedBy = "technician",
			cascade = CascadeType.ALL,
			orphanRemoval = true)
	@JsonIgnore
	private java.util.List<OrderTechnicianDetails> orderTechnicianDetails = new ArrayList<>();	
	
	public Technician(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
}
