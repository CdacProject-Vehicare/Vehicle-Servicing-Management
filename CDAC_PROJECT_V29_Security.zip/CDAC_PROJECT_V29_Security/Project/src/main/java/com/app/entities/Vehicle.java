package com.app.entities;

import java.time.LocalDate;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "vehicle") // to specify table name
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString(exclude = "order")
public class Vehicle {
	
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "vehicle_id")
	private Long vehicleId;
	
	
	@Column(name = "vehicle_mfg")
	private String vehicleMfg;
	@Column(name = "vehicle_name")
	private String vehicleName;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "Vehicle_type")
	private VehicleTypeEnum VehicleType;
	
	@Column(name = "vehicle_no")
	private String VehicleNo;
	
	@OneToOne
	@JoinColumn(name = "order_id")
	@MapsId 
	private Orders order;



}
