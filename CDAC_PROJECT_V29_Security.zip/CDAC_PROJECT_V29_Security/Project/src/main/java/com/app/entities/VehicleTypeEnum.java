package com.app.entities;

public enum VehicleTypeEnum {
  TWOWHEELER,THREEWHEELER,FOURWHEELER;
}
