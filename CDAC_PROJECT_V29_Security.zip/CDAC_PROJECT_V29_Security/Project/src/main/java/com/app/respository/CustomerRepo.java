package com.app.respository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.entities.Customer;
import com.app.entities.Technician;

public interface CustomerRepo extends JpaRepository<Customer,Long> {
	
	Customer findByCustomerId(Long customerId);
	
	List<Customer> findAll();
	
	Optional<Customer> findByEmailAndPassword(String em,String pass);
	
	Customer  findByUserId(Long uid);
}
