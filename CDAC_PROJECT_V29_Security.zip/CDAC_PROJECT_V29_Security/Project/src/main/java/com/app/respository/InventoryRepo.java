package com.app.respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.entities.Inventory;
import com.app.entities.Product;

public interface InventoryRepo extends JpaRepository<Inventory, Long>{
	

	

	
	
	//select e from Employee e where e.dept.id=:id
//	@Query("select p from Product p where p.category.categoryId=:catId")
//	List<Product> findByCategory(Long catId);
	
	
}
