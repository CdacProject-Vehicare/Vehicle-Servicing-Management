package com.app.respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.app.dto.AdminAllOrdersDto;
import com.app.entities.OrderDetails;
import com.app.entities.Orders;
import com.app.entities.Product;

public interface OrderDetailRepo extends JpaRepository<OrderDetails, Long> {
	
	@Query("select od from OrderDetails od where od.orders.orderId=:orderId")
	List<OrderDetails> findOrderDetailsByOrderId(Long orderId);
	
	@Query("SELECT SUM(od.amount*od.quantity) FROM OrderDetails od WHERE od.orders.orderId =:orderId GROUP BY od.orders.orderId")
	Long findTotalSumOfProducts(Long orderId);
	
	@Query("SELECT SUM(od.amount) FROM OrderDetails od  GROUP BY od.product.productId")
	List<Long> findSumOfProductsinOd(Long productId);



      OrderDetails findByOrdersAndProduct(Orders Orders,Product p );

//      @Query("SELECT new com.app.dto.AdminAllOrdersDto(od.orders.orderId,od.odId,od.orders.customer.firstName,od.orders.customer.lastName,od.product.productName,od.product.productPrice,od.orders.orderStatus,od.orders.vehicle.VehicleNo,od.orders.vehicle.vehicleName,od.orders.paymentStatus) FROM OrderDetails od  JOIN od.orders o JOIN od.orders.vehicle v JOIN od.orders.feedback f JOIN od.product p where od.orders.orderId=:orderId")
//      List<AdminAllOrdersDto> AdminOrdersDashboard(@Param("orderId") Long orderId);
//      
      
      
      @Query("SELECT new com.app.dto.AdminAllOrdersDto(od.orders.orderId,od.odId,od.orders.customer.firstName,od.orders.customer.lastName,od.product.productId,od.product.productName,od.product.productPrice,od.orders.orderStatus,od.orders.paymentStatus) FROM OrderDetails od  JOIN od.orders o JOIN od.product p JOIN od.orders.ordertachniciandetails otd JOIN otd.technician ot where ot.technicianId=:technicianId")
      List<AdminAllOrdersDto> TechnicianOrdersDashboard(@Param("technicianId") Long technicianId);

      
      @Query("SELECT new com.app.dto.AdminAllOrdersDto(od.orders.orderId,od.odId,od.orders.customer.firstName,od.orders.customer.lastName,od.product.productId,od.product.productName,od.product.productPrice,od.orders.orderStatus,od.orders.paymentStatus) FROM OrderDetails od  JOIN od.orders o JOIN od.product p")
      List<AdminAllOrdersDto> AdminOrdersDashboard();

      
      
      
      //customer dashboard view
      @Query("SELECT new com.app.dto.AdminAllOrdersDto(od.orders.orderId,od.odId,od.orders.customer.firstName,od.orders.customer.lastName,od.product.productId,od.product.productName,od.product.productPrice,od.orders.orderStatus,od.orders.paymentStatus) FROM OrderDetails od  JOIN od.orders o JOIN od.product p where od.orders.customer.customerId=:customerId")
       List<AdminAllOrdersDto> customerOrdersDashboard0(@Param("customerId") Long customerId);

      
      
      @Query("SELECT new com.app.dto.AdminAllOrdersDto(od.orders.orderId,od.odId) FROM OrderDetails od  JOIN od.orders o")
      List<AdminAllOrdersDto> AdminOrdersDashboard1();
      
      
      
      @Query("SELECT new com.app.dto.AdminAllOrdersDto(od.orders.orderId,od.odId,od.orders.customer.firstName,od.orders.customer.lastName) FROM OrderDetails od  JOIN od.orders o JOIN od.orders.customer c ")
      List<AdminAllOrdersDto> AdminOrdersDashboard2();
      
      
      //this query will give all columns of orders tables
      
     // @Query("Select new")
      
      
//      AdminAllOrdersDto(Long orderId, Long orderDetailsId, String customerFirstname, String customerLastName,
//  			String productName, double price, String technicianAssigned, String status, String vehicleNo,
//  			String vehicleName, String paymentstatus) 
//      
//      
    //  o.vehicle v JOIN o.feedback f
//      @Query("SELECT new com.sunbeaminfo.dto.OrderFeedbackVehicleDto( o.orderBookingDate, o.servicingDate, s.serviceName, f.remarks, v.vehicleName, v.VehicleNo ) FROM Orders o JOIN o.serviceCatalogueList s JOIN o.vehicle v JOIN o.feedback f  WHERE o.id =?1")
//		List<OrderFeedbackVehicleDto> newquery(Long orderId);

}
