package com.app.respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.entities.OrderDetails;
import com.app.entities.OrderInventoryDetails;
import com.app.entities.OrderTechnicianDetails;
import com.app.entities.Orders;

public interface OrderInventoryDetailRepo extends JpaRepository<OrderInventoryDetails, Long> {
	
	@Query("select od from OrderInventoryDetails od where od.orderdetails.orders.orderId=:orderId")
	List<OrderInventoryDetails> findOrderInventoryDetailsByOrderId(Long orderId);
	
}
