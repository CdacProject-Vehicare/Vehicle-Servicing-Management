package com.app.respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.app.entities.OrderDetails;
import com.app.entities.OrderTechnicianDetails;
import com.app.entities.Orders;
import com.app.entities.Product;

public interface OrderTechnicianDetailRepo extends JpaRepository<OrderTechnicianDetails, Long> {
	
	@Query("select od from OrderTechnicianDetails od where od.orders.orderId=:orderId")
	List<OrderTechnicianDetails> findOrderTechnicianDetailsByOrderId(Long orderId);
	
	
	
	
	@Query("select od from OrderTechnicianDetails od where od.technician.technicianId=:TechnicianId")
	List<OrderTechnicianDetails> findOrderTechnicianDetailsByTechnicianId(Long TechnicianId);
	
	
//	@Query("SELECT SUM(od.amount*od.quantity) FROM OrderDetails od WHERE od.orders.orderId =:orderId GROUP BY od.orders.orderId")
//	Long findTotalSumOfProducts(Long orderId);
//	
//	@Query("SELECT SUM(od.amount) FROM OrderDetails od  GROUP BY od.product.productId")
//	List<Long> findSumOfProductsinOd(Long productId);
//
//
//
//      OrderDetails findByOrdersAndProduct(Orders Orders,Product p );
	
	
	    @Modifying
	    @Query("UPDATE OrderTechnicianDetails otd SET otd.Worklog = CONCAT(otd.Worklog, :newWorklog) WHERE otd.orders.orderId = :orderId")
	    void appendWorklogToOrder(@Param("orderId") Long orderId, @Param("newWorklog") String newWorklog);

	

	
	

}
