package com.app.respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.dto.CountDto;
import com.app.entities.Product;

public interface ProductRepo extends JpaRepository<Product, Long>{
	
	List<Product> findAll();
	
	
	List<Product> findByProductName(String productName);
	
	@Query("SELECT count(e) FROM Product e")
	Long countofProducts();
	
	//select e from Employee e where e.dept.id=:id
//	@Query("select p from Product p where p.category.categoryId=:catId")
//	List<Product> findByCategory(Long catId);
	
	
}
