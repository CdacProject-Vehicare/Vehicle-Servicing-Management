
package com.app.service;

import java.util.List;

import com.app.dto.CartRespDTO;
import com.app.dto.CartResponseDTO;

public interface CartService {
	
	List<CartRespDTO> getAllCarts(Long customID);
	
	public CartResponseDTO addToCart(CartResponseDTO dto);
	
}
