package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dto.CartRespDTO;
import com.app.dto.CartResponseDTO;
import com.app.entities.Cart;
import com.app.entities.Customer;
import com.app.entities.Product;
import com.app.respository.CartRepo;
import com.app.respository.CustomerRepo;
import com.app.respository.ProductRepo;

@Service
@Transactional
public class CartServiceImpl implements CartService {

	@Autowired
	private CartRepo cartRepo;
	
	@Autowired
	private ModelMapper mapper;
	
	@Autowired
	private CustomerRepo customerRepo;
	
	private Cart cart;
	
	@Autowired
	private ProductRepo productRepo;
	
	@Override
	public List<CartRespDTO> getAllCarts(Long customID) {
		
		List<Cart> cartList = cartRepo.findByCustomer(customID);
		
		List<CartRespDTO> responseList= new ArrayList<>();
		for (Cart cart : cartList) {
			System.out.println(cart.getProduct().getProductName()+" "+cart.getProduct().getProductPrice());
	        
			CartRespDTO crd =new CartRespDTO();
			
			crd.setProductName(cart.getProduct().getProductName());
            crd.setProductPrice(cart.getProduct().getProductPrice());
            responseList.add(crd);
		}
		
		return responseList;
	}

	@Override
	public CartResponseDTO addToCart(CartResponseDTO dto) {
//		Customer customer = customerRepo.findById(dto.getCustomerId().
//				orElseThrow(() -> new ResourceNotFoundException("Invalid cat Id !!"));

		Customer customer=customerRepo.findById(dto.getCustomerId()).
				orElseThrow(() -> new ResourceNotFoundException("Invalid cat Id !!"));
				
		
		Product product=productRepo.findById(dto.getProductId()).
				orElseThrow(() -> new ResourceNotFoundException("Invalid cat Id !!"));
		
		
		 cart = mapper.map(dto, Cart.class);

			cart.setCustomer(customer);
			
			cart.setProduct(product);
		dto=mapper.map(cartRepo.save(cart), CartResponseDTO.class);
		
		dto.setCustomerId(customer.getCustomerId());
		dto.setProductId(product.getProductId());
	
//			cartRepo.save(cart);	 
				 
		return dto;

	}
	
	

}
