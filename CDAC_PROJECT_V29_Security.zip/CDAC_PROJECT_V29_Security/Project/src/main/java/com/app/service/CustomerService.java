package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.dto.AdminAllOrdersDto;
import com.app.dto.AuthRequest;
import com.app.dto.AuthResp;
import com.app.dto.SignupRequest;
import com.app.dto.SignupResp;
import com.app.dto.addNewCustomerDto;
import com.app.entities.Customer;

public interface CustomerService {
	Customer  addNewCustomer(addNewCustomerDto dto);
	Customer getCustDetails(Long CustId);
	 Customer addCustDetails(Customer Cust) ;
	List<Customer> getAllCustomer();
	
	Customer getCustomer(Long customerId);
	List<AdminAllOrdersDto> customerdashboardView(Long customerId);
	
	AuthResp authenticateCust(AuthRequest request);
	//Cust sign up
	Customer signupCust(Customer request);
	Customer signupCust2(Customer request);

}
