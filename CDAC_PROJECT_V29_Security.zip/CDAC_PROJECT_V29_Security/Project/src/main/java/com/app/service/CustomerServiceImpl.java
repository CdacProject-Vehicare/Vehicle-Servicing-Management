package com.app.service;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dto.AdminAllOrdersDto;
import com.app.dto.AuthRequest;
import com.app.dto.AuthResp;
import com.app.dto.SignupRequest;
import com.app.dto.SignupResp;
import com.app.dto.addNewCustomerDto;
import com.app.entities.Customer;
import com.app.entities.Technician;
import com.app.entities.User;
import com.app.entities.UserRole;
import com.app.respository.CustomerRepo;
import com.app.respository.OrderDetailRepo;
import com.app.respository.UserDao;


@Service
@Transactional
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	private ModelMapper mapper;
	@Autowired
	private CustomerRepo customerRepo;
	
	@Autowired
	private OrderDetailRepo orderdetailsrepo;
	
	@Autowired
	private PasswordEncoder encoder;
	
	@Autowired
	private UserDao userdao;
	
	
	@Override
	public Customer addNewCustomer(addNewCustomerDto dto) {
		if(dto.getConfirmPassword().equals(dto.getPassword())) {
			
			Customer user = mapper.map(dto, Customer.class);
			user.setRole("Customer");
			System.out.println("dto"+dto);
			System.out.println("in customer service   --"+user);
			System.out.println("customer :"+mapper.map(customerRepo.save(user), addNewCustomerDto.class));
			return user;
		}
		return null;
	}

	@Override
	public List<Customer> getAllCustomer() {
		return customerRepo.findAll();
	}

	@Override
	public Customer getCustomer(Long customerId) {
		Customer user = customerRepo
.findByCustomerId(customerId);
		return user;

	}

	@Override
	public List<AdminAllOrdersDto> customerdashboardView(Long customerId) {
		// TODO Auto-generated method stub
		
		
		
		return orderdetailsrepo.customerOrdersDashboard0(customerId);
	}

	@Override
	public AuthResp authenticateCust(AuthRequest request) {
		// autheticate Cust
		Customer Cust = customerRepo.findByEmailAndPassword(request.getEmail(), request.getPassword()).orElseThrow(() -> new ResourceNotFoundException("Invalid Email or Password !!!!!"));
				//.orElseThrow(() -> new ResourceNotFoundException("Invalid Email or Password !!!!!"));
		// => valid login --> map Entity --> DTO
		// ModelMapper API : public T map(Object src , Class<T> class)
		AuthResp a =mapper.map(Cust, AuthResp.class);
		a.setId(Cust.getCustomerId());
		
		
		return a;
	}

	@Override
	public Customer signupCust(Customer request) {
		// map dto --> entity
		//Customer Customer = mapper.map(request, Customer.class);
		// invoke dao's method for saving Cust dtls in DB
		Customer Customer = customerRepo.save(request);
		// map entity --> dto
		return Customer;
	}
	
	@Override
	public Customer signupCust2(Customer request) {
		// map dto --> entity
		//Customer Customer = mapper.map(request, Customer.class);
		// invoke dao's method for saving Cust dtls in DB
		
		User user = new User();
		user.setEmail(request.getEmail());
		user.setPassword(encoder.encode(request.getPassword()));
		user.setRole(UserRole.ROLE_CUSTOMER);

		Customer c = mapper.map(request, Customer.class);
         c.setRole("Customer");
         c.setUser(user);
        // user.setCustomer(c);
		User user1 =userdao.save(user);
		
		
		Customer Customer = customerRepo.save(request);
		// map entity --> dto
		return Customer;
	}
	
	
	@Override
	public Customer getCustDetails(Long CustId) {
		// TODO Auto-generated method stub
		return customerRepo.findById(CustId).orElseThrow(() -> new ResourceNotFoundException("Cust id invalid !!!!!"));
	}
	@Override
	public Customer addCustDetails(Customer Cust) {
		// API of CrudRepository : T save(T entity)
		Cust.setRole("Customer");
		 Cust.setUser(userdao.findByEmail(Cust.getEmail()).orElseThrow());  
		return customerRepo.save(Cust);
	}// auto dirty chking --> insert --> sesison closed --> rets detached Cust to the
		// caller

	
	
}
