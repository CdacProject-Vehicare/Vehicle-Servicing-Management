package com.app.service;

import java.util.List;

import com.app.entities.Feedback;


public interface FeedbackService {
	
	public List<Feedback> getAllFeedback();
	public Boolean insertFeedback(Long orderId,String Remarks,Double rating);
		
	
	
}
