package com.app.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entities.Feedback;
import com.app.entities.Orders;
import com.app.respository.FeedbackRepo;
import com.app.respository.OrderRepo;



@Service
@Transactional
public class FeedbackServiceImpl implements FeedbackService {

	
	@Autowired
	private FeedbackRepo feedbackdao;
	
	@Autowired
	private OrderRepo orderdao;
	
	@Override
	public List<Feedback> getAllFeedback() {
		// TODO Auto-generated method stub
		
		return feedbackdao.findAll();
	}

	@Override
	public Boolean insertFeedback(Long orderId, String Remarks, Double rating) {
		
		Feedback f1=new Feedback();
//	      Orders o=orderdao.findById(orderId);
//		
		Orders o=orderdao.findById(orderId).orElse(null);
		 	
		f1.setRating(rating);
		f1.setRemarks(Remarks);
		f1.setOrder(o);
		f1.setFeedbackDate(LocalDate.now());
		feedbackdao.save(f1);
		return true;
	}

	
	
	

	
	

}
