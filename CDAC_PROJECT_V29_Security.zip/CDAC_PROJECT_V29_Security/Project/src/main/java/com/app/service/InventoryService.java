package com.app.service;

import java.util.List;

import com.app.entities.Inventory;



public interface InventoryService {
	
	public List<Inventory> getAllItems();
	public List<Inventory> getAllItemsDetails(List<Long> inventoryId);
	public Inventory addItem(Inventory item);
}
