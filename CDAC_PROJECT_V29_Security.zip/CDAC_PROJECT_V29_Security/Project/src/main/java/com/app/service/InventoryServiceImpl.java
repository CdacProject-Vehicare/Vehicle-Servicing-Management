package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entities.Inventory;
import com.app.respository.InventoryRepo;


@Service
@Transactional
public class InventoryServiceImpl implements  InventoryService{

	
	@Autowired
	private InventoryRepo inventoryRepo;
	
	@Override
	public List<Inventory> getAllItems() {
		// TODO Auto-generated method stub
		
		return inventoryRepo.findAll();
	}

	@Override
	public List<Inventory> getAllItemsDetails(List<Long> inventoryId) {
		// TODO Auto-generated method stub
		
		
		return inventoryRepo.findAllById(inventoryId);
	}
	// dep : orders Repo i/f
	
	@Override
	public Inventory addItem(Inventory item) {
		// TODO Auto-generated method stub
		
		
		return inventoryRepo.save(item);
	}
	

	
	

}
