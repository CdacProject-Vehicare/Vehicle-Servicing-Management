package com.app.service;

import java.util.List;

import com.app.dto.OrderDetailsDto;
import com.app.dto.OrderInventoryDetailsResponeDto;
import com.app.entities.OrderDetails;
import com.app.entities.OrderInventoryDetails;
import com.app.entities.OrderTechnicianDetails;
import com.app.entities.Orders;

public interface OrderInventoryDetailsService {
	
//	Orders findProduct(Long productId); 
//	
//	OrderDetails addOrderDetails(OrderDetailsDto dto);
//		
//	List<OrderDetails> getOrderDetailsByOrderId(Long orderId);
//	
//	void updateOrderTotal(Long orderId);
//	
	
     //OrderDetails getOrderDetailsByOrderAndProduct(Long orderId,Long ProductId);
	List<OrderInventoryDetailsResponeDto> getOrderInventoryDetailsByOrderId(Long orderId);
	
	     OrderInventoryDetails addToOrderInventoryDetails(Long OrderId,Long ProductId,Long InventoryId ,int Qtyused);
}
