package com.app.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dto.OrderDetailsDto;
import com.app.dto.OrderInventoryDetailsResponeDto;
import com.app.entities.Inventory;
import com.app.entities.OrderDetails;
import com.app.entities.OrderInventoryDetails;
import com.app.entities.OrderTechnicianDetails;
import com.app.entities.Orders;
import com.app.entities.Product;
import com.app.respository.InventoryRepo;
import com.app.respository.OrderDetailRepo;
import com.app.respository.OrderInventoryDetailRepo;
import com.app.respository.OrderRepo;
import com.app.respository.ProductRepo;


@Service
@Transactional
public class OrderInventoryDetailsServiceImpl implements OrderInventoryDetailsService {

	@Autowired
	private OrderRepo orderRepo;
	
	@Autowired
	private OrderDetailRepo orderDetailsRepo;
	
	@Autowired
	private ProductRepo productRepo;
	
	
	@Autowired
	private InventoryRepo inventoryRepo;
	
	
	@Autowired
	private OrderInventoryDetailRepo orderInventoryDetailsRepo;
	
	@Autowired
	private ModelMapper mapper;
	
	@Autowired
	private OrderDetailsService orderservicedetails;

	
	
	@Override
	public OrderInventoryDetails addToOrderInventoryDetails(Long OrderId, Long ProductId, Long InventoryId,
			int Qtyused) {
		// TODO Auto-generated method 
		
		 System.out.println("inside services impl");
	  OrderDetails osd1=	orderservicedetails.getOrderDetailsByOrderAndProduct(OrderId, ProductId);
	   Inventory i1=  inventoryRepo.findById(InventoryId).orElseThrow();
	  
	   OrderInventoryDetails oid1=new OrderInventoryDetails();
	   
	   
	   oid1.setInventory(i1);
	   oid1.setOrderdetails(osd1);
	   oid1.setQuantityUsed(Qtyused);
	 
	   orderInventoryDetailsRepo.save(oid1);
	   
	   i1.setAvailableStock(i1.getAvailableStock()-Qtyused);
		
	   return orderInventoryDetailsRepo.save(oid1);
	}

	@Override
	public List<OrderInventoryDetailsResponeDto> getOrderInventoryDetailsByOrderId(Long orderId){
		//updateOrderTotal(orderId);	
		//System.out.println(orderDetailsRepo.findSumOfTechniciansinOd(2L) + "hii");
		List<OrderInventoryDetails> list=orderInventoryDetailsRepo.findOrderInventoryDetailsByOrderId(orderId);
		List<OrderInventoryDetailsResponeDto> responselist= new ArrayList<>();
		
		
		   for (OrderInventoryDetails orderInventoryDetails : list) {
			
			   OrderInventoryDetailsResponeDto oidresponse= new OrderInventoryDetailsResponeDto();
			   
			   oidresponse.setQtyUsed(orderInventoryDetails.getQuantityUsed());
			   oidresponse.setProductName(orderInventoryDetails.getOrderdetails().getProduct().getProductName());
			   oidresponse.setInventoryName(orderInventoryDetails.getInventory().getInventoryName());
			   oidresponse.setProductId(orderInventoryDetails.getOrderdetails().getProduct().getProductId());
			   oidresponse.setInventoryId(orderInventoryDetails.getInventory().getInventoryId());
			   oidresponse.setOrderId(orderId);
			   responselist.add(oidresponse);
	     	}
		
		
		 
		
		return responselist;
		
	}
	
	
}
