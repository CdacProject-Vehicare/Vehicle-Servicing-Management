package com.app.service;

import com.app.dto.CountDto;
import com.app.entities.Orders;

public interface OrderService {
	Orders addOrder(Orders o);
	Orders UpdateOrderStatus(Long OrderId,String status);
	Orders UpdateOrderPaymentStatus(Long OrderId,String status);
	
	CountDto OrderStatistics();
	
}
