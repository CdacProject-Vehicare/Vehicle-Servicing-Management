package com.app.service;

import java.util.List;

import com.app.dto.OrderDetailsDto;
import com.app.dto.OrderTechnicianDetailsDto;
import com.app.dto.OrderTechnicianDetailsResponseDto;
import com.app.entities.OrderDetails;
import com.app.entities.OrderTechnicianDetails;
import com.app.entities.Orders;

public interface OrderTechnicianDetailsService {
	
	//Orders findProduct(Long productId); 
	
	OrderTechnicianDetails addTechnicianToOrder(OrderTechnicianDetailsDto dto);
		
	List<OrderTechnicianDetails> getOrderTechnicianDetailsByOrderId(Long orderId);
	
	List<OrderTechnicianDetailsResponseDto> getAllOrderTechnicianDetails();
	
	
	List<OrderTechnicianDetailsResponseDto> getAllOrderTechnicianDetailsForTechnicianDashBoard(Long TechnicianId);

		
	OrderTechnicianDetailsResponseDto updateWorklog(Long orderId,String worklogText);
	
	
//	void updateOrderTotal(Long orderId);
	
	
     //OrderDetails getOrderDetailsByOrderAndProduct(Long orderId,Long ProductId);
}
