package com.app.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dto.OrderDetailsDto;
import com.app.dto.OrderTechnicianDetailsDto;
import com.app.dto.OrderTechnicianDetailsResponseDto;
import com.app.entities.OrderDetails;
import com.app.entities.OrderTechnicianDetails;
import com.app.entities.Orders;
import com.app.entities.Technician;
import com.app.respository.OrderDetailRepo;
import com.app.respository.OrderRepo;
import com.app.respository.OrderTechnicianDetailRepo;
import com.app.respository.TechnicianRepo;


@Service
@Transactional
public class OrderTechnicianDetailsServiceImpl implements OrderTechnicianDetailsService {

	@Autowired
	private OrderRepo orderRepo;
	
	@Autowired
	private OrderTechnicianDetailRepo orderTechnicianDetailsRepo;
	
	@Autowired
	private TechnicianRepo TechnicianRepo;
	
	@Autowired
	private ModelMapper mapper;
		
//	@Override
//	public Orders findTechnician(Long TechnicianId) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	//Assigned Technician to order 
	@Override
	public OrderTechnicianDetails addTechnicianToOrder(OrderTechnicianDetailsDto dto) {
		Orders order=orderRepo.findById(dto.getOrderId()).orElseThrow(()->new ResourceNotFoundException(""));
		
	//	System.out.println("order in ordertechniciandtls---"+order);
	//	System.out.println("technicianId----"+dto.getTechnicianId());
		Technician Technician=TechnicianRepo.findById(dto.getTechnicianId()).orElseThrow(()->new ResourceNotFoundException(""));
	//	System.out.println("Technician in orderdtls---"+Technician);
		
		
		OrderTechnicianDetails ordertechnicianDetails = mapper.map(dto, OrderTechnicianDetails.class);
		ordertechnicianDetails.setOrders(order);
		ordertechnicianDetails.setTechnician(Technician);
		
//		OrderTechnicianDetails.setOrders(order);
//		OrderTechnicianDetails.setTechnician(Technician);
//			System.out.println("orderdetails---------"+orderDetails);
		ordertechnicianDetails.setWorklog("=>");
		orderTechnicianDetailsRepo.save(ordertechnicianDetails);
		return ordertechnicianDetails;
	}
	
	@Override
	public List<OrderTechnicianDetails> getOrderTechnicianDetailsByOrderId(Long orderId){
		//updateOrderTotal(orderId);	
		//System.out.println(orderDetailsRepo.findSumOfTechniciansinOd(2L) + "hii");
		return orderTechnicianDetailsRepo.findOrderTechnicianDetailsByOrderId(orderId);
		
	}

	@Override
	public List<OrderTechnicianDetailsResponseDto> getAllOrderTechnicianDetails() {
		// TODO Auto-generated method stub
		
		List<OrderTechnicianDetails>  list =orderTechnicianDetailsRepo.findAll(); 
		
		List<OrderTechnicianDetailsResponseDto> responseList=new ArrayList<>();
	         for (OrderTechnicianDetails orderTechnicianDetails : list) {
				 
	        	 OrderTechnicianDetailsResponseDto o =new OrderTechnicianDetailsResponseDto();
	        	 o.setWorklog(orderTechnicianDetails.getWorklog()); 
	        	 o.setExpectedCompletionDate(orderTechnicianDetails.getOrders().getOdate().plusDays(2));
	        	 o.setTechnicianName(orderTechnicianDetails.getTechnician().getFirstName());
		         o.setTechnicianId(orderTechnicianDetails.getTechnician().getTechnicianId());
                 o.setOrderId(orderTechnicianDetails.getOrders().getOrderId()); 
                 responseList.add(o);
	         }
		
		return responseList;

	}

	@Override
	public OrderTechnicianDetailsResponseDto updateWorklog(Long orderId,String worklogText) {
		// TODO Auto-generated method stub
		
		orderTechnicianDetailsRepo.appendWorklogToOrder(orderId, " Status Updated "+" -> "+worklogText+" : "+LocalDate.now());
		return null;
	}

	@Override
	public List<OrderTechnicianDetailsResponseDto> getAllOrderTechnicianDetailsForTechnicianDashBoard(
			Long TechnicianId) {
		// TODO Auto-generated method stub
		            
		
		List<OrderTechnicianDetails> orderTechnicianDetailslist= orderTechnicianDetailsRepo.findOrderTechnicianDetailsByTechnicianId(TechnicianId);
		
       //List<OrderTechnicianDetails>  list =orderTechnicianDetailsRepo.findAll(); 
		
		List<OrderTechnicianDetailsResponseDto> responseList=new ArrayList<>();
	         for (OrderTechnicianDetails orderTechnicianDetails : orderTechnicianDetailslist) {
				 
	        	 OrderTechnicianDetailsResponseDto o =new OrderTechnicianDetailsResponseDto();
	        	 o.setWorklog(orderTechnicianDetails.getWorklog()); 
	        	 o.setExpectedCompletionDate(orderTechnicianDetails.getOrders().getOdate().plusDays(2));
	        	 o.setTechnicianName(orderTechnicianDetails.getTechnician().getFirstName());
		         o.setTechnicianId(orderTechnicianDetails.getTechnician().getTechnicianId());
                 o.setOrderId(orderTechnicianDetails.getOrders().getOrderId()); 
                 responseList.add(o);
	         }
		
		return responseList;
		
	}


//	@Override
//	public void updateOrderTotal(Long orderId) {
//		
//		Orders order=orderRepo.findByOrderId(orderId);
//		//directly putting the total of all the Technician fetched using the sum() and groupby query.
//		//order.setTotal(orderDetailsRepo.findTotalSumOfTechnicians(orderId));
//		//order.setTotal(orderDetailsRepo.findTotalSumOfTechnicians(orderId));
//		System.out.println(orderDetailsRepo.findSumOfTechniciansinOd(orderId) + "hii");
//		
//		orderRepo.save(order);
//	}

//	@Override
//	public OrderDetails getOrderDetailsByOrderAndTechnician(Long orderId, Long TechnicianId) {
//		
//		Orders o1=orderRepo.findById(orderId).orElseThrow();
//		Technician p1=TechnicianRepo.findById(TechnicianId).orElseThrow();
//		
//		
//		
//		return orderDetailsRepo.findByOrdersAndTechnician(o1, p1);
//	}

	
	
	

}
