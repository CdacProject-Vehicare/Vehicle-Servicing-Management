package com.app.service;

import java.util.List;


import com.app.dto.AddProductDto;

import com.app.dto.ProductRespDTO;
import com.app.entities.Product;



public interface ProductService {

	List<ProductRespDTO> getAllProductsFromCat();


	Product addNewProduct(AddProductDto dto);
	
	Product updateProduct(Long prodID,AddProductDto dto);
	
	Product deleteProduct(Long prodID);


	Product getProductDetails(Long prodID);
	
	
}
