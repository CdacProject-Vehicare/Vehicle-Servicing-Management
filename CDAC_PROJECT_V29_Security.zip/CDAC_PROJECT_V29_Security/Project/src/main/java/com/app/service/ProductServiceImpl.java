package com.app.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ApiException;
import com.app.custom_exceptions.ResourceNotFoundException;
//import com.app.custom_exceptions.ApiException;
//import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dto.AddProductDto;

import com.app.dto.ProductRespDTO;
//import com.app.entities.Address;

import com.app.entities.Product;
//import com.app.entities.Project;
//import com.app.repository.AddressRepository;

import com.app.respository.ProductRepo;

@Service
@Transactional
public class ProductServiceImpl implements ProductService{
	
	
	@Autowired
	private ProductRepo prodRepo;
	
	
	
	@Autowired
	private ModelMapper mapper;
	

	@Override
	public List<ProductRespDTO> getAllProductsFromCat() {

		System.out.println("in service  prod get");
		List<Product> prodList=prodRepo.findAll();
		return prodList.stream() //Stream<Emp>
				.map(prod ->mapper.map(prod, ProductRespDTO.class))//Stream<DTO>
				.collect(Collectors.toList());
	}

	@Override
	public Product addNewProduct(AddProductDto dto) {

		Product prod = new Product();
		mapper.map(dto,prod);
		prodRepo.save(prod);
		return prod;
		
	}

	@Override
	public Product updateProduct(Long prodID, AddProductDto dto) {
		
		Product prod = prodRepo.findById(prodID)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Prod ID , Prod not found !!!!"));
			mapper.map(dto,prod);
	    	prod.setProductId(prodID);
		return mapper.map(prod,Product.class);
		
	}

	@Override
	public Product getProductDetails(Long prodID) {
		Product product = prodRepo.findById(prodID)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Prod ID!!!"));
		return product;
	}

	@Override
	public Product deleteProduct(Long prodID) {
		
		//System.out.println("Optional"+product1);
		Product product = prodRepo.findById(prodID)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Prod ID!!!"));
		//System.out.println("product"+product);
		prodRepo.delete(product);
		return product;
	}

}
