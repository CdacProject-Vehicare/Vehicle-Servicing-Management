package com.app.service;

import java.util.List;

import com.app.dto.AdminAllOrdersDto;
import com.app.dto.ApiResponse;
import com.app.dto.AuthRequest;
import com.app.dto.AuthResp;
import com.app.dto.SignupRequest;
import com.app.entities.Technician;
import com.app.dto.SignupResp;



public interface TechnicianService {
	
	List<Technician> getAllTechnicians();
	Technician addTechnicianDetails(Technician Technician);
	
	ApiResponse deleteTechnicianDetails(Long TechnicianId);
	//add a method for Technician signin
	AuthResp authenticateTechnician(AuthRequest request);
	//Technician sign up
	SignupResp signupTechnician(SignupRequest request);
	Technician getTechnicianDetails(Long TechnicianId) ;
	
	List<AdminAllOrdersDto> getAllOrderDetailsforTechnician(Long Technician);
	//Technician saveTechnicianDetails(Long TechnicianId);
	//list all Technician names havinf a sal > min sal
	//List<TechnicianFullName> getTechnicianNamesBySalarySanket(double minSal);
	 SignupResp signupTechnician2(SignupRequest request) ;
}
