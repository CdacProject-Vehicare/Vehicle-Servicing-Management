package com.app.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dto.AdminAllOrdersDto;
import com.app.dto.ApiResponse;
import com.app.dto.AuthRequest;
import com.app.dto.AuthResp;
import com.app.dto.OrderDetailsDto;
import com.app.dto.SignupRequest;
import com.app.entities.Designation;
import com.app.entities.Feedback;
import com.app.entities.Orders;
import com.app.entities.Technician;
import com.app.entities.User;
import com.app.entities.UserRole;
import com.app.respository.OrderDetailRepo;
import com.app.respository.ProductRepo;
import com.app.respository.TechnicianRepo;
import com.app.respository.UserDao;
import com.app.dto.SignupResp;



@Service
@Transactional
public class TechnicianServiceImpl implements TechnicianService {
	// dep : Technician dao i/f
	@Autowired
	private TechnicianRepo technicianDao;
	// autowire : model mapper
	@Autowired
	private ModelMapper mapper;
	
	@Autowired
	private ProductRepo productRepo;
	
	private OrderDetailRepo odr;

	@Autowired
	private PasswordEncoder encoder;
	
	@Autowired
	private UserDao userdao;
	@Override
	public List<Technician> getAllTechnicians() {
		// TODO Auto-generated method stub
		return technicianDao.findAll();
	}

	@Override
	public Technician addTechnicianDetails(Technician Technician) {
		// API of CrudRepository : T save(T entity)
		Technician.setDesignation(Designation.SENIOR);
		Technician.setRole("Technician");
		
		//Technician.setProduct(productRepo.findById(ProductId).orElseThrow()); 
		return technicianDao.save(Technician);
	}// auto dirty chking --> insert --> sesison closed --> rets detached Technician to the
		// caller

	@Override
	public Technician getTechnicianDetails(Long TechnicianId) {
		// TODO Auto-generated method stub
		return technicianDao.findById(TechnicianId).orElseThrow(() -> new ResourceNotFoundException("Technician id invalid !!!!!"));
	}

	@Override
	public ApiResponse deleteTechnicianDetails(Long TechnicianId) {
		Technician Technician = getTechnicianDetails(TechnicianId);
		// => Technician id valid
		technicianDao.delete(Technician); // OR TechnicianDao.deleteById(TechnicianId)
		return new ApiResponse("Technician details deleted !");
	}

	@Override
	public AuthResp authenticateTechnician(AuthRequest request) {
		// autheticate Technician
		Technician Technician = technicianDao.findByEmailAndPassword(request.getEmail(), request.getPassword())
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Email or Password !!!!!"));
		
		
		System.out.println("in the authenticateTechnician////************* technician Service Impl") ;
		// => valid login --> map Entity --> DTO
		// ModelMapper API : public T map(Object src , Class<T> class)
		System.out.println("technician id ="+Technician.getTechnicianId());
		//Technician t=mapper.map(Technician, AuthResp.class);
	//	System.out.println(t.getTechnicianId());
		AuthResp a =mapper.map(Technician, AuthResp.class);
		a.setId(Technician.getTechnicianId());
		return a;
	}

	@Override
	public SignupResp signupTechnician(SignupRequest request) {
		// map dto --> entity
		String dateStr = request.getJoinDate();
		
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;
        
		//String dateStr = dateDTO.getDate();
        
       // DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;
        LocalDate localDate = LocalDate.parse(dateStr, formatter);
        
        
		Technician technician = mapper.map(request, Technician.class);
		technician.setJoinDate(localDate);
		technician.setDesignation(Designation.TRAINEE);
		technician.setRole("Technician");
		// invoke dao's method for saving Technician dtls in DB
		Technician Technician2 = technicianDao.save(technician);
		// map entity --> dto
		System.out.println("technician id ="+Technician2.getTechnicianId());
		return mapper.map(Technician2, SignupResp.class);
	}

//	--------------------------------------------security---------------------------
	@Override
	public SignupResp signupTechnician2(SignupRequest request) {
		// map dto --> entity
		
		
		User user = new User();
		user.setEmail(request.getEmail());
		user.setPassword(encoder.encode(request.getPassword()));
		user.setRole(UserRole.ROLE_TECHNICIAN);
		User user1 =userdao.save(user);
		
		
		
		
		
		String dateStr = request.getJoinDate();
		
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;
        
		//String dateStr = dateDTO.getDate();
        
       // DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;
        LocalDate localDate = LocalDate.parse(dateStr, formatter);
        
        
		Technician technician = mapper.map(request, Technician.class);
		technician.setJoinDate(localDate);
		technician.setDesignation(Designation.TRAINEE);
		technician.setRole("Technician");
		technician.setUser(user1);
		//user1.setTechnician(technician);
		// invoke dao's method for saving Technician dtls in DB
		Technician Technician2 = technicianDao.save(technician);
		//user1.setTechnician(Technician2);
		// map entity --> dto
		System.out.println("technician id ="+Technician2.getTechnicianId());
		
		
		
		
		
		return mapper.map(Technician2, SignupResp.class);
	}
	//	----------------------------------------------------------------------------------
	@Override
	public List<AdminAllOrdersDto> getAllOrderDetailsforTechnician(Long TechnicianId) {
		// TODO Auto-generated method stub
		
		
		return odr.TechnicianOrdersDashboard(TechnicianId);
	}
	
//	@Override
//	public Boolean insertTechnician(Long orderId, String Remarks, Double rating) {
//		
//		Feedback f1=new Feedback();
////	      Orders o=orderdao.findById(orderId);
////		
//		Orders o=orderdao.findById(orderId).orElse(null);
//		 	
//		f1.setRating(rating);
//		f1.setRemarks(Remarks);
//		f1.setOrder(o);
//		f1.setFeedbackDate(LocalDate.now());
//		feedbackdao.save(f1);
//		return true;
//	}
//	
	
//
//	@Override
//	public Technician saveTechnicianDetails(Long TechnicianId) {
//		
//		
//		return null;
//	}

	
	
	//
//	@Override
//	public List<TechnicianFullName> getTechnicianNamesBySalarySanket(double minSal) {
//		// call dao's method
//		List<Technician> TechnicianList = TechnicianDao.xxxxxx(minSal);
//		List<TechnicianFullName> efn=new ArrayList<>();
//		
//		for(Technician e:TechnicianList)
//		 efn.add(mapper.map(e,TechnicianFullName.class));
//	     return efn;     
//		return TechnicianList.stream(). //Stream<Technician>
//				map(Technician -> mapper.map(Technician, TechnicianFullName.class)). //Stream<TechnicianFullName>
//				collect(Collectors.toList());//List<DTO>
//	}

}
