package com.app.service;

import com.app.entities.User;

public interface UserService {
 User addUserDetails(User user);
 //boolean userExists(String email);

	//void changeRole(Role role, String email);
}
