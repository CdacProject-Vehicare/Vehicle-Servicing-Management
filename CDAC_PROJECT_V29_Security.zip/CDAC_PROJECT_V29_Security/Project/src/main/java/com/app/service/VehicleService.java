package com.app.service;

import java.util.List;

import com.app.entities.Vehicle;


public interface VehicleService {
	
	public List<Vehicle> getAllVehicleList();
	public Boolean insertVehicle(Long CustomerId,Vehicle v);
//	public Boolean updateVehicle(Long CustomerId,Vehicle v);
}
