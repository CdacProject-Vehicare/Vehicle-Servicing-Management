package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entities.Orders;
import com.app.entities.Vehicle;
import com.app.respository.CustomerRepo;
import com.app.respository.OrderRepo;
import com.app.respository.VehicleRepo;

@Service
@Transactional
public class VehicleServiceImpl implements VehicleService {

	@Autowired
	private VehicleRepo vehicledao;
	 
	@Autowired
	private CustomerRepo customerdao;
	 
	@Autowired 
	private OrderRepo ordersdao;
	
	@Override
	public List<Vehicle> getAllVehicleList() {
	  
		
		return vehicledao.findAll();
	}

	@Override
	public Boolean insertVehicle(Long orderId, Vehicle v) {
		// TODO Auto-generated method stub
	    Orders o1=ordersdao.findById(orderId).orElseThrow();
	    
		Vehicle v1=new Vehicle();
		v1.setVehicleMfg(v.getVehicleMfg());
		v1.setVehicleName(v.getVehicleName());
		v1.setVehicleType(v.getVehicleType());
		v1.setVehicleNo(v.getVehicleNo());
		v1.setOrder(o1);
				
		vehicledao.save(v1);
		ordersdao.save(o1);
		return true;
	}

	
	

	
	

}
