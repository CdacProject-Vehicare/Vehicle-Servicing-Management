import { useDispatch, useSelector } from 'react-redux'
import { Route, Routes } from 'react-router-dom'

import './App.css'
import Cart from './components/cart'

import LoginTechnician from './components/Technician/loginTechnician'
import EditTechnicianProfile from './components/Technician/EditTechnicianProfile' 
import RegisterTechnician from './components/Technician/registerTechnician'
import AllTechnicianDetails from './components/Admin/AllTechnicianDetails'

import MyOrders from './components/myOrders'
import NavigationBar from './components/navigationBar'
//import ProductGallery from './components/product-gallery'
import ProductGallery from './components/Admin/ServiceCatalogue'
import TechnicianAccount from './components/Technician/TechnicianAccount'
// used to register react-toastify
import { useEffect } from 'react'
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import { login } from './features/authSlice'
import AdminAccount from './components/Admin/AdminAccount'
import AllAssignedOrders from './components/Admin/AllAssignedOrders'
import GetAllOrdersDetailsList from './components/Admin/AllOrdersDetails'
import GetAllOrdersInventoryDetailsList from './components/Admin/AllOrdersInventoryDetails'
import CartGallery from './components/Admin/CartDetailsForUser'
import EmployeeDropdown from './components/Admin/demo'
import InventoryDetails from './components/Admin/InventoryDetails'
import AddNewItemInInventory from './components/Admin/AddNewItemInInventory'
import AddFeedbackToOrder from './components/Customer/AddFeedbackToOrder'
import AllFeedbackDetails from './components/Admin/AllFeedbackDetails'
import AddNewVehicleToOrder from './components/Customer/AddNewVehicleToOrder'
import InventoryUsage from './components/Technician/UpdateInventoryUsedDetails'
import GetAllOrdersDetailsListByCustomerId from './components/Customer/CustomerAllOrdersDetails'
import TechnicianDashBoard from './components/Technician/TechnicianDashBoard'
import VehicleDetails from './components/Technician/VehicleDetailsOfAnOrder'
import GetAllOrdersDetailsListByTechnician from './components/Technician/AllOrdersDetailsTechnician'
import LoginCustomer from './components/Customer/LoginCustomer'
import RegisterUser from './components/Customer/RegisterUser'
import CustomerAccount from './components/Customer/CustomerAccount'

// ****************************************************************************************************************
import Home from './components/FrontPage/Home'
import IndexNavbar from './components/FrontPage/HomeComponent/NavBars/IndexNavbar'
import LaunchNewService from './components/Admin/LaunchNewService'
import ProductCatalogue from './components/Admin/ProductCatalouge'
import UpdateServiceCatalogue from './components/Admin/UpdateServiceCatalogue'
import UpdateTechnicianDetailsByAdmin from './components/Admin/UpdateTechnicianDetailsByAdmin'
import EditCustomerProfile from './components/Customer/EditCustomerProfile'
import EditAdminProfile from './components/Admin/EditAdminProfile'
import HeaderHome from './components/FrontPage/HomeComponent/HeaderHome'
import AllServiceDetails from './components/FrontPage/HomeComponent/AllServiceDetails'
import FutureScope from './components/FrontPage/FutureScope'
import UnAuthorized from './unAuthorized'
import { PageNotFound } from './PageNotFound'

function App() {
  // use selector accepts a function which passes the store global state
  // at the moment we are interested only in auth slice
  const loginStatus = useSelector((state) => state.auth.status)
  const dispatch = useDispatch()

  useEffect(() => {
    // first read the current sessionStorage and see if user is logged in
    if (sessionStorage['token'] && sessionStorage['token'].length > 0) {
      // update the auth slice status to true
      dispatch(login())
    }
  }, [])

  return (
    <div className='container-fluid'>
      {/* navigation bar here */}
      {/* conditional rendering */}
      {loginStatus && <NavigationBar />}
      <div>
        <Routes>
        {/* <Route path='/' element={< />} />
        <Route path='/LoginTechnician' element={<LoginTechnician />} /> */}
        
        <Route path='/' element={<Home />} /> 
        <Route path='/LoginTechnician' element={<LoginTechnician />} />
        <Route path='/register' element={<RegisterTechnician />} />
        <Route path='/product-gallery' element={<ProductGallery />} />
        <Route path='/cart' element={<Cart />} />
        <Route path='/TechnicianAccount' element={<TechnicianAccount />} />
        <Route path='/EditTechnicianProfile' element={< EditTechnicianProfile/>} />
        <Route path='/InventoryUsage/:orderId/:productId' element={< InventoryUsage/>} />
        <Route path='/AdminAccount' element={<AdminAccount />} />
        <Route path='/AllTechnicianDetails' element={<AllTechnicianDetails />} />
        <Route path='/AllAssginedOrdersTechnician' element={<AllAssignedOrders/>} />
        <Route path='/AllOrdersDetails' element={< GetAllOrdersDetailsList/>} />
        <Route path='/my-orders' element={<MyOrders />} />
        <Route path="/OrdersInventoryDetails/:id" element={<GetAllOrdersInventoryDetailsList/>} />
        <Route path="/productgallery" element={<ProductGallery/>} />          
        <Route path="/cartdetails" element={<CartGallery/>} />
        <Route path="/empdropdown" element={<EmployeeDropdown/>} />
        <Route path='/InventoryDetails' element={<InventoryDetails />} />
        <Route path='/AddNewItemInInventory' element={<AddNewItemInInventory />} />
        <Route path='/AddFeedbackToOrder/:id' element={<AddFeedbackToOrder />} />
        <Route path='/AllFeedbackDetails' element={<AllFeedbackDetails />} />
        <Route path='/AddNewVehicleToOrder/:id' element={<AddNewVehicleToOrder />} />
        <Route path='/CustomerDashBoard' element={<GetAllOrdersDetailsListByCustomerId />} />
        <Route path='/TechnicianDashBoard' element={<TechnicianDashBoard />} />
        <Route path='/GetVehicleDetails/:orderId' element={<VehicleDetails />} />
        <Route path='/GetAllOrdersDetailsListByTechnician' element={<GetAllOrdersDetailsListByTechnician />} />
        <Route path='/LoginCustomer' element={<LoginCustomer />} />
        <Route path='/RegisterUser' element={<RegisterUser />} />
        <Route path='/CustomerAccount' element={<CustomerAccount />} />
{/* ******************************************************************************************************************************* */}
        {/* <Route path='/' element={<Home />} />  */}
        <Route path='/LaunchNewService' element={<LaunchNewService />} /> 
        <Route path='/GetAllOrdersDetailsListByCustomerId' element={<GetAllOrdersDetailsListByCustomerId />} />
        
        <Route path='/ProductCatalogue' element={<ProductCatalogue />} />
        <Route path='/LaunchNewService' element={<LaunchNewService />} />
        <Route path='/UpdateServiceCatalogue/:id' element={<UpdateServiceCatalogue />} />
        <Route path='/UpdateTechnicianDetailsByAdmin/:id' element={<UpdateTechnicianDetailsByAdmin />} />
        <Route path='/EditCustomerProfile' element={<EditCustomerProfile />} />
        <Route path='/EditAdminProfile' element={<EditAdminProfile />} />
        <Route path='/HeaderHome' element={<HeaderHome />} />
        <Route path='/AllServiceDetails' element={<AllServiceDetails />} />
        <Route path='/FutureScope' element={<FutureScope />} />
        <Route path='/401' element={<UnAuthorized/>}/>
        <Route path='/*' element={<PageNotFound/>}/>
        


        </Routes>
      </div>
      <ToastContainer />
    </div>
  )
}

export default App
