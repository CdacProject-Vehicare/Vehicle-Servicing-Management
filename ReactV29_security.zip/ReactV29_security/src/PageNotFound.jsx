
// import PageNotFoundImg from './../public/ErrorImage/error404.jpeg'
import PageNotFoundImg from './ErrorImage/error404.jpeg'

const PageNotFound = ()=>{
    return <>
            <div style={{height : 'calc(100vh - 56px)', backgroundColor:'#131E3A'}} className="container-fluid d-flex justify-content-center align-items-center" 
                 >
                <img src={PageNotFoundImg} style={{width:'50%'}}   alt="Page Not Found" />
            </div>
            </>
}
export  {PageNotFound};