import React from 'react';


import '../../../node_modules/bootstrap/dist/css/bootstrap.css';


const InfoCardComponent = () => {
  return (
   
   <center>
    <table><tr><td><div className="card" style={{ width: '18rem' }}>
   <img src="..." className="card-img-top" alt="..." />
   <div className="card-body">
     <h5 className="card-title">Order Summary</h5>
     <p className="card-text">
       This month: 100
     </p>
    
   </div>
 </div></td>
 <td>
 <div className="card" style={{ width: '18rem' }}>
      <img src="..." className="card-img-top" alt="..." />
      <div className="card-body">
        <h5 className="card-title">Revenue Summary</h5>
        <p className="card-text">
        This month: 34467rs
        </p>
       
      </div>
    </div>
 </td>
 </tr></table>
   
   </center>
  );
};

export default InfoCardComponent;




// import React from 'react';

// const InfoCardComponent = () => {
//   return (
//         <>
//         <div className='table-responsive'>
//         <table class="table table-hover" >
//     <div className="card text-dark bg-warning mb-3 hover-card" style={{ maxWidth: '18rem' }}>
        
//         <tbody>
//             <tr>
//                 <td style={{width : 100}}>
//                     <div className="card text-dark bg-warning mb-3 hover-card" style={{ Width: '18rem' }}>
//                                     <div className="card-header">Header</div>
//                     <div className="card-body">
//                         <h5 className="card-title">Info card title</h5>
//                         <p className="card-text">
//                         Some quick example text to build on the card title and make up the bulk of the card's content.
//                         </p>
//                     </div> 
//                     </div> 
//                 </td>

//                 <td>
//                     <div className="card text-dark bg-warning mb-3 hover-card" style={{ Width: '18rem' }}>
//                                     <div className="card-header">Header</div>
//                     <div className="card-body">
//                         <h5 className="card-title">Info card title</h5>
//                         <p className="card-text">
//                         Some quick example text to build on the card title and make up the bulk of the card's content.
//                         </p>
//                     </div> 
//                     </div> 
//                 </td>

//                 <td>
//                     <div className="card text-dark bg-warning mb-3 hover-card" style={{ Width: '18rem' }}>
//                                     <div className="card-header">Header</div>
//                     <div className="card-body">
//                         <h5 className="card-title">Info card title</h5>
//                         <p className="card-text">
//                         Some quick example text to build on the card title and make up the bulk of the card's content.
//                         </p>
//                     </div> 
//                     </div> 
//                 </td>

//                 <td>
//                     <div className="card text-dark bg-warning mb-3 hover-card" style={{ Width: '18rem' }}>
//                                     <div className="card-header">Header</div>
//                     <div className="card-body">
//                         <h5 className="card-title">Info card title</h5>
//                         <p className="card-text">
//                         Some quick example text to build on the card title and make up the bulk of the card's content.
//                         </p>
//                     </div> 
//                     </div> 
//                 </td>

//                 <td>
//                     <div className="card text-dark bg-warning mb-3 hover-card" style={{ Width: '18rem' }}>
//                                     <div className="card-header">Header</div>
//                     <div className="card-body">
//                         <h5 className="card-title">Info card title</h5>
//                         <p className="card-text">
//                         Some quick example text to build on the card title and make up the bulk of the card's content.
//                         </p>
//                     </div> 
//                     </div> 
//                 </td>

//                 <td>
//                     <div className="card text-dark bg-warning mb-3 hover-card" style={{ Width: '18rem' }}>
//                                     <div className="card-header">Header</div>
//                     <div className="card-body">
//                         <h5 className="card-title">Info card title</h5>
//                         <p className="card-text">
//                         Some quick example text to build on the card title and make up the bulk of the card's content.
//                         </p>
//                     </div> 
//                     </div> 
//                 </td>
//             </tr>
//         </tbody>
//         </div>
//     </table>
    

//         </div>

//         </>

    
    
    
//   );
// };

// export default InfoCardComponent;














// import React from 'react';

// const InfoCardComponent = () => {
//   const cardStyles = {
//     maxWidth: '18rem',
//     transition: 'transform 0.3s',
//   };

//   const handleMouseEnter = () => {
//     cardStyles.transform = 'scale(1.05)';
//   };

//   const handleMouseLeave = () => {
//     cardStyles.transform = 'scale(1)';
//   };

//   return (
//    <>
//    <table><tr><td> 
//     <div
//       className="card text-dark bg-info mb-3 hover-card"
//       style={cardStyles}
//       onMouseEnter={handleMouseEnter}
//       onMouseLeave={handleMouseLeave}
//     >
//       <div className="card-header">Header</div>
//       <div className="card-body">
//         <h5 className="card-title">Info card title</h5>
//         <p className="card-text">
//           Some quick example text to build on the card title and make up the bulk of the card's content.
//         </p>
//       </div>
//     </div>
//     </td>
//   <td>
//     <div
//       className="card text-danger bg-info mb-3 hover-card"
//       style={cardStyles}
//       onMouseEnter={handleMouseEnter}
//       onMouseLeave={handleMouseLeave}
//     >
//       <div className="card-header">Header</div>
//       <div className="card-body">
//         <h5 className="card-title">Info card title</h5>
//         <p className="card-text">
//           Some quick example text to build on the card title and make up the bulk of the card's content.
//         </p>
//       </div>
//     </div>
//    </td>
//     <td>
//     <div
//       className="card text-success bg-info mb-3 hover-card"
//       style={cardStyles}
//       onMouseEnter={handleMouseEnter}
//       onMouseLeave={handleMouseLeave}
//     >
//       <div className="card-header">Header</div>
//       <div className="card-body">
//         <h5 className="card-title">Info card title</h5>
//         <p className="card-text">
//           Some quick example text to build on the card title and make up the bulk of the card's content.
//         </p>
//       </div>
//     </div>
//     </td>
//    <td>
//     <div
//       className="card text-primary bg-info mb-3 hover-card"
//       style={cardStyles}
//       onMouseEnter={handleMouseEnter}
//       onMouseLeave={handleMouseLeave}
//     >
//       <div className="card-header">Header</div>
//       <div className="card-body">
//         <h5 className="card-title">Info card title</h5>
//         <p className="card-text">
//           Some quick example text to build on the card title and make up the bulk of the card's content.
//         </p>
//       </div>
//     </div>
//   </td>
//   </tr>
// <tr>
//   <td>

//   </td>
//    <td>
//   </td>
// </tr>
//     </table>
//    </>

//   );
// };

// export default InfoCardComponent;
