
import React from 'react';
//import { useHistory } from 'react-router-dom';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import { useEffect, useState } from 'react';

function AdminProfileupdate() {

    //const history = useHistory();
    const [message,setMessage] =  useState("");
    useEffect(()=>{
      setTimeout(() => 
      {
          setMessage("");
      }, 3000);
  }, [message])

   const handleButtonClick = () => {

     setMessage("Updated Successfull!")
   };

  

    return ( <div >

        <center>
          <table>
            <tbody>
            <tr>
                <td>Name</td>
                <td>
                  <input type="text" value="Name" />
                </td>
            </tr>
              <tr>
                <td>Email</td>
                <td>
                  <input type="text" value="abc@123" />
                </td>
              </tr>

              <tr>
                <td>Password</td>
                <td>
                  <input type="text" value="abc@123" />
                </td>
              </tr>

              <tr>
                <td>Address</td>
                <td>
                  <input type="text" value="Address" />
                </td>
              </tr>

              <tr>
                <td>Mobile Number</td>
                <td>
                  <input type="number" value="MobileNumber" />
                </td>
              </tr>
                
              <tr>
                <td>Gender</td>
                <td>
                  <input type="text" value="Male" />
                </td>
              </tr>


              <tr>
                <td>DateOfBirth</td>
                <td>
                  <input type="datetime" value="" />
                </td>
              </tr>

              <tr>
                <td colSpan="2">
                  <button className='btn btn-success' onClick={handleButtonClick}>Update</button>
                </td>
              </tr>
            </tbody>
          </table>
          <hr/>
          <h1> {message}</h1>
        </center>
      </div> );
}

export default AdminProfileupdate;