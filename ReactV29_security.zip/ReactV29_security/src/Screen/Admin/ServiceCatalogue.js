import React from 'react';
import { useHistory } from 'react-router-dom';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '.././box.css';

function ServiceCatalogue() {
    const history = useHistory();

    const handleEditClick = () => {
        // Handle click for "Your Assigned Orders"
        // You can navigate to a specific route or perform any other action here
        
           history.push('/UpdateServiceCatalogue');
          
    };

    const handleAddClick = () => {
        // Handle click for "Your Assigned Orders"
        // You can navigate to a specific route or perform any other action here
        
           history.push('/ServiceCatalogueAdd');
          
    };

    const handleDeleteClick = () => {
        // Handle click for "Your Assigned Orders"
        // You can navigate to a specific route or perform any other action here
        
           alert('Service Deleted!!');
          
    };

    return (  
        <> 
     <center><h2>Service Catalogue</h2></center>
    <div className="container">
        <br/><br/>
        <button className="btn btn-Success" onClick={handleAddClick}>Add new Service</button>

        <div className="box-container">
                
            <table className="table table-striped table-bordered table-hover table-responsive">
               
                <tr>
                    <th>    
                        Sr. No
                    </th>
                    <th>
                    Service_Id
                    </th>

                    <th>
                        
                    service_Name				
                        
                    </th>
                    
                    <th>
                    
                    cost 	
               
                    </th>
                    
                   
                </tr>
                <tbody>
                <tr>
                    <td>    
                       1
                    </td>
                    <td>
                        100
                    </td>

                    <td>
                        
                    Washing
                        
                    </td>
                    
                    <td>
                    
                    500 	
               
                    </td>
                   
                    <td>
                    
                    <button className="btn btn-warning" onClick={handleEditClick}>Edit</button>

                    </td>
                    <td>
                    
                    <button className="btn btn-danger" onClick={handleDeleteClick}>Delete</button>

                    </td>
                </tr>
                </tbody>

            </table>

        </div>
    </div>
    </>

    );
}

export default ServiceCatalogue;