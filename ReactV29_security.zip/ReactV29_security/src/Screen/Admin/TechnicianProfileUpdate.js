import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import React, { useState, useEffect } from 'react';


function TechnicianProfileUpdate() {

   

    const [message,setMessage] =  useState("");
    useEffect(()=>{
      setTimeout(() => 
      {
          setMessage("");
      }, 3000);
  }, [message])

   const handleButtonClick = () => {

     setMessage("Updated Successfully!")
   };
   

    return ( <div >

        <center>
          <h2>Technician Profile Update</h2>
          <table>
            <tbody>
            <tr>
                <td>Name</td>
                <td>
                  <input type="text" value="Name" />
                </td>
            </tr>
              <tr>
                <td>Email</td>
                <td>
                  <input type="text" value="abc@123" />
                </td>
              </tr>

              <tr>
                <td>Password</td>
                <td>
                  <input type="text" value="abc@123" />
                </td>
              </tr>

              <tr>
                <td>Address</td>
                <td>
                  <input type="text" value="Address" />
                </td>
              </tr>

              <tr>
                <td>Mobile Number</td>
                <td>
                  <input type="number" value="MobileNumber" />
                </td>
              </tr>
                
              <tr>
                <td>Gender</td>
                <td>
                  <input type="text" value="Male" />
                </td>
              </tr>


              <tr>
                <td>DateOfBirth</td>
                <td>
                  <input type="datetime" value="" />
                </td>
              </tr>
              <tr>
                <td>Salary</td>
                <td>
                  <input type="datetime" value="" />
                </td>
              </tr>
              <tr>
                <td>Designation</td>
                <td>
                  <input type="datetime" value="" />
                </td>
              </tr>
              <tr>
                <td>Expertise</td>
                <td>
                  <input type="datetime" value="" />
                </td>
              </tr>
              <tr>
                <td>DOJ</td>
                <td>
                  <input type="datetime" value="" disabled/>
                </td>
              </tr>
              <tr>
                <td colSpan="2">
                  <button className='btn btn-success' onClick={handleButtonClick}>Update</button>
                </td>
              </tr>
             
              
            </tbody>
          </table>
          <hr/>
          <h1>{message}</h1>
        </center>
      </div> );
}

export default TechnicianProfileUpdate;