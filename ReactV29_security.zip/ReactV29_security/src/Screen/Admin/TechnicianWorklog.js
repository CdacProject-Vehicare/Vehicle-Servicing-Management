import React from 'react';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '.././box.css';

function TechnicianWorklog() {

    
    return (  
        <> 
     <center><h2>WorkLog</h2></center>
    <div className="container">
        <br/><br/>
        <div className="box-container">
                
            <table className="table table-striped table-bordered table-hover table-responsive">
               
                <tr>
                    <th>      
                        Sr. No.     
                    </th>
                    <th>
                        Order Id
                    </th>
                    <th>    
                        Description
                    </th>
                    <th>
                        Status
                    </th>
                </tr>
            </table>

            
        </div>
    </div>
    </>

    );
}

export default TechnicianWorklog;