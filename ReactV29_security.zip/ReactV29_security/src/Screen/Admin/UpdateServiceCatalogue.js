import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import React, { useState, useEffect } from 'react';


function UpdateServiceCatalogue() {

   

    const [message,setMessage] =  useState("");
    useEffect(()=>{
      setTimeout(() => 
      {
          setMessage("");
      }, 3000);
  }, [message])

   const handleAddClick = () => {

     setMessage("Updated Successfully!")
   };
   

    return ( <div >

        <center>
          <table>
            <tbody>
            <tr>
                <td>ServiceId</td>
                <td>
                  <input disabled type="number" value="" />
                </td>
            </tr>
              <tr>
                <td>Service Name</td>
                <td>
                  <input type="text" value="" />
                </td>
              </tr>

              <tr>
                <td>Cost</td>
                <td>
                  <input type="number" value="" />
                </td>
              </tr>

              
              <tr>
                <td colSpan="2">
                  <button className='btn btn-success' onClick={handleAddClick}>Update Service</button>
                </td>
              </tr>
             
              
            </tbody>
          </table>
          <hr/>
          <h1>{message}</h1>
        </center>
      </div> );
}

export default UpdateServiceCatalogue;