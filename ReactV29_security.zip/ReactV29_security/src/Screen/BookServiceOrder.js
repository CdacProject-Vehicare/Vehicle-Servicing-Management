
import React from 'react';
import { useHistory } from 'react-router-dom';
import '../../node_modules/bootstrap/dist/css/bootstrap.css';


function BookServiceOrder() {

    const history = useHistory();

   const handleButtonClick = () => {
     history.push("/home");
   };


    return (
    <>
    <div>
        <center>
          <table>
            <tbody>
            <tr>
                <td>ServiceType</td>
                <td>
                  <input type="text" value="" />
                </td>
              </tr>
              <tr>
                <td>Date</td>
                <td>
                  {/* <input type="datetime-local" value="" /> */}
                  <input type="datetime-local" defaultValue="2023-06-01T12:00" />
                </td>
              </tr>
              <tr>
                <td>timeslot</td>
                <td>
                  <input type="text" value="" />
                </td>
              </tr>
              <tr>
                <td>Vehicle</td>
                <td>
                <select class="select">
                      <option value="1">Bike 1</option>
                      <option value="2">Bike 1</option>
                      <option value="3">Bike 1</option>
                      <option value="4">Car 1</option>
                      <option value="5">car 2</option>
                </select>
                </td>
              </tr>
              <tr>
                <td colSpan="2">
                  <button className='btn btn-success' onClick={handleButtonClick}>BookNow</button>
                </td>
              </tr>
            </tbody>
          </table>

        <br/><br/>
        <h1> Select Services</h1>
        <br/><br/>
          <div class="form-check">
            <center>
              <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault" style={{ marginLeft: '850px' }}/>
              <label class="form-check-label" htmlfor="flexCheckDefault" style={{ marginRight: '900px' }}>Denting asd Painting</label>
            </center>
            </div>

          <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" style={{ marginLeft: '850px' }} />
            <label class="form-check-label" for="flexCheckChecked" style={{ marginRight: '900px' }}>AC repairs</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" style={{ marginLeft: '850px' }} />
            <label class="form-check-label" for="flexCheckChecked" style={{ marginRight: '900px' }}>Battery Replacement</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" style={{ marginLeft: '850px' }} />
            <label class="form-check-label" for="flexCheckChecked" style={{ marginRight: '900px' }}>Detailing Services</label>
        </div>

        <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" style={{ marginLeft: '850px' }} />
            <label class="form-check-label" for="flexCheckChecked" style={{ marginRight: '900px' }}>Car spa and Cleaning</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" style={{ marginLeft: '850px' }} />
            <label class="form-check-label" for="flexCheckChecked" style={{ marginRight: '900px' }}>Car Inspection</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" style={{ marginLeft: '850px' }} />
            <label class="form-check-label" for="flexCheckChecked" style={{ marginRight: '900px' }}>Susspension and fitment</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" style={{ marginLeft: '850px' }} />
            <label class="form-check-label" for="flexCheckChecked" style={{ marginRight: '900px' }}>Cluth and Body Repair</label>
        </div>


        <br/><br/>
        <h2> Select TimeSlot</h2>
        <br/>

        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
          <label class="form-check-label" for="inlineRadio1">9:00 - 11:00</label>
        </div>

        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" />
          <label class="form-check-label" for="inlineRadio1">11:00 - 1:00</label>
          <label class="form-check-label" for="inlineRadio2"></label>
        </div>

        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" />
          <label class="form-check-label" for="inlineRadio1">2:00 - 4:00</label>
          <label class="form-check-label" for="inlineRadio2"></label>
        </div>

        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" />
          <label class="form-check-label" for="inlineRadio1">4:00 - 6:00</label>
          <label class="form-check-label" for="inlineRadio2"></label>
        </div>

        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3" disabled />
          <label class="form-check-label" for="inlineRadio3">6:00 - 8:00 (Service NOT available at this Slot)</label>
        </div>

        </center>

        



    </div> 
    </>
    
    );
}

export default BookServiceOrder;