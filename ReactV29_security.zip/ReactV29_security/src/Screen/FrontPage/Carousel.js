
import { useNavigate } from 'react-router-dom';
function Carousel() {
  const navigate =useNavigate()
    return (  <>
    
      <div id="carouselId" className="carousel slide " data-bs-ride="carousel" >
    <ol class="carousel-indicators">
      <li data-bs-target="#carouselId" data-bs-slide-to="0" class="active" aria-current="true" aria-label="First slide"></li>
      <li data-bs-target="#carouselId" data-bs-slide-to="1" aria-label="Second slide"></li>
      <li data-bs-target="#carouselId" data-bs-slide-to="2" aria-label="Third slide"></li>
    </ol>
    <div class="carousel-inner" role="listbox">
      <div class="carousel-item active">
        <img src="http://localhost:3000/ImageFolder/image2.png" class="w-100 d-block" alt="First slide"/>
      </div>
      
      <div class="carousel-item">
        <img src="http://localhost:3000/ImageFolder/image4.png" class="w-100 d-block" alt="Second slide"/>
      </div>
      <div class="carousel-item">
        <img src="http://localhost:3000/ImageFolder/image2.png"  class="w-100 d-block" alt="Third slide"/>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselId" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselId" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
      </button>
  </div>
    
        <a class="left carousel-control" href="#carousel-id" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
        <a class="right carousel-control" href="#carousel-id" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
        </>
    );
}

export default Carousel;


// function Carousel() {
//     return (  

//       <>
//       <div id="carouselExampleAutoplaying" className="carousel slide" data-bs-ride="carousel">
//           <div className="carousel-inner">
//             <div className="carousel-item active">
//               <img src="http://localhost:3000/ImageFolder/image4.png" style={{height:'80%',width:'80%' } }  className="d-block w-100" alt="..."/>
//             </div>
//             <div className="carousel-item" >
//               <img src="http://localhost:3000/ImageFolder/image11.jpg" className="d-block w-100" alt="..." style={{height:'80%',width:'100%' }}/>
//             </div>
//             <div className="carousel-item">
//               <img src="http://localhost:3000/ImageFolder/image2.png" className="d-block w-100" alt="..." style={{height:'80%',width:'100%' }}/>
//             </div>
            
//       </div>

//   <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev" style={{height:350}}>
//     <span className="carousel-control-prev-icon" aria-hidden="true"></span>
//     <span className="visually-hidden">Previous</span>
//   </button>
//   <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next" style={{height:350}}>
//     <span className="carousel-control-next-icon" aria-hidden="true"></span>
//     <span className="visually-hidden">Next</span>
//   </button>
// </div>
//       </>

//     );
// }

// export default Carousel;

// onClick={()=>navigate('/subCategory/1')}