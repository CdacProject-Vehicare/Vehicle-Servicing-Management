//import '../node_modules/bootstrap/dist/css/bootstrap.css';
import '../../node_modules/bootstrap/dist/css/bootstrap.css';
import { useHistory } from 'react-router-dom';      // Put url in 
import Carousel from './FrontPage/Carousel';
import Navbar from './FrontPage/Navbar';
import CardGrid from './FrontPage/AllServices';
import AllServices1 from './FrontPage/ALlService1';
import Footer from './Footer';
import Sidebar from './Sidebar';

function Home() {
  
    const history = useHistory();

    const handleButtonClick = () => {
      history.push("/bookserviceorder");
    };
 

    return (<>
     <div>
        <h1> Home Page </h1>

        
        
        <Navbar></Navbar>
       <center><Carousel></Carousel></center>
      <hr></hr>
       <AllServices1></AllServices1>
        
       <div>
       <CardGrid></CardGrid>
       </div>
       <br/><br/>      
    </div>
        <Footer></Footer>
    </>
      

     );
}

export default Home;