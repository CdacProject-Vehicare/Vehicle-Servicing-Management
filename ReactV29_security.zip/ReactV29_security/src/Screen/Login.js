import React from 'react';
import { useHistory } from 'react-router-dom';

function Login() {
   //const history = useHistory();
   const history = useHistory();

   const handleButtonClick = () => {
     history.push("/home");
   };


  return (
    <div>

      <center>
        <table>
          <tbody>
            <tr>
              <td>EmailId</td>
              <td>
                <input type="text" value="abc@123" />
              </td>
            </tr>
            <tr>
              <td>Password</td>
              <td>
                <input type="password" value="abc@123" />
              </td>
            </tr>
            <tr>
              <td colSpan="2">
                <button onClick={handleButtonClick}>Login</button>
              </td>
            </tr>
          </tbody>
        </table>
      </center>
    </div>
  );
}

export default Login;
