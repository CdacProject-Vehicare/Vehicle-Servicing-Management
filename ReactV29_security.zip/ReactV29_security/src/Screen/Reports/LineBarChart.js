import React, { useEffect, useRef } from 'react';
import ApexCharts from 'apexcharts';

function LineBarChart() {
  const chartRef = useRef(null);

  useEffect(() => {
    const options = {
      chart: {
        height: 350,
        type: "line",
      },
      series: [
        {
          name: "Customer",
          type: "line",
          data: [23, 56, 34, 65, 43, 78, 45, 60, 80]
        },
        {
          name: " Revenue",
          type: "bar",
          data: [23, 56, 34, 65, 43, 78, 45, 60, 80]
         

        },
        {
          name: "",
          type: "bar",
          data: [0, 0, 0, 0, 0, 0, 0, 0, 0]
  

        },
        {
          name: "Bar Series2",
          type: "bar",
          data: [23, 56, 34, 65, 43, 78, 45, 60, 80]
  

        }
      ],
      xaxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep']
      }
    };

    if (chartRef.current) {
      const chart = new ApexCharts(chartRef.current, options);
      chart.render();
    }

    // Cleanup the chart on component unmount
    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, []);

  return <div id="apexcharts-line-bar" ref={chartRef} />;
}

export default LineBarChart;
