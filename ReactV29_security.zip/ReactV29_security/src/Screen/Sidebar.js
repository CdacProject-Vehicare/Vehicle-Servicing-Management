import React from 'react';
import { useNavigate } from 'react-router-dom';

const Sidebar = () => {
    
  const navigate = useNavigate();


    const handleAllAssignedOrdersClick = () => {
        // Handle click for "Your Assigned Orders"
        // You can navigate to a specific route or perform any other action here
        
            navigate.push("/allorderdetails");
          
    };
  return (
    <>
     
      <button
        className="btn btn-primary"
        type="button"
        data-bs-toggle="offcanvas"
        data-bs-target="#offcanvasWithBothOptions"
        aria-controls="offcanvasWithBothOptions"
      >
        SideBar
      </button>

      <div
        className="offcanvas offcanvas-start"
        data-bs-scroll="true"
        data-bs-backdrop="false"
        tabIndex="-1"
        id="offcanvasScrolling"
        aria-labelledby="offcanvasScrollingLabel"
      >
        <div className="offcanvas-header">
          <h5 className="offcanvas-title" id="offcanvasScrollingLabel">
            Colored with scrolling
          </h5>
          <button
            type="button"
            className="btn-close text-reset"
            data-bs-dismiss="offcanvas"
            aria-label="Close"
          ></button>
        </div>
        <div className="offcanvas-body">
          <p>Try scrolling the rest of the page to see this option in action.</p>
        </div>
      </div>

      <div
        className="offcanvas offcanvas-start"
        tabIndex="-1"
        id="offcanvasWithBackdrop"
        aria-labelledby="offcanvasWithBackdropLabel"
      >
        <div className="offcanvas-header">
          <h5 className="offcanvas-title" id="offcanvasWithBackdropLabel">
            Offcanvas with backdrop
          </h5>
          <button
            type="button"
            className="btn-close text-reset"
            data-bs-dismiss="offcanvas"
            aria-label="Close"
          ></button>
        </div>
        <div className="offcanvas-body">
          <p>.....</p>
        </div>
      </div>

      <div
        className="offcanvas offcanvas-start"
        data-bs-scroll="true"
        tabIndex="-1"
        id="offcanvasWithBothOptions"
        aria-labelledby="offcanvasWithBothOptionsLabel"
      >
        <div className="offcanvas-header">
          <h5 className="offcanvas-title" id="offcanvasWithBothOptionsLabel">
            Backdroped with scrolling
          </h5>
          <button
            type="button"
            className="btn-close text-reset"
            data-bs-dismiss="offcanvas"
            aria-label="Close"
          ></button>
        </div>



        {/* <div className="offcanvas-body"> */}
        
            <div class="offcanvas-body">



                <div class="dropdown mt-3">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown">
                        Dropdown button
                    </button>
                    
    
                    <a class="dropdown-item" href="/allorderdetails">All order Details</a>
                    <a class="dropdown-item" href="/AdminProfileupdate">Edit Self Profile</a>
                    <a class="dropdown-item" href="/TechnicianProfileUpdate">Update Technician Profile</a>
                    <a class="dropdown-item" href="/piechart">Generate Report</a>
                    <a class="dropdown-item" href="/TechnicianWorklog">Work Login</a>
                    <a class="dropdown-item" href="/servicecatalogue">Service catalogue</a>
                    <a class="dropdown-item" href="/Inventory">Update Inventory</a>
                    
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <li><a class="dropdown-item" href="#">Action</a></li>
                        <li><a class="dropdown-item" href="#">Another action</a></li>
                        <li><a class="dropdown-item" href="#">Something else here</a></li>
                    </ul>
                </div>
        </div>

        {/* </div> */}








      </div>
    </>
  );
};

export default Sidebar;