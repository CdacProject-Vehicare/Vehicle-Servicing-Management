import React from 'react';
//import { useHistory } from 'react-router-dom';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '.././box.css';

function TechnicianAssignedOrders() {
    //const history = useHistory();

    const handleSaveClick = () => {
        // Handle click for "Your Assigned Orders"
        // You can navigate to a specific route or perform any other action here
        
           alert('Records Saved!!');
          
    };

    return (  
        <> 
     
    <div className="container">
        <br/><br/>
        <div className="box-container">
                
            <table className="table table-striped table-bordered table-hover table-responsive">
                <thead>Booking Details</thead>
                <tr>
                    <th>
                        
                    Booking Date
                        

                        
                    </th>
                    <th>
                    
                    Status
                
                    </th>

                    <th>
                        
                        Vehicle Number
                        
                    </th>
                    
                    <th>
                    
                    Comments
               
                    </th>
                    <th>
                    
                    Expected Completion time
                    
                    </th>
                    <th>
                    
                    Part name
                    
                    </th>

                    <th>
                    
                    Price
                    </th>
                   

                </tr>
            </table>

            <button className="btn btn-success" onClick={handleSaveClick}>Save</button>

        </div>
    </div>
    </>

    );
}

export default TechnicianAssignedOrders;