
import React from 'react';
import { useHistory } from 'react-router-dom';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';


function TechnicianRegistration() {

    const history = useHistory();

   const handleButtonClick = () => {
     history.push("/Login");
   };

  

    return ( <div >

        <center>
          <table>
            <tbody>
            <tr>
                <td>Name</td>
                <td>
                  <input type="text" value="Name" />
                </td>
            </tr>
              <tr>
                <td>Email</td>
                <td>
                  <input type="text" value="abc@123" />
                </td>
              </tr>

              <tr>
                <td>Password</td>
                <td>
                  <input type="text" value="abc@123" />
                </td>
              </tr>

              <tr>
                <td>Address</td>
                <td>
                  <input type="text" value="Address" />
                </td>
              </tr>

              <tr>
                <td>Mobile Number</td>
                <td>
                  <input type="number" value="MobileNumber" />
                </td>
              </tr>
                
              <tr>
                <td>Gender</td>
                <td>
                  <input type="text" value="Male" />
                </td>
              </tr>


              <tr>
                <td>DateOfBirth</td>
                <td>
                  <input type="datetime" value="" />
                </td>
              </tr>

              <tr>
                <td colSpan="2">
                  <button className='btn btn-success' onClick={handleButtonClick}>Submit</button>
                </td>
              </tr>
            </tbody>
          </table>
        </center>
      </div> );
}

export default TechnicianRegistration;