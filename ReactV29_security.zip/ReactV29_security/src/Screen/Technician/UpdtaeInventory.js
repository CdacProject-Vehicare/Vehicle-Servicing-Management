import React from 'react';
import { useHistory } from 'react-router-dom';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '.././box.css';

function UpdateInventory() {
    const history = useHistory();

    const handleEditClick = () => {
        // Handle click for "Your Assigned Orders"
        // You can navigate to a specific route or perform any other action here
        
           history.push('');
          
    };

    const handleDeleteClick = () => {
        // Handle click for "Your Assigned Orders"
        // You can navigate to a specific route or perform any other action here
        
           alert('Records Updated!!');
          
    };

    return (  
        <> 
     <center><h2>All Technician Details</h2></center>
    <div className="container">
        <br/><br/>
        <div className="box-container">
                
            <table className="table table-striped table-bordered table-hover table-responsive">
               
                <tr>
                    <th>    
                        Sr. No
                    </th>
                    <th>
                        ProductId
                    </th>

                    <th>
                        
                    PraductName				
                        
                    </th>
                    
                    <th>
                    
                    AvailableQuantity 	
               
                    </th>
                    <th>
                    
                    safetyStock	
                    
                    </th>
                    <th>
                    
                    productPrice
                    </th>

                   
                </tr>
                <tbody>
                <tr>
                    <td>    
                       1
                    </td>
                    <td>
                        100
                    </td>

                    <td>
                        
                    Name 1
                        
                    </td>
                    
                    <td>
                    
                    abc@123 	
               
                    </td>
                    <td>
                    
                    123	
                    
                    </td>
                    <td>
                    
                    pune
                    </td>

                   
                    <td>
                    
                    <button className="btn btn-warning" onClick={handleEditClick}>Edit</button>

                    </td>
                    <td>
                    
                    <button className="btn btn-danger" onClick={handleDeleteClick}>Delete</button>

                    </td>
                </tr>
                </tbody>

            </table>

        </div>
    </div>
    </>

    );
}

export default UpdateInventory;