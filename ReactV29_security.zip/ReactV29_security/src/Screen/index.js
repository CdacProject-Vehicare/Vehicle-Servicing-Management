import { BrowserRouter as Router,Route, Switch} from "react-router-dom"; 
import Home from './Home';
import Login from "./Login";
import LoginSample  from "./LoginSample";
import UserRegistration from "./UserRegistration";
import BookServiceOrder from "./BookServiceOrder";
//import TechnicianRegistration from "./Technician/TechnicianRegistration";
import TechnicianAccount from "./Technician/TechnicianAccount";
import TechnicianAssignedOrders from "./Technician/TechnicianAssignedOrders";
import AllAssignedOrders from "./Admin/AllAssignedOrders";
import AdminProfileupdate from "./Admin/AdminProfileUpdate";
import AllTechnicianDetails from "./Admin/AllTechnicianDetails";
import TechnicianWorklog from "./Admin/TechnicianWorklog";
import TechnicianProfileUpdate from "./Admin/TechnicianProfileUpdate";
import InventoryUpdate from "./Admin/InventoryUpdate";
import Inventory from "./Admin/Inventory";
import ServiceCatalogue from "./Admin/ServiceCatalogue";
import ServiceCatalogueAdd from "./Admin/ServiceCatalogueAdd";
import UpdateServiceCatalogue from "./Admin/UpdateServiceCatalogue";
import AddNewProductinInventory from "./Admin/AddNewProductinInventory";
import AdminAccount from "./Admin/AdminAccount";
import PieChart from "./Reports/PieChart";
import LineBarChart from "./Reports/LineBarChart";
import DoughnutChart from "./Reports/DonutChart"; 
import Footer from "./Footer";
import ShowServiceDetails from "./FrontPage/ShowServiceDetails";
import EditTechnicianProfile from "../components/EditTechnicianProfile";


function Controller() {
    return ( 

        <Router>

            <Switch>
                debugger;
            <Route exact path= "/LoginSample" component = {LoginSample}/>
            <Route exact path= "/login" component = {Login}/>
            <Route exact path= "/" component = {Home}/>      
            <Route exact path= "/home" component = {Home}/>
            <Route exact path="/userreg" component={UserRegistration}></Route>
            <Route exact path="/bookserviceorder" component={BookServiceOrder}></Route>
            {/* <Route exact path="/TechnicianRegistration" component={TechnicianRegistration}></Route> */}
            <Route exact path="/EditTechnicianProfile" component={EditTechnicianProfile}></Route>

            <Route exact path="/TechnicianAccount" component={TechnicianAccount}></Route>
            <Route exact path="/TechnicianAssignedOrders" component={TechnicianAssignedOrders}></Route>
            <Route exact path="/allOrderDetails" component={AllAssignedOrders}></Route>
            <Route exact path="/AdminProfileupdate" component={AdminProfileupdate}></Route>
            <Route exact path="/TechnicianProfileUpdate" component={TechnicianProfileUpdate}></Route>
            <Route exact path="/AllTechnicianDetails" component={AllTechnicianDetails}></Route>
            <Route exact path="/TechnicianWorklog" component={TechnicianWorklog}></Route>           
            <Route exact path="/InventoryUpdate" component={InventoryUpdate}></Route>
            <Route exact path="/Inventory" component={Inventory}></Route>
            <Route exact path="/ServiceCatalogue" component={ServiceCatalogue}></Route>           
            <Route exact path="/ServiceCatalogueAdd" component={ServiceCatalogueAdd}></Route> 
            <Route exact path="/UpdateServiceCatalogue" component={UpdateServiceCatalogue}></Route>
            <Route exact path="/AdminAccount" component={AdminAccount}></Route>
            
            <Route exact path="/AddNewProductinInventory" component={AddNewProductinInventory}></Route>

            <Route exact path="/PieChart" component={PieChart}></Route>
            <Route exact path="/linebarGraph" component={LineBarChart}></Route>
            <Route exact path="/DoughnutChart" component={DoughnutChart}></Route>
            <Route exact path="/ShowServiceDetails" component={ShowServiceDetails}></Route>
        
        </Switch>
        

        
    </Router>



     );
}

export default Controller;