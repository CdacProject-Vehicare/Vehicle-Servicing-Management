import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'

import { insertItem } from '../../services/Inventory-Service';

function AddNewItemInInventory() {

  const [inventoryName, setInventoryName] = useState('')
  const [safetyStock, setSafetyStock] = useState('')
  const [availableStock, setAvailableStock] = useState('')
  const [invetoryPrice, setInvetoryPrice] = useState('')

  const navigate = useNavigate()

  const addNewItem = async () => {
    if (inventoryName.length == '') {
      toast.error('Please enter Item Name')
    } else if (safetyStock.length == '') {
      toast.error('Please enter safety stock of item')
    } else if (availableStock.length == '') {
      toast.error('Please enter Available Stock')
    } else if (invetoryPrice.length == '') {
      toast.error('Please item price')
    }  else {
      // call register api
      const response = await insertItem(inventoryName, safetyStock,availableStock,invetoryPrice)
      console.log(response)
      if(response){
        
        console.log(response)
        toast.success('Item added successfully ')
        navigate('/InventoryDetails')
      } else {
        toast.error('Product failed to add')
        navigate('/InventoryDetails')
      }
    }
  }
   
   return (
    <div>
      <h1 style={{ textAlign: 'center', margin: 10 }}>Add New Item</h1>

      <div className='row'>
        <div className='col'></div>
        <div className='col'>
          <div className='form'>

            <div className='mb-3'>
              <label htmlFor=''>Item Name</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setInventoryName(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Safety Stock</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setSafetyStock(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Available stock</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setAvailableStock(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Item Price</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setInvetoryPrice(e.target.value)
                }}
              />
            </div>
            
            <div className='mb-3'>
              {/* <div className='mb-3'>
                Don't have an account? <Link to='/register'>Register here</Link>
              </div> */}
              <button onClick={addNewItem} className='btn btn-success'>
                Launch
              </button>
            </div>
          </div>
        </div>
        <div className='col'></div>
      </div>
    </div>
  )
}

export default AddNewItemInInventory;