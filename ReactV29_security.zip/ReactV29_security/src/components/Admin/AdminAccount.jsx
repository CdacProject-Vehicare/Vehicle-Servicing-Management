import React from "react";
import { useNavigate } from "react-router-dom";
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../../CssFiles/box.css';
//import { Link } from "react-router-dom";
import { Container, Row, Col } from "react-bootstrap";
import adminDashboard from "../../CssFiles/adminDashboard.css";
import NavigationBar from "../navigationBar";

function AdminDashboard() {

  const navigate = useNavigate()

  const handleAllAssignedOrdersClick = () => {
    // Handle click for "Your Assigned Orders"
    // You can navigate to a specific route or perform any other action here
    
        navigate("/AllOrdersDetails");
      
  };

  const handleEditProfileClick = () => {
    // Handle click for "Edit mProfile"
    // You can navigate to a specific route or perform any other action here
    navigate("/EditAdminProfile");
  };

  const handleUpdateTechnicianClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/AllTechnicianDetails");
  };

  const handleGenerateReportClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/piechart");
  };

  const handleWorkLogClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/empdropdown");
  };

  const handleUpdateServicesClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/ProductCatalogue");
  };

  const handleUpdateTimeSlotsClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/servicecatalogue");
  };
  const handleAddVehicleToOrderClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/AddNewVehicleToOrder");
  };


  const handleUpdateInventoryClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
  //  navigate("/Inventory");
    navigate('/InventoryDetails')
  };

  const handleGetAllFeedbackClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
  //  navigate("/Inventory");
    navigate('/AllFeedbackDetails')
  };

  const handleAddFeedbackClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
  //  navigate("/Inventory");
    navigate('/AddFeedbackToOrder')
  };


  const addtocart = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/productgallery");
  };

  return (
    <Container>
      <NavigationBar></NavigationBar>
      <Row className="admin-dashboard">
        <Col xs={12} className="text-center"> 
        <h2 className="admin-title">Welcome Admin!</h2>  
        </Col>

        <Row className="text-center"> 
          <div className="admin-options">
            <Col className="options-column">
              
              <Row className="admin-option" onClick={addtocart}>
                book Order
              </Row>

              {/* <Row className="admin-option" onClick={handleAddVehicleToOrderClick}>
                Add vehicle
              </Row> */}

              {/* <Row className="admin-option" onClick={handleAddFeedbackClick}>
                Add all feedback
              </Row> */}
  
              <Row className="admin-option" onClick={handleAllAssignedOrdersClick}>
                Admin Dashboard
              </Row>

              <Row className="admin-option" onClick={handleEditProfileClick}>
                Edit Self Profile
              </Row>

              <Row className="admin-option" onClick={handleUpdateTechnicianClick}>
                Update Technician Profile
              </Row>
            </Col>

            <Col className="options-column" >
              
              <Row className="admin-option" onClick={handleGenerateReportClick}>
                Generate Report
              </Row>

              <Row className="admin-option" onClick={handleWorkLogClick}>
                Work-Log
              </Row>

              <Row className="admin-option" onClick={handleGetAllFeedbackClick}>
                Get all feedback
              </Row>

              <Row className="admin-option" onClick={handleUpdateServicesClick}>
                Get all service
              </Row>

              {/* <Row className="admin-option" onClick={handleUpdateTimeSlotsClick}>
                Update Time-slots
              </Row> */}

              <Row className="admin-option" onClick={handleUpdateInventoryClick}>
                Inventory Status
              </Row>
            </Col>
          </div>
        </Row>
      </Row>

      {/* <Row>

      </Row> */}
    </Container>
  );
}

export default AdminDashboard;


////////////////pratik///////////////////////////////////
// import React from 'react';
// import { useNavigate } from 'react-router-dom';
// import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
// import '../../CssFiles/box.css';
// import Sidebar from '../../Screen/Sidebar';
// function AdminAccount() {

//   const navigate = useNavigate()
  

  
//   const handleAllAssignedOrdersClick = () => {
//     // Handle click for "Your Assigned Orders"
//     // You can navigate to a specific route or perform any other action here
    
//         navigate("/AllOrdersDetails");
      
// };

//   const handleEditProfileClick = () => {
//     // Handle click for "Edit mProfile"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/AdminProfileupdate");
//   };

//   const handleUpdateTechnicianClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/TechnicianProfileUpdate");
// };

// const handleGenerateReportClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/piechart");
// };

// const handleWorkLogClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/empdropdown");
// };

// const handleUpdateServicesClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/servicecatalogue");
// };

// const handleUpdateTimeSlotsClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/servicecatalogue");
// };
// const handleAddVehicleToOrderClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/AddNewVehicleToOrder");
// };


// const handleUpdateInventoryClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//   //  navigate("/Inventory");
//     navigate('/InventoryDetails')
// };


// const handleGetAllFeedbackClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//   //  navigate("/Inventory");
//     navigate('/AllFeedbackDetails')
// };

// const handleAddFeedbackClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//   //  navigate("/Inventory");
//     navigate('/AddFeedbackToOrder')
// };


// const addtocart = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/productgallery");
// };





//   return (<> 
//   <div><Sidebar></Sidebar></div>
//    <center> <h1>Your Account</h1></center>   
//     <div className="container">
//         <br/><br/>
//         <div className="box-container">
        
//         <div className="box" onClick={addtocart}>
//                     book Order
//         </div>

//         <div className="box" onClick={handleAddVehicleToOrderClick}>
//                     Add vehicle
//         </div>

//         <div className="box" onClick={handleAddFeedbackClick}>
//                    Add all feedback
//         </div>

//             <table>
//                 <tr>
//                     <td>
//                         <div className="box" onClick={handleAllAssignedOrdersClick}>
//                     All Assigned Orders
//                     </div>

                        
//                     </td>
//                     <td>
//                     <div className="box" onClick={handleEditProfileClick}>
//                     Edit Self Profile
//                 </div>
//                     </td>

//                     <td>
//                         <div className="box" onClick={handleUpdateTechnicianClick}>
//                         Update Technician Profile
//                         </div>
//                     </td>
//                     </tr>


//                     <tr>
//                     <td>
//                     <div className="box" onClick={handleGenerateReportClick}>
//                     Generate Report
//                 </div>
//                     </td>
//                     <td>
//                     <div className="box" onClick={handleWorkLogClick}>
//                     Work-Log
//                     </div>
//                     </td>
//                     <td>
//                     <div className="box" onClick={handleGetAllFeedbackClick}>
//                         Get all feedback
//                     </div>
//                     </td>
//                     </tr>
//                     <tr>
//                     <td>
//                         <div className="box" onClick={handleUpdateServicesClick}>
//                         Update Services
//                         </div>
//                     </td>

//                     <td>
//                         <div className="box" onClick={handleUpdateTimeSlotsClick}>
//                         Update Time-slots
//                         </div>
//                     </td>

//                     <td>
//                         <div className="box" onClick={handleUpdateInventoryClick}>
//                         Update Inventory
//                         </div>
//                     </td>

//                 </tr>
//             </table>

//         </div>
//     </div>
//     </>

//   );
// }

// export default AdminAccount;




// // import React from 'react';
// // import { usenavigate } from 'react-router-dom';
// // import '../../node_modules/bootstrap/dist/css/bootstrap.css';
// // import './box.css';
// // function TechnicianAccount() {
// //     return (  
// //         <div className="container" >
      
// //         <div className="table-responsive">
// //             <table className="table table-hover">
// //                 <tbody>
// //                     <tr>
// //                         <td >
// //                             Your Assignd Orders
// //                         </td>
// //                         <td >
// //                            Edit Profile
// //                         </td>
// //                         <td >
// //                            Update Inventory
// //                            technicalaccount       </td>
// //                     </tr>
// //                 </tbody>
// //             </table>    
// //         </div>
    
// //     </div>
// //     );
// // }

// // export default TechnicianAccount;