import React from 'react';
//import { useHistory } from 'react-router-dom';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../../CssFiles/box.css';
import InfoCardComponent from '../../Screen/Admin/AdminDashboard';
//import LineBarChart from '../../Screen/Reports/LineBarChart';
import Sidebar from '../../Screen/Sidebar';


function AllAssignedOrders() {
    //const history = useHistory();

    const handleSaveClick = () => {
        // Handle click for "Your Assigned Orders"
        // You can navigate to a specific route or perform any other action here
        
           alert('Records Updated!!');
          
    };

    return (  
        <> 
        <div><Sidebar></Sidebar></div>
        <InfoCardComponent></InfoCardComponent>
        <br/>
     <center><h2>All Order Summary</h2></center>
    <div className="container">
        {/* <LineBarChart></LineBarChart> */}

        <br/><br/>
        <div className="table-responsive">
                
            <table className="table table-bordered ">
               
                <tr className='hover'>
                    <th>      
                        Sr. No.     
                    </th>
                    <th>
                        Order Id
                    </th>
                    <th>    
                        Vehicle Id    
                    </th>
                    <th>
                        Service_Id
                    </th>
                    <th>
                        Date&TimeOfServiceOrder
                    </th>
                    <th>
                        TimeStampOfBooking
                    </th>
                    <th>
                        Status
                    </th>
                    <th> 
                        (EmpId)AssignedTo
                    </th>
                    <th>
                        Inventory.ProductId
                    </th>
                    <th>
                        PurchasedQty
                    </th>
                    <th>
                        PaymentStatus
                    </th>
                </tr>

                <tr className='tr-hover'>
                    <td>      
                       1  
                    </td>
                    <td>  
                        1001
                    </td>
                    <td>    
                        V1    
                    </td>
                    <td>
                        S1
                    </td>
                    <td>
                       04/07/2023
                    </td>
                    <td>
                        04/07/2023
                    </td>
                    <td>
                        Pending
                    </td>
                    <td> 
                        Emp 1
                    </td>
                    <td>
                       P1
                    </td>
                    <td>
                        5
                    </td>
                    <td>
                        Pending
                    </td>
                </tr>

            </table>

            <button className="btn btn-warning" onClick={handleSaveClick}>Save</button>

        </div>
    </div>
    </>

    );
}

export default AllAssignedOrders;