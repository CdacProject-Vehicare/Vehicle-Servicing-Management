// import React from 'react';
// import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
// import '.././../CssFiles/box.css';
// import {  useNavigate } from 'react-router-dom'
// //import { getAllTechnicianDetails } from '../../services/user';
// import { useEffect, useState } from 'react'
// import { toast } from 'react-toastify'
// import { getAllFeedbackDetails } from '../../services/feedback-service ';



// function AllFeedbackDetails() {
//     //const history = useHistory();
//     const navigate = useNavigate()
//     //const [products, setProducts] = useState([])
//     const [feedbackDetails, setFeedbackDetails] = useState([])
//     var index = 0;
    
//   useEffect(() => {
//     // get the list of products from server
//     console.log("in component did mount")
//     loadFeedbackDetails()
//   }, [])

//   const loadFeedbackDetails = async () => {
//     const response = await getAllFeedbackDetails()
//     //if (response['status'] === 'success') {
//       if(true){
//         console.log("in the All feednack Details page");
//         console.log(response)
//         setFeedbackDetails(response.data)
//         console.log("technicial Details-------------"+feedbackDetails)
//     } else {
//       toast.error('Error while calling get /technicialDetails api')
//     }
//   }

//     // const handleEditClick = () => {        
//     //   navigate('/src/components/Technician/EditTechnicianProfile.jsx')
//     // };

//     // const removeTechnician = async (technicianId) => {
//     //     // call register api
//     //     const response = await removeTechnicianByIdApi(technicianId)
//     //     console.log(response)
//     //     loadTechnicianDetails()
//     //     toast.success('Technician is deleted successfully ')
//     // };
       
          
//   //  };
//     return(

//         <div>
//           <h1 style={{ textAlign: 'center', margin: 10 }}>All feedback Details</h1>
//           <table className='table table-bordered'>
//           <thead>
//                   <tr >
//                     <th>Sr. No</th>
//                     <th>orderId</th>
//                     <th>Feedback Date</th>
//                     <th>rating</th>
//                     <th>remarks</th>
                    
//                     {/* <th>Salary</th>
//                     <th>Location</th>
//                     <th>Department</th>
//                     <th>Designation</th>
//                     <th>Role</th>
//                     <th>Edit</th>
//                     <th>Delete</th> */}
//                   </tr>
//                 </thead>
//             <tbody>
//               {feedbackDetails.map((feedback) => {
//                 index = index + 1
//                 return (
//                     <tr key={feedback.technicianId}>
//                     <td>{index}</td>
//                     <td>{feedback.feedbackId}</td>
//                     <td>{feedback.feedbackDate}</td>
//                     <td>{feedback.rating}</td>
//                     <td>{feedback.remarks}</td>

                   
//                     {/* <td>{technician.salary}</td>
//                     <td>{technician.location}</td>
//                     <td>{technician.department}</td>
//                     <td>{technician.designation}</td>
//                     <td>{technician.role}</td> */}
//                     {/* <td>
//                       <button className="btn btn-warning" onClick={handleEditClick}>Edit</button>
//                     </td>
//                     <td>
//                       <button className="btn btn-danger" onClick={()=>{removeTechnician(technician.technicianId)}}>Delete</button>
//                     </td> */}
//                   </tr>
//                 );
//               })}
//             </tbody>
//           </table>
//         </div>
        
//         )
// }
// export default AllFeedbackDetails