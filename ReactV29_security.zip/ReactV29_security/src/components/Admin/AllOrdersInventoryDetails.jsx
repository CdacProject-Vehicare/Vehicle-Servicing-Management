
import React, { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import { getOrdersInventoryList } from '../../services/orders';
import { useParams } from 'react-router-dom';
import { MDBTable, MDBTableHead, MDBTableBody } from 'mdb-react-ui-kit';


function GetAllOrdersInventoryDetailsList() {
  const [ordersDetails, setOrdersDetails] = useState([]);
  const { id } = useParams();

  useEffect(() => {
    loadOrdersInventoryDetails();
  }, []);

  const loadOrdersInventoryDetails = async () => {
    try {
      const response = await getOrdersInventoryList(id);
      if (response) {
        setOrdersDetails(response.data);
      } else {
        toast.error('No inventory used for this order');
      }
    } catch (error) {
      console.error('Error while loading orders:', error);
    }
  };

  return (
    <div>
      <h1 style={{ textAlign: 'center', margin: 10 }}>Inventory Used Details</h1>
      <MDBTable bordered hover style={{ marginTop: 50 }}>
        <MDBTableHead dark>
          <tr>
            <th>Order ID</th>
            <th>Service Name</th>
            <th>Inventory Name</th>
            <th>Quantity Used</th>
          </tr>
        </MDBTableHead>
        <MDBTableBody>
          {ordersDetails.map((order) => (
            <tr key={order.orderId}>
              <td>{order.orderId}</td>
              <td>{order.productName}</td>
              <td>{order.inventoryName}</td>
              <td>{order.qtyUsed}</td>
            </tr>
          ))}
        </MDBTableBody>
      </MDBTable>
    </div>
  );
}

export default GetAllOrdersInventoryDetailsList;
















// import React, { useEffect, useState } from 'react';
// import { toast } from 'react-toastify';
// import { getOrdersInventoryList } from '../../services/orders';
// import { useParams } from 'react-router-dom';

// function GetAllOrdersInventoryDetailsList() {
//   const [ordersDetails, setOrdersDetails] = useState([]);
//   const {id} = useParams();
//   useEffect(() => {
//     loadOrdersInventoryDetails();
//   }, []);

//   const loadOrdersInventoryDetails = async () => {
//     try {
//       console.log(id)
//       const response = await getOrdersInventoryList(id)
//       if (response) {
//         const ordersData = response.data
//         setOrdersDetails(ordersData)
//       } else {
//         toast.error('Error while calling get /OrdersInventoryApi api');
//       }
//     } catch (error) {
//       console.error('Error while loading orders:', error);
//     }
//   };

//   // const handleOrderUpdate = (orderId) => {
//   //   // Handle edit logic for the specific order
//   //   console.log('Edit order with ID:', orderId);
//   // };

//   // const handlePaymentUpdate = (orderId) => {
//   //   // Handle delete logic for the specific order
//   //   console.log('Delete order with ID:', orderId);
//   // };


//   // const handleinventorydetails = (orderDetailsId) => {
//   //   // Handle delete logic for the specific order
//   //   console.log('AddOrRemove inventory order with orderdetails ID:', orderDetailsId);
//   // };

//   // const handleUpdateinventoryUsed = (orderDetailsId) => {
//   //   // Handle delete logic for the specific order
//   //   console.log('Update inventory order with orderdetails ID:', orderDetailsId);
//   // };

//   return (
//     <div>
//     <h1 style={{ textAlign: 'center', margin: 10 }}>Order Details</h1>
//     <table className='table' style={{ marginTop: 50 }}>
//       <thead>
//         <tr>
//           <th>Customer First Name</th>
//           <th>Customer Last Name</th>
//           <th>Order ID</th>
//           <th>Payment Status</th>
//           <th>Price</th>
//           <th>Product Name</th>
//           <th>Vehicle Name</th>
//           <th>Vehicle Number</th>
         
//         </tr>
//       </thead>
//       <tbody>
//         {ordersDetails.map((od) => (
//           <tr key={od.orderId}>
//             <td>{od.customerFirstname}</td>
//             <td>{od.customerLastName}</td>
//             <td>{od.orderId}</td>
//             <td>{od.paymentstatus}</td>
//             <td>{od.price}</td>
//             <td>{od.productName}</td>
//             <td>{od.vehicleName}</td>
           
            
//           </tr>
//         ))}
//       </tbody>
//     </table>
//   </div>
//   );
// }

// export default GetAllOrdersInventoryDetailsList;







// import { useEffect, useState } from 'react'
// import { toast } from 'react-toastify'
// import { getOrdersList }  from '../../services/orders'
// import { constants } from '../../utils/constants'
// function GetAllOrdersDetailsList() {
//   const [ordersDetails, setordersDetails] = useState([])
  
//   useEffect(() => {
//     // get the list of products from server
//     console.log("in component did mount")
//     loadOrders()
//   }, [])

//   const loadOrders = async () => {
//     const response = await getOrdersList()
//     //if (response['status'] === 'success') {
//       if(true){
//         console.log("in the Orders page");
//         console.log(response)
//         //console.log(JSON.parse(response))
//         setordersDetails(response.data)
//         console.log("Orders-------------"+ordersDetails)

//     } else {
//       toast.error('Error while calling get /Orders api')
//     }
//   }

//   return (
//     <div>
//       <h1 style={{ textAlign: 'center', margin: 10 }}>Product Gallery</h1>
//       <div className='row' style={{ marginTop: 50 }}>
//         {ordersDetails.map((od) => {
//           return (
//             <div className='col-md-3'>
//               <div className='card'>
//                 <img
//                   src={constants.serverUrl + '/'}
//                   style={{ height: 200 }}
//                   alt=''
//                 />
//                 {/* [{"productId":1,"productName":"washing","productDesc":"string","productMfgDate":"2023-08-22","productExpDate":"2023-08-22","productPrice":200.0} */}
//                 <div className='card-body'>
//                   <h5 className='card-title'></h5>
//                   <div className='card-text'>
//                     {/* <div>{product['company']}</div>
//                     <div>₹ {product['price']}</div> */}
//                         <div>{od['customerFirstname']}</div>
//                         <div>{od['customerLastName']}</div>
//                         <div>{od['orderDetailsId']}</div>
//                         <div>{od['paymentstatus']} </div>
//                         <div>{od['price']} </div>
//                         <div>{od['productName']} </div>
//                         <div>{od['vehicleName']} </div>
//                         <div>{od['vehicleNo']} </div>

                        
//                   </div>
//                 </div>
//               </div>
//             </div>
//           )
//         })}
//       </div>
//     </div>
//   )
// }
  


// export default GetAllOrdersDetailsList
// // customerFirstname
// // : 
// // "new_firstname"
// // customerLastName
// // : 
// // "string"
// // orderDetailsId
// // : 
// // 2
// // orderId
// // : 
// // 2
// // paymentstatus
// // : 
// // null
// // price
// // : 
// // 100
// // productName
// // : 
// // "string"
// // status
// // : 
// // null
// // technicianAssigned
// // : 
// // null
// // vehicleName
// // : 
// // "g6"
// // vehicleNo
// // : 
// // "mustang"

