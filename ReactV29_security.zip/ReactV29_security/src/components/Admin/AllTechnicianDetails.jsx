import React from 'react';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '.././../CssFiles/box.css';
import { Link, useNavigate } from 'react-router-dom'
import { getAllTechnicianDetails } from '../../services/user';
import { useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import { removeTechnicianById as removeTechnicianByIdApi } from '../../services/user'
import { MDBTable, MDBTableHead, MDBTableBody } from 'mdb-react-ui-kit';


function AllTechnicianDetails() {
    //const history = useHistory();
    const navigate = useNavigate()
    //const [products, setProducts] = useState([])
    const [technicianDetails, setTechnicianDetails] = useState([])

  var index=0;
  useEffect(() => {
    // get the list of products from server
    console.log("in component did mount")
    loadTechnicianDetails()
  }, [])

  const loadTechnicianDetails = async () => {
    const response = await getAllTechnicianDetails()
    //if (response['status'] === 'success') {
      if(true){
        console.log("in the All technician Details page");
        console.log(response)
        setTechnicianDetails(response.data)
        console.log("technicial Details-------------"+technicianDetails)
    } else {
      toast.error('Error while calling get /technicialDetails api')
    }
  }

    const handleEditClick = (technicianId) => {        
        navigate('/UpdateTechnicianDetailsByAdmin/' +technicianId)
          // history.push('');     
    };

    // const handleDeleteClick = (technicianId) => {
        // Handle click for "Your Assigned Orders"
        // You can navigate to a specific route or perform any other action here
        const removeTechnician = async (technicianId) => {
            // call register api
            const response = await removeTechnicianByIdApi(technicianId)
            console.log(response)
            loadTechnicianDetails()
            toast.success('Technician is deleted successfully ')
        };
       
          
  //  };
    return(

        <div>
          <h1 style={{ textAlign: 'center', margin: 10 }}>All technician Details</h1>
          <MDBTable bordered hover>
          <MDBTableHead dark>
                  <tr >
                    <th>Sr. No</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email Id</th>
                    <th>Password</th>
                    <th>Salary</th>
                    <th>Location</th>
                    <th>Department</th>
                    <th>Designation</th>
                    <th>Role</th>
                    <th>Edit</th>
                    <th>Delete</th>
                  </tr>
                </MDBTableHead>
            <MDBTableBody>
              {technicianDetails.map((technician) => {
                index = index + 1
                return (
                    <tr key={technician.technicianId}>
                    <td>{index}</td>
                    <td>{technician.firstName}</td>
                    <td>{technician.lastName}</td>
                    <td>{technician.email}</td>
                    <td>{technician.password}</td>
                    <td>{technician.salary}</td>
                    <td>{technician.location}</td>
                    <td>{technician.department}</td>
                    <td>{technician.designation}</td>
                    <td>{technician.role}</td>
                    <td>
                      <button className="btn btn-warning" onClick={()=>{handleEditClick(technician.technicianId)}}>Edit</button>
                    </td>
                    <td>
                      <button className="btn btn-danger" onClick={()=>{removeTechnician(technician.technicianId)}}>Delete</button>
                    </td>
                  </tr>
                );
              })}
            </MDBTableBody>
          </MDBTable>
        </div>
        
        )
/////////////////////////////////////////////////////////////////////////////////////////////
// Working
// return(

// <div>
//   <h1 style={{ textAlign: 'center', margin: 10 }}>All technician Details</h1>
//   <table className='table table-bordered'>
//   <thead>
//           <tr >
//             <th>Sr. No</th>
//             <th>First Name</th>
//             <th>Last Name</th>
//             <th>Email Id</th>
//             <th>Password</th>
//             <th>Salary</th>
//             <th>Location</th>
//             <th>Department</th>
//             <th>Designation</th>
//             <th>Role</th>
//             <th>Edit</th>
//             <th>Delete</th>
//           </tr>
//         </thead>
//         <tbody>
          
//         </tbody>
//     <tbody>
//       {technicianDetails.map((technician) => {
//         return (
//             <tr key={technician.technicianId}>
//             <td>1</td>
//             <td>{technician.firstName}</td>
//             <td>{technician.lastName}</td>
//             <td>{technician.email}</td>
//             <td>{technician.password}</td>
//             <td>{technician.salary}</td>
//             <td>{technician.location}</td>
//             <td>{technician.department}</td>
//             <td>{technician.designation}</td>
//             <td>{technician.role}</td>
//             <td>
//               <button className="btn btn-warning" onClick={handleEditClick}>Edit</button>
//             </td>
//             <td>
//               <button className="btn btn-danger" onClick={handleDeleteClick}>Delete</button>
//             </td>
//           </tr>

//         //   <tr key={product.productId}>
//         //     <td>{product.productId}</td>
//         //     <td>{product.productName}</td>
//         //     <td>{product.productDesc}</td>
//         //     <td>{product.productMfgDate}</td>
//         //     <td>{product.productExpDate}</td>
//         //     <td>₹ {product.productPrice}</td>
//         //     <td>
//         //       <img
//         //         src={constants.serverUrl + '/' + product.image}
//         //         style={{ height: 100 }}
//         //         alt=''
//         //       />
//         //     </td>
//         //   </tr>
//         );
//       })}
//     </tbody>
//   </table>
// </div>

// )


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//     return (  
//         <> 
//      <center><h2>All Technician Details</h2></center>
//     <div className="container">
//         <br/><br/>
//         <div className="box-container">
                
//             <table className="table table-striped table-bordered table-hover table-responsive">
               
//                 <tr>
//                     <th>    
//                         Sr. No
//                     </th>
//                     <th>
//                         EmpId
//                     </th>

//                     <th>
                        
//                     EmpName	
                        
//                     </th>
                    
//                     <th>
                    
//                     EmailId 	
               
//                     </th>
//                     <th>
                    
//                     password	
                    
//                     </th>
//                     <th>
                    
//                     Address
//                     </th>

//                     <th>
                    
//                     	MobileNo

//                     </th>
                   
//                     <th>
                    
//                     gender
//                     </th>
//                     <th>
                    
//                     DeptID
//                     </th>
//                     <th>
                    
//                     DOJ
//                     </th>
//                     <th>
                    
//                     Expertise
//                     </th>

//                     <th>
                    
//                     DOB
//                     </th>
//                     <th>
                    
//                     Designation
//                     </th>
//                     <th>
                    
//                     Salary
//                     </th>
//                 </tr>
//                 <tbody>
//                 <tr>
//                     <td>    
//                        1
//                     </td>
//                     <td>
//                         100
//                     </td>

//                     <td>
                        
//                     Name 1
                        
//                     </td>
                    
//                     <td>
                    
//                     abc@123 	
               
//                     </td>
//                     <td>
                    
//                     123	
                    
//                     </td>
//                     <td>
                    
//                     pune
//                     </td>

//                     <td>
                    
//                     	112

//                     </td>
                   
//                     <td>
                    
//                     Male
//                     </td>
//                     <td>
                    
//                     HR
//                     </td>
//                     <td>
                    
//                     18/6/2020
//                     </td>
//                     <td>
                    
//                     Level 1
//                     </td>

//                     <th>
                    
//                     5/5/2005
//                     </th>
//                     <td>
                    
//                     Trainee
//                     </td>
//                     <td>
                    
//                     50000
//                     </td>
//                     <td>
                    
//                     50000
//                     </td>
//                     <td>
                    
//                     <button className="btn btn-warning" onClick={handleEditClick}>Edit</button>

//                     </td>
//                     <td>
                    
//                     <button className="btn btn-danger" onClick={handleDeleteClick}>Delete</button>

//                     </td>
//                 </tr>
//                 </tbody>

//             </table>

//         </div>
//     </div>
//     </>

//     );
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}
export default AllTechnicianDetails