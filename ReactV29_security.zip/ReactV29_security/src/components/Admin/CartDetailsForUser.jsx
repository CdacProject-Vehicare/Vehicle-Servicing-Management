///////////chat GPT///////////////////
import React, { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import { GetListOfItemsinCart } from '../../services/cart';
import { PlaceOrderApi } from '../../services/orders';
import { useNavigate } from 'react-router-dom';

import 'bootstrap/dist/css/bootstrap.min.css';
// import './CartGallery.css';

function CartGallery() {
  const [cartItems, setCartItems] = useState([]);
  const [vehicleMfg, setVehicleMfg] = useState('');
  const [vehicleName, setVehicleName] = useState('');
  const [vehicleType, setVehicleType] = useState('');
  const [vehicleNo, setVehicleNo] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    loadCartItems();
  }, []);

  const loadCartItems = async () => {
    try {
      const response = await GetListOfItemsinCart(sessionStorage.getItem('id'));
      if (response) {
        setCartItems(response.data);
      } else {
        toast.error('Error while fetching cart items');
      }
    } catch (error) {
      console.error('Error while fetching cart items:', error);
      toast.error('Error while fetching cart items');
    }
  };

  const calculateTotalPrice = () => {
    return cartItems.reduce((total, product) => total + product.productPrice, 0);
  };

  const placeOrder = async (customerId) => {
    try {
      const response = await PlaceOrderApi(customerId);
      if (response) {
        navigate('/GetAllOrdersDetailsListByCustomerId');
        toast.success('Order placed successfully')
        setCartItems(response.data);
      } else {
        toast.error('Error while placing order');
      }
    } catch (error) {
      console.error('Error while placing order:', error);
      toast.error('Error while placing order');
    }
  };

  return (
    // <div className='container' style={{background: linear-gradient( bottom, #4a90e2, #483d8b)}}>
    // <div className='container' style={{ background: 'linear-gradient(to bottom, #4a90e2, #483d8b)' }}>
<div className='container'>

      <h1 className='text-center my-4'>Cart Gallery</h1>
      <table className='table'>
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Product Price</th>
          </tr>
        </thead>
        <tbody>
          {cartItems.map((product) => (
            <tr key={product.productId}>
              <td>{product.productName}</td>
              <td>{product.productPrice}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className='text-center'>
        <button className='btn btn-primary' onClick={() => placeOrder(sessionStorage.getItem('id'))}>
          Place Order
        </button>
      </div>
      <div className='text-center mt-3'>
        <div className='total-price'>
          <strong>Total Price: {calculateTotalPrice()} </strong>
        </div>
      </div>
    </div>
  );
}

export default CartGallery;




/////////////////////pratik/////////////////////////////////////////////////////////
// import React, { useEffect, useState } from 'react';
// import { toast } from 'react-toastify';
// import { constants } from '../../utils/constants';
// import { GetListOfItemsinCart } from '../../services/cart';
// import { PlaceOrderApi } from '../../services/orders';
// import { useNavigate } from 'react-router-dom';
// function CartGallery() {
//   const [cartItems, setCartItems] = useState([]);

//   const [vehicleMfg, setVehicleMfg] = useState('')
//   const [vehicleName, setVehicleName] = useState('')
//   const [vehicleType, setVehicleType] = useState('')
//   const [vehicleNo, setVehicleNo] = useState('')

//   const navigate=useNavigate();
  
//   const insertVehicle= async () => {
//     if (vehicleName.length == '') {
//       toast.error('Please enter Vehicle Name')
//     } else if (vehicleMfg.length == '') {
//       toast.error('Please enter Vehicle company')
//     } else if (vehicleType.length == '') {
//       toast.error('Please enter Vehicle Type')
//     } else if (vehicleNo.length == '') {
//       toast.error('Please Enter Vehicle Number')
//     }  else {
//       // call register api
//       const response = await PlaceOrderApi(vehicleMfg, vehicleName,vehicleType,vehicleNo)
//       console.log(response)
//       if(response){
        
//         console.log(response)
//         toast.success('Vehicle added successfully')
//         navigate('/src/components/Admin/AllOrdersDetails.jsx')
//       } else {
//         toast.error('Vehicle failed to add to ')
//         navigate('/src/components/Admin/AllOrdersDetails.jsx')
//       }
//     }
//   }
  
//   const handleVehicleTypeChange = (e) => {
//     setVehicleType(e.target.value);
//   };


//   useEffect(() => {
//     loadCartItems();
//   }, []);

//   const loadCartItems = async () => {
//     const response = await GetListOfItemsinCart(sessionStorage.getItem('id'));
//     if (response) {
//       setCartItems(response.data);
//     } else {
//       toast.error('Error while calling get /product api');
//     }
//   };

//   const calculateTotalPrice = () => {
//     return cartItems.reduce((total, product) => total + product.productPrice, 0);
//   };

//   const placeOrder= async (customerId)=>{

//     const response = await PlaceOrderApi(customerId);
//     if (response) {
//       navigate("/src/components/Admin/AdminAccount.jsx")
//       setCartItems(response.data);
     
//     } else {
//       toast.error('Error while calling get /product api');
//     }

//   }

//   return (
//     <div>
//       <h1 style={{ textAlign: 'center', margin: 10 }}>Product Gallery</h1>
//       <table className='table'>
//         <thead>
//           <tr>
//             <th>Product Name</th>
//             <th>Product Price</th>
//           </tr>
//         </thead>
//         <tbody>
//           {cartItems.map((product) => (
//             <tr key={product.productId}>
//               <td>{product.productName}</td>
//               <td>{product.productPrice}</td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//       <div style={{ textAlign: 'center', marginTop: 20 }}>
//         <button className='btn btn-primary'  onClick={() => placeOrder(sessionStorage.getItem('id'))}>Place Order</button>
//       </div>
//       <div style={{ textAlign: 'center', marginTop: 20 }}>
//         <div style={{ border: '1px solid #ccc', padding: '10px', width: '200px', margin: '0 auto' }}>
//           <strong>Total Price: {calculateTotalPrice()} </strong>
//         </div>
//       </div>

//   {/* <h1 style={{ textAlign: 'center', margin: 10 }}>Add Vehicle</h1>

//     <div className='row'>
//       <div className='col'></div>
//             <div className='col'>
//                 <div className='form'> */}

//                       {/* <div className='mb-3'>
//                         <label htmlFor=''>Vehicle Name</label>
//                         <input type='text'
//                           className='form-control'
//                           onChange={(e) => {
//                             setVehicleName(e.target.value)
//                           }}
//                         />
//                       </div>

//                         <div className='mb-3'>
//                           <label htmlFor=''>Vehicle company</label>
//                           <input
//                             type='text'
//                             className='form-control'
//                             onChange={(e) => {
//                               setVehicleMfg(e.target.value)
//                             }}
//                           />
//                         </div> */}

//                         {/* <div className='mb-3'>
//                           <label htmlFor=''>Vehicle Type</label>
//                           <input
//                             type='text'
//                             className='form-control'
//                             onChange={(e) => {
//                               setVehicleType(e.target.value)
//                             }}
//                           />
//                         </div> */}
//                         {/* <div className='mb-3'>
//                           <label htmlFor='vehicleType'>Vehicle Type</label>
//                           <input
//                             type='text'
//                             id='vehicleType'
//                             className='form-control'
//                             value={vehicleType}
//                             onChange={handleVehicleTypeChange}
//                           />
//                         </div> */}

//                         {/* <div className='mb-3'>
//                             <label htmlFor='vehicleOptions'>Vehicle Type</label>
//                             <select
//                               id='vehicleOptions'
//                               className='form-control'
//                               value={vehicleType}
//                               onChange={handleVehicleTypeChange}
//                             >
//                               <option value=''>Select an option</option>
//                               <option value='TWOWHEELER'>2W</option>
//                               <option value='FOURWHEELER'>4W</option>
//                             </select>
//                         </div> */}


//                         {/* <div className='mb-3'>
//                           <label htmlFor=''>Vehicle no</label>
//                           <input
//                             type='text'
//                             className='form-control'
//                             onChange={(e) => {
//                               setVehicleNo(e.target.value)
//                             }}
//                           />
//                         </div> */}
          
//                           {/* <div className='mb-3'>
//                              <div className='mb-3'>
//                               Don't have an account? <Link to='/register'>Register here</Link>
//                             </div>
//                             <button onClick={insertVehicle} className='btn btn-success'>
//                               Add Vehicle to order
//                             </button>
//                           </div> */}
                          
//                 {/* </div>
//             </div>
//       <div className='col'></div>
//     </div> */}
// </div>



//   );
// }

// export default CartGallery;












//------------------------Card format Display---------------------
// import { useEffect, useState } from 'react'
// import { toast } from 'react-toastify'
// import { constants } from '../../utils/constants'
// import { AddToCartApi } from '../../services/cart'
// import { GetProductList } from '../../services/product'
// import { GetListOfItemsinCart } from '../../services/cart'
// function CartGallery() {
//   const [cartItems, setcartItems] = useState([])

//   useEffect(() => {
//     // get the list of products from server
//     console.log("in component did mount")
//     loadcartItems()
//   }, [])

//   const loadcartItems = async () => {
//     const response = await GetListOfItemsinCart(sessionStorage.getItem('id'))
//     //if (response['status'] === 'success') {
//       if(true){
//         console.log("in the carts page");
//         console.log(response)
//         setcartItems(response.data)
//         //console.log("carts-------------"+products)

//     } else {
//       toast.error('Error while calling get /product api')
//     }
//   }


//   // const handleAddToCartUpdate = async (productId) => {
//   //   // Handle edit logic for the specific order

//   //   const response = await AddToCartApi(productId)
//   //   //if (response['status'] === 'success') {
//   //     if(true){
//   //       toast.success('service with service id '+productId+' Successfully Added to cart')

//   //       console.log("in the UpdateOrderPaymentStatusApi ");
//   //   } else {
//   //     toast.error('Error while calling get handleAddToCartUpdate api')
//   //   } 
   
// //loadOrders()




//   //   console.log('OrderUpdate with ID:', productId);
//   // };



//   return (
//     <div>
//       <h1 style={{ textAlign: 'center', margin: 10 }}>Product Gallery</h1>
//       <div className='row' style={{ marginTop: 50 }}>
       
//       <button
//                   className='btn btn-sm btn-primary sm-2'
//                   >
//                  place order
//                 </button>
       
//         {cartItems.map((product) => {
//           return (
//             <div className='col-md-3'>
//               <div className='card'>
//                 <img
//                   src={constants.serverUrl + '/' + product['image']}
//                   style={{ height: 200 }}
//                   alt=''
//                 />
//                 {/* [{"productId":1,"productName":"washing","productDesc":"string","productMfgDate":"2023-08-22","productExpDate":"2023-08-22","productPrice":200.0} */}
//                 <div className='card-body'>
//                   <h5 className='card-title'></h5>
//                   <div className='card-text'>
//                     {/* <div>{product['company']}</div>
//                     <div>₹ {product['price']}</div> */}

// {/* [
//   {
//     "productName": "string",
//     "productPrice": 100
//   },
//   {
//     "productName": "bike washing",
//     "productPrice": 500
//   }
// ] */}

                      
//                         <div>{product['productName']}</div>                       
//                         <div>{product['productPrice']} </div>
                       
                 
                 
//                   </div>
//                 </div>
//               </div>
//             </div>
//           )
//         })}
//       </div>
//     </div>
//   )
// }

// export default CartGallery
