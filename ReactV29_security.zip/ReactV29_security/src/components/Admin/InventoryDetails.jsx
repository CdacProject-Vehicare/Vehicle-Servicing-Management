import React from 'react';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';

import { useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import { getAllInventoryDetails } from '../../services/Inventory-Service';
import { MDBTable, MDBTableHead, MDBTableBody } from 'mdb-react-ui-kit';

import '../../CssFiles/box.css'

function InventoryDetails() {
    const navigate = useNavigate()
    const [inventoryList, setInventory] = useState([])
    var index = 0;

    useEffect(() => {
        console.log("in component did mount")
        loadInventory()
      }, [])

      const loadInventory = async () => {
        const response = await getAllInventoryDetails()
        //if (response['status'] === 'success') {
          if(true){
            console.log("in the Inventory page");
            console.log(response)
            setInventory(response.data)
            console.log("Inventory-------------"+inventoryList)
    
        } else {
          toast.error('Error while calling get /inventory api')
        }
      }


    // const handleEditClick = () => {
    //     history.push('/InventoryUpdate');
    // };

    // const handleAddClick = () => {
    //     history.push('/AddNewProductinInventory');
    //  };

    // const handleDeleteClick = () => {
    //      alert('Records Deleted!!');
    // };

    return(

        <div>
          <h1 style={{ textAlign: 'center', margin: 10 }}>All Item Details</h1>
          <button className="btn btn-info" 
                onClick={()=>{navigate('/AddNewItemInInventory')}}>Add New Items</button>
                   
          <MDBTable bordered hover>
          {/* <thead>
                  <tr >
                    <th>Sr. No</th>
                    <th>Item Id</th>
                    <th>Item Name</th>
                    <th>Safety Stock</th>
                    <th>Available stock</th>
                    <th>item Price</th>
                    <th>Edit</th>
                    <th>Delete</th> 
                  </tr>
                </thead> */}
                <MDBTableHead dark>
                <tr>
                  <th className="column-header">Sr. No</th>
                  <th className="column-header">Item Id</th>
                  <th className="column-header">Item Name</th>
                  <th className="column-header">Safety Stock</th>
                  <th className="column-header">Available Stock</th>
                  <th className="column-header">Item Price</th>
                  {/* <!-- <th>Edit</th>
                  <th>Delete</th> --> */}
                </tr>
              </MDBTableHead>
              
            <MDBTableBody>
              {inventoryList.map((item) => {
                // const serialNumber = index + 1;
                    index = index + 1
                return (
                    <tr key={item.inventoryId}>
                    <td className="column-field">{index}</td>
                    <td className="column-field">{item.inventoryId}</td>
                    <td className="column-field">{item.inventoryName}</td>
                    <td className="column-field">{item.safetyStock}</td>
                    <td className="column-field">{item.availableStock}</td>
                    <td className="column-field">{item.invetoryPrice}</td>
                    {/* <td>
                      <button classNameName="btn btn-warning" onClick={()=>{navigatToEditService(product.productId)}}>Edit</button>
                    </td>
                    <td>
                      <button classNameName="btn btn-danger" onClick={()=>{removeService(product.productId)}}>Delete</button>
                    </td> */}

                    {/* <td>
                      <button classNameName="btn btn-danger" onClick={()=>{removeTechnician(technician.technicianId)}}>Delete</button>
                    </td> */}
                  </tr>
                );
              })}
            </MDBTableBody>
          </MDBTable>
        </div>
        )
}

export default InventoryDetails;