import React from 'react';
//import { useHistory } from 'react-router-dom';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../../CssFiles/box.css';
import { useNavigate } from 'react-router-dom'

import { useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import { getProductList } from '../../services/product';
import { removeServiceById as  removeServiceByIdApi} from '../../services/product';

function ProductCatalogue() {
    //const history = useHistory();
    const navigate = useNavigate()
    const [products, setProducts] = useState([])
    var index = 0;
    
    useEffect(() => {
        // get the list of products from server
        console.log("in component did mount")
        loadProducts()
      }, [])
      

      const loadProducts = async () => {
        const response = await getProductList()
        //if (response['status'] === 'success') {
          if(true){
            console.log("in the Product page");
            console.log(response)
            setProducts(response.data)
            console.log("products-------------"+products)
    
        } else {
          toast.error('Error while calling get /product api')
        }
      }


    const navigatToEditService=(productId)=>{
      navigate('/UpdateServiceCatalogue/'+productId)
    }

    const removeService = async (productId) => {
        // call register api
        const response = await removeServiceByIdApi(productId)
        console.log(response)
        loadProducts()
        toast.success('Product is deleted successfully ')
    };


    return(

        <div>
          <h1 style={{ textAlign: 'center', margin: 10 }}>All Service Details</h1>
          <button className="btn btn-info" onClick={()=>{navigate('/LaunchNewService')}}>Launch New Service</button>
                   
          <table className='table table-bordered'>
          <thead>
                  <tr >
                    <th>Sr. No</th>
                    <th>Service Id</th>
                    <th>Service Name</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Service Base price</th>
                    <th>Edit</th>
                    <th>Delete</th>
                  </tr>
                </thead>
            <tbody>
              {products.map((product) => {
                // const serialNumber = index + 1;
                    index = index + 1
                return (
                    <tr key={product.productId}>
                    <td>{index}</td>
                    <td>{product.productId}</td>
                    <td>{product.productName}</td>
                    <td>{product.productMfgDate}</td>
                    <td>{product.productExpDate}</td>
                    <td>{product.productPrice}</td>
                    <td>
                      <button className="btn btn-warning" onClick={()=>{navigatToEditService(product.productId)}}>Edit</button>
                    </td>
                    <td>
                      <button className="btn btn-danger" onClick={()=>{removeService(product.productId)}}>Delete</button>
                    </td>

                    {/* <td>
                      <button className="btn btn-danger" onClick={()=>{removeTechnician(technician.technicianId)}}>Delete</button>
                    </td> */}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        
        )
}

export default ProductCatalogue;