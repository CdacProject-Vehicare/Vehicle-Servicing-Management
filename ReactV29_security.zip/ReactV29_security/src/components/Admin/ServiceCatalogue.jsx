import { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import { AddToCartApi } from '../../services/cart';
import { GetProductList } from '../../services/product';
import { useNavigate } from 'react-router-dom';

import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS
// import './ProductGallery.css'; // Import your custom CSS for further styling

function ProductGallery() {
  const [products, setProducts] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const response = await GetProductList();
      if (response) {
        setProducts(response.data);
      } else {
        toast.error('Error while fetching product list');
      }
    } catch (error) {
      console.error('Error while fetching product list:', error);
      toast.error('Error while fetching product list');
    }
  };

  const handleAddToCartUpdate = async (productId) => {
    try {
      const response = await AddToCartApi(productId);
      if (response) {
        toast.success(`Service with ID ${productId} successfully added to cart`);
      } else {
        toast.error('Error while adding service to cart');
      }
    } catch (error) {
      console.error('Error while adding service to cart:', error);
      toast.error('Error while adding service to cart');
    }
  };

  const showMyCart = () => {
    navigate('/cartdetails');
  };

  return (
    <div className='container'>
      <h1 className='text-center my-4'>Book Your Services Here</h1>

      <button className='btn btn-success mb-3' onClick={() => showMyCart()}>
        Show My Cart
      </button>

      <div className='row'>
        {products.map((product) => (
          <div className='col-md-4 mb-4' key={product.productId}>
            <div className='card'>
              <img
                src="http://localhost:3000/ImageFolder/ACServices.png"
                className='card-img-top'
                alt=''
              />
              <div className='card-body'>
                <h5 className='card-title'>{product.productName}</h5>
                <div className='card-text'>
                  {/* <div>Service ID: {product.productId}</div> */}
                  {/* <div>Service Name: {product.productName}</div> */}
                  <div>{product.productDesc}</div>
                  {/* <div>Service Starting Date: {product.productMfgDate}</div> */}
                  <div>Service Price: ₹{product.productPrice}</div>
                  <button
                    className='btn btn-primary mt-2'
                    onClick={() => handleAddToCartUpdate(product.productId)}
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ProductGallery;







// import { useEffect, useState} from 'react'
// import { toast } from 'react-toastify'
// import { constants } from '../../utils/constants'
// import { AddToCartApi } from '../../services/cart'
// import { GetProductList } from '../../services/product'
// import { useNavigate } from 'react-router-dom'
// function ProductGallery() {
//   const [products, setProducts] = useState([])
//   const navigate =useNavigate();
//   useEffect(() => {
//     // get the list of products from server
//     console.log("in component did mount")
//     loadProducts()
//   }, [])

//   const loadProducts = async () => {
//     const response = await GetProductList()
//     //if (response['status'] === 'success') {
//       if(true){
//         console.log("in the Product page");
//         console.log(response)
//         setProducts(response.data)
//         console.log("products-------------"+products)

//     } else {
//       toast.error('Error while calling get /product api')
//     }
//   }


//   const handleAddToCartUpdate = async (productId) => {
//     // Handle edit logic for the specific order

//     const response = await AddToCartApi(productId)
//     //if (response['status'] === 'success') {
//       if(true){
//         toast.success('service with service id '+productId+' Successfully Added to cart')

//         console.log("in the UpdateOrderPaymentStatusApi ");
//     } else {
//       toast.error('Error while calling get handleAddToCartUpdate api')
//     } 
   
// //loadOrders()




//     console.log('OrderUpdate with ID:', productId);
//   };



//   const showMyCart = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/cartdetails");
// };

//   return (
//     <div>
//       <h1 style={{ textAlign: 'center', margin: 10 }}>Book your Services here....!!!</h1>

//       <button
//                   className='btn btn-sm btn-success sm-2'
//                   onClick={() => showMyCart()}>
//                  showMyCart
//                 </button>
//       <div className='row' style={{ marginTop: 50 }}>
//         {products.map((product) => {
//           return (
//             <div className='col-md-3'>
//               <div className='card'>
//                 <img
//                   //src={constants.serverUrl + '/' + product['image']}
//                   src="http://localhost:3000/ImageFolder/ACServices.png"
//                   style={{ height: 200 }}
//                   alt=''
//                 />
//                 {/* [{"productId":1,"productName":"washing","productDesc":"string","productMfgDate":"2023-08-22","productExpDate":"2023-08-22","productPrice":200.0} */}
//                 <div className='card-body'>
//                   <h5 className='card-title'>{product['title']}</h5>
//                   <div className='card-text'>
//                     {/* <div>{product['company']}</div>
//                     <div>₹ {product['price']}</div> */}
//                         <div>Service ID:{product['productId']}</div>
//                         <div>Service Name:{product['productName']}</div>
//                         <div>Service Dsecription:{product['productDesc']}</div>
//                         <div>Service StartingDate:{product['productMfgDate']} </div>
//                         <div>Service Price:{product['productPrice']} </div>
//                         <button
//                   className='btn btn-sm btn-primary sm-2'
//                   onClick={() => handleAddToCartUpdate(product['productId'])}>
//                  Add to CArt
//                 </button>
                 
                 
//                   </div>
//                 </div>
//               </div>
//             </div>
//           )
//         })}
//       </div>
//     </div>
//   )
// }

// export default ProductGallery
