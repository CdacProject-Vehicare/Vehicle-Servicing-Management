import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import { useState, useEffect } from 'react'
import {  useLocation, useNavigate, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import { getProductById, updateProductDetails as updateProductDetailsApi } from '../../services/product';



function UpdateServiceCatalogue() {
  //const location = useLocation()
  const navigate = useNavigate()
    //const {data} = location.state;
    const [productId, setProductId] = useState('')
    const [productName, setProductName] = useState('')
    const [productDesc, setProductDesc] = useState('')
    const [productMfgDate, setProductMfgDate] = useState('')
    const [productExpDate, setProductExpDate] = useState('')
    const [productPrice, setProductPrice] = useState('')
    
    //Edited
    const {id}=useParams();

  useEffect(() => {
    // get the list of products from server
    console.log("in component did mount")
    //console.log(props)
    fetchDetailsOfProduct()
  }, [])

  const fetchDetailsOfProduct = async () => {
    // console.log(data)
    // const response = await getProductById({data})

    console.log(id)
    const response = await getProductById(id)
    console.log(response)
      if(true){
        console.log("in the Update Product details ");
        setProductId(id)
        setProductName(response.data.productName)
        setProductDesc(response.data.productDesc)
        setProductMfgDate(response.data.productMfgDate)
        setProductExpDate(response.data.productExpDate)
        setProductPrice(response.data.productPrice)

        //setProducts(response.data)
       //console.log("Product details (response )-------------"+response)

    } else {
      toast.error('Error while calling get /product api')
    }
  }

  const updateService = async () => {
      // call register api
      const response = await updateProductDetailsApi(
        productId,productName,productDesc,productMfgDate,productExpDate,productPrice
      )
    if(response){
      toast.success('Successfully Update service details')
      navigate('/ProductCatalogue')
      
    }
  }




  //  const handleAddClick = () => {
  //    setMessage("Updated Successfully!")
  //  };

   return (
    <div>
      <h1 style={{ textAlign: 'center', margin: 10 }}>Update Service</h1>

      <div className='row'>
        <div className='col'></div>
        <div className='col'>
          <div className='form'>

            <div className='mb-3'>
              <label htmlFor=''>Service Name</label>
              <input
                type='text'
                className='form-control'
                value={productName}
                onChange={(e) => {
                  setProductName(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Product Description</label>
              <input
                type='text'
                className='form-control'
                value={productDesc}
                onChange={(e) => {
                  setProductDesc(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Enter Starting Date of Service </label>
              <input
                type='text'
                className='form-control'
                value={productMfgDate}
                onChange={(e) => {
                  setProductMfgDate(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Enter Service expiry Date </label>
              <input
                type='text'
                className='form-control'
                value={productExpDate}
                onChange={(e) => {  
                  setProductExpDate(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Price</label>
              <input
                type='text'
                className='form-control'
                value={productPrice}
                onChange={(e) => {
                  setProductPrice(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <button onClick={updateService} className='btn btn-success'>
                Update
              </button>
            </div>
          </div>
        </div>
        <div className='col'></div>
      </div>
    </div>
  )
}

   

export default UpdateServiceCatalogue;