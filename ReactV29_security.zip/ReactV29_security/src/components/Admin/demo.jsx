
/////---------MODAL Start--------------------------
import React, { useState } from 'react';
import { MDBTable, MDBTableHead, MDBTableBody } from 'mdb-react-ui-kit';
//import { MDBSelect } from 'mdb-react-ui-kit';

import { Modal } from 'react-modal';
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { GetTechnicianListApi } from '../../services/technicians';
import { getAllOrdersListApi } from '../../services/orders';
import { AssignOrderToTechnicianApi } from '../../services/orders';
import { GetOrderTechnicianDetailsList } from '../../services/orderTechnicianDetails';
import { UpdateWorkLog } from '../../services/orderTechnicianDetails';
function EmployeeDropdown() {


const [modalIsOpen, setModalIsOpen] = useState(false);
const [orderIdInput, setOrderIdInput] = useState('');
const [textInput, setTextInput] = useState('');

  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
  const [selectedOrderId, setSelectedOrderId] = useState('');

  const [orders, setOrders] = useState([])
  const [technician,setTechnician]=useState([])
  const [data,setData]=useState([])
  const navigate =useNavigate()


   //-----------

   const openModal = () => {
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
  };

  const handleOrderInputChange = (e) => {
    setOrderIdInput(e.target.value);
  };

  const handleTextInputChange = (e) => {
    setTextInput(e.target.value);
  };
   //--------

    //---------------start

    const handlePopUpSubmit = () => {
      // Call another function and pass the values
      anotherFunction(orderIdInput, textInput);
      
      // Close the modal
      closeModal();
    };
  
    const anotherFunction = async (orderId, inputValue) => {
      // Do something with the values
      console.log('Order ID in another function:', orderId);
      console.log('Input Value in another function:', inputValue);

      const response= await UpdateWorkLog(textInput, orderIdInput);
      if (response) {
        console.log('Work log updated successfully:', response);
        loadOrderTechnicianDetails()
        // Perform any actions after successful update
      } else {
        console.error('Failed to update work log');
        // Handle error scenario
      }
    };
  

    //------------end

  useEffect(() => {
    // get the list of products from server
    console.log("in component did mount")
    loadOrderData()
    loadTechnicianData()
    loadOrderTechnicianDetails()
  }, [])

  const loadOrderData = async () => {
    const response = await getAllOrdersListApi()
    //if (response['status'] === 'success') {
      if(true){
        console.log("in the OrdersTechnician page");
        console.log(response)
        setOrders(response.data)
        

    } else {
      toast.error('Error while calling get /product api')
    }
  }

  const loadTechnicianData = async () => {
    const response = await GetTechnicianListApi()
    //if (response['status'] === 'success') {
      if(true){
        console.log("in the OrdersTechnician page");
        console.log(response)
        setTechnician(response.data)
      

    } else {
      toast.error('Error while calling get /product api')
    }
  }


  const loadOrderTechnicianDetails = async () => {
    const response = await GetOrderTechnicianDetailsList()
    //if (response['status'] === 'success') {
      if(response.status!=401 ){
        console.log("in the OrdersTechnician page");
        console.log(response)
        setData(response.data)
      

    } else {
      toast.error('Error while calling get /product api')
      navigate("/CustomerAccount")
    }
  }






  const handleEmployeeSelect = (event) => {
    setSelectedEmployeeId(event.target.value);
  };

  const handleOrderSelect = (event) => {
    setSelectedOrderId(event.target.value);
  };

  const handleButtonClick = () => {
    if (selectedEmployeeId && selectedOrderId) {
      passSelectedValues(selectedEmployeeId, selectedOrderId);
    } else {
      alert('Please select an employee and an order.');
    }
  };

  const passSelectedValues = async (employeeId, orderId) => {
    console.log('Selected Employee ID:', employeeId);
    console.log('Selected Order ID:', orderId);


    const response = await AssignOrderToTechnicianApi(employeeId,orderId)
    //if (response['status'] === 'success') {
      if(true){
        console.log("in the OrdersTechnician page");
        console.log(response)
        setTechnician(response.data)
        toast.success( 'work is assigned to Technician')
        navigate('/AdminAccount')
       

    } else {
      toast.error('Error while calling get /product api')
    }

    

  };

  return (
    <div>
     <center> <h1>Assigned work to Technician</h1></center>
      {/* <div>
        <label>Select an employee:</label>
        <select value={selectedEmployeeId} onChange={handleEmployeeSelect}>
          <option value="">Select an technician...</option>
          {technician.map((employee) => (
            <option key={employee.technicianId} value={employee.technicianId}>
              {employee.firstName}
            </option>
          ))}
        </select>
      </div> */}

<div className="container-fluid">
      <h1 className="text-center mb-4">Employee and Order Mapping</h1>
      <div className="row">
        <div className="col-md-2">

          <div className="form-group">

            <label htmlFor="employeeSelect">Select an employee:</label>
            <select
              id="employeeSelect"
              className="form-control"
              value={selectedEmployeeId}
              onChange={handleEmployeeSelect}
            >
              <option value="">Select a technician...</option>
              {technician.map((employee) => (
                <option key={employee.technicianId} value={employee.technicianId}>
                  {employee.firstName}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* <div className="col-md-2">
          <div className="form-group">
            <label htmlFor="employeeSelect">Select an employee:</label>
            <select
              id="employeeSelect"
              className="form-control"
              value={selectedEmployeeId}
              onChange={handleEmployeeSelect}
            >
              <option value="">Select a technician...</option>
              {technician.map((employee) => (
                <option key={employee.technicianId} value={employee.technicianId}>
                  {employee.firstName}
                </option>
              ))}
            </select>
          </div>
        </div> */}

        
        <div className="col-md-2">
          <div className="form-group">
        <label>Select an order:</label>
        <select  className="form-control" value={selectedOrderId} onChange={handleOrderSelect}>
          <option value="">Select an order...</option>
          {orders.map((order) => (
            <option key={order.orderId} value={order.orderId}>
              {order.orderId}
            </option>
          ))}
        </select>
        </div>
        </div>




        {/* ... Add more columns for other inputs ... */}
      </div>
      {/* <div className="text-center mt-1">
        <button className="btn btn-info" onClick={handleButtonClick}>
          Add Mapping
        </button>
      </div> */}
      {/* ... Rest of your UI ... */}
    </div>

      {/* <div>
        <label>Select an order:</label>
        <select value={selectedOrderId} onChange={handleOrderSelect}>
          <option value="">Select an order...</option>
          {orders.map((order) => (
            <option key={order.orderId} value={order.orderId}>
              {order.orderId}
            </option>
          ))}
        </select>
      </div> */}
      <button className="btn btn-info" onClick={handleButtonClick}>Add Mapping</button>
      <h1>Activity Tracker</h1>
      <MDBTable bordered hover>
      <MDBTableHead dark>
          <tr>
            <th>Order ID</th>
            <th>Technician ID</th>
            <th>Technician Name</th>
            <th>Work-log</th>
            <th>Expected Completion Date</th>
          </tr>
          </MDBTableHead>
          <MDBTableBody>
          {data.map((item, index) => (
            <tr key={index}>
              <td>{item.orderId}</td>
              <td>{item.technicianId}</td>
              <td>{item.technicianName}</td>
              <td>{item.worklog}</td>
              <td>{item.expectedCompletionDate}</td>
               
            </tr>
         
        
        ))}
        </MDBTableBody>
        </MDBTable>
      
        <h2 >Update Worklog Here</h2>
        <div>
          <div className='col-md-2' >
           <label>Order ID:</label>
           <input type='text' className="form-control" value={orderIdInput} onChange={handleOrderInputChange} />
          </div>
         <div className='col-md-2'>
           <label>Input Text:</label>
           <input type='text' className="form-control" value={textInput} onChange={handleTextInputChange} />
          </div>
          <button className="btn btn-info" onClick={handlePopUpSubmit}>Submit</button>
        </div>
    </div>
  );
}

 export default EmployeeDropdown;
///////------Modal END-
// import React, { useState } from 'react';

// function EmployeeDropdown() {
//   const orders = [
//     { id: 1, description: 'Order 1' },
//     { id: 2, description: 'Order 2' },
//     // ...more orders
//   ];

//   const employees = [
//     { id: 1, name: 'John Doe', mappedOrderIds: [] },
//     { id: 2, name: 'Jane Smith', mappedOrderIds: [] },
//     // ...more employees
//   ];

//   const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
//   const [selectedOrderId, setSelectedOrderId] = useState('');
//   const [employeeOrderMappings, setEmployeeOrderMappings] = useState([]);

//   const handleEmployeeSelect = (event) => {
//     setSelectedEmployeeId(event.target.value);
//   };

//   const handleOrderSelect = (event) => {
//     setSelectedOrderId(event.target.value);
//   };

//   const handleButtonClick = () => {
//     if (selectedEmployeeId && selectedOrderId) {
//       const newMapping = {
//         employeeId: selectedEmployeeId,
//         orderId: selectedOrderId,
//       };
//       setEmployeeOrderMappings([...employeeOrderMappings, newMapping]);
//       setSelectedEmployeeId('');
//       setSelectedOrderId('');
//     } else {
//       alert('Please select an employee and an order.');
//     }
//   };

//   return (
//     <div>
//       <h1>Employee and Order Mapping</h1>
//       <div>
//         <label>Select an employee:</label>
//         <select value={selectedEmployeeId} onChange={handleEmployeeSelect}>
//           <option value="">Select an employee...</option>
//           {employees.map((employee) => (
//             <option key={employee.id} value={employee.id}>
//               {employee.name}
//             </option>
//           ))}
//         </select>
//       </div>
//       <div>
//         <label>Select an order:</label>
//         <select value={selectedOrderId} onChange={handleOrderSelect}>
//           <option value="">Select an order...</option>
//           {orders.map((order) => (
//             <option key={order.id} value={order.id}>
//               {order.description}
//             </option>
//           ))}
//         </select>
//       </div>
//       <button onClick={handleButtonClick}>Add Mapping</button>
//       <h2>Employee-Order Mappings:</h2>
//       <table>
//         <thead>
//           <tr>
//             <th>Employee Name</th>
//             <th>Order Description</th>
//           </tr>
//         </thead>
//         <tbody>
//           {employeeOrderMappings.map((mapping, index) => (
//             <tr key={index}>
//               <td>{employees.find((employee) => employee.id === mapping.employeeId)?.name}</td>
//               <td>{orders.find((order) => order.id === mapping.orderId)?.description}</td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// }

// export default EmployeeDropdown;


// import React, { useState } from 'react';

// function EmployeeDropdown() {
//   const orders = [
//     { id: 1, description: 'Order 1' },
//     { id: 2, description: 'Order 2' },
//     // ...more orders
//   ];

//   const employees = [
//     { id: 1, name: 'John Doe', mappedOrderIds: [1] },
//     { id: 2, name: 'Jane Smith', mappedOrderIds: [2] },
//     // ...more employees
//   ];

//   const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
//   const [availableOrders, setAvailableOrders] = useState(orders);

//   const handleEmployeeSelect = (event) => {
//     const selectedId = event.target.value;
//     setSelectedEmployeeId(selectedId);

//     const selectedEmployee = employees.find((employee) => employee.id === parseInt(selectedId));
//     const filteredOrders = orders.filter((order) => !selectedEmployee.mappedOrderIds.includes(order.id));
//     setAvailableOrders(filteredOrders);
//   };

//   const handleOrderSelect = (event) => {
//     const selectedOrderId = event.target.value;
//     // Handle the selected order and employee here
//     console.log('Selected Order ID:', selectedOrderId);
//     console.log('Selected Employee ID:', selectedEmployeeId);
//   };

//   return (
//     <div>
//       <h1>Employee and Order Mapping</h1>
//       <div>
//         <label>Select an employee:</label>
//         <select value={selectedEmployeeId} onChange={handleEmployeeSelect}>
//           <option value="">Select an employee...</option>
//           {employees.map((employee) => (
//             <option key={employee.id} value={employee.id}>
//               {employee.name}
//             </option>
//           ))}
//         </select>
//       </div>
//       <div>
//         <label>Select an order:</label>
//         <select onChange={handleOrderSelect}>
//           <option value="">Select an order...</option>
//           {availableOrders.map((order) => (
//             <option key={order.id} value={order.id}>
//               {order.description}
//             </option>
//           ))}
//         </select>
//       </div>
//     </div>
//   );
// }

// export default EmployeeDropdown;


// import React from 'react';
// import { useNavigate } from 'react-router-dom';
// import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
// import '../../CssFiles/box.css';
// import Sidebar from '../../Screen/Sidebar';
// function AdminAccount() {

//   const navigate = useNavigate()
  

  
//   const handleAllAssignedOrdersClick = () => {
//     // Handle click for "Your Assigned Orders"
//     // You can navigate to a specific route or perform any other action here
    
//         navigate("/src/components/Admin/AllOrdersDetails.jsx");
      
// };

//   const handleEditProfileClick = () => {
//     // Handle click for "Edit Profile"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/AdminProfileupdate");
//   };

//   const handleUpdateTechnicianClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/TechnicianProfileUpdate");
// };

// const handleGenerateReportClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/piechart");
// };

// const handleWorkLogClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/TechnicianWorklog");
// };

// const handleUpdateServicesClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/servicecatalogue");
// };

// const handleUpdateTimeSlotsClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/servicecatalogue");
// };

// const handleUpdateInventoryClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/Inventory");
// };


// const addtocart = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/productgallery");
// };





//   return (<> 
//   <div><Sidebar></Sidebar></div>
//    <center> <h1>Your Account</h1></center>   
//     <div className="container">
//         <br/><br/>
//         <div className="box-container">
//         <div className="box" onClick={addtocart}>
//                     book Order
//                         </div>

//             <table>
//                 <tr>
//                     <td>
//                         <div className="box" onClick={handleAllAssignedOrdersClick}>
//                     All Assigned Orders
//                         </div>

                        
//                     </td>
//                     <td>
//                     <div className="box" onClick={handleEditProfileClick}>
//                     Edit Self Profile
//                 </div>
//                     </td>

//                     <td>
//                         <div className="box" onClick={handleUpdateTechnicianClick}>
//                         Update Technician Profile
//                         </div>
//                     </td>
//                     </tr>


//                     <tr>
//                     <td>
//                     <div className="box" onClick={handleGenerateReportClick}>
//                     Generate Report
//                 </div>
//                     </td>
//                     <td>
//                     <div className="box" onClick={handleWorkLogClick}>
//                     Work-Log
//                     </div>
//                     </td>
//                     <td>
//                     <div className="box" onClick={handleUpdateInventoryClick}>
//                     Total Rating
//                     </div>
//                     </td>
//                     </tr>
//                     <tr>
//                     <td>
//                         <div className="box" onClick={handleUpdateServicesClick}>
//                         Update Services
//                         </div>
//                     </td>

//                     <td>
//                         <div className="box" onClick={handleUpdateTimeSlotsClick}>
//                         Update Time-slots
//                         </div>
//                     </td>

//                     <td>
//                         <div className="box" onClick={handleUpdateInventoryClick}>
//                         Update Inventory
//                         </div>
//                     </td>

//                 </tr>
//             </table>

//         </div>
//     </div>
//     </>

//   );
// }

// export default AdminAccount;




// // import React from 'react';
// // import { usenavigate } from 'react-router-dom';
// // import '../../node_modules/bootstrap/dist/css/bootstrap.css';
// // import './box.css';
// // function TechnicianAccount() {
// //     return (  
// //         <div className="container" >
      
// //         <div className="table-responsive">
// //             <table className="table table-hover">
// //                 <tbody>
// //                     <tr>
// //                         <td >
// //                             Your Assignd Orders
// //                         </td>
// //                         <td >
// //                            Edit Profile
// //                         </td>
// //                         <td >
// //                            Update Inventory
// //                            technicalaccount       </td>
// //                     </tr>
// //                 </tbody>
// //             </table>    
// //         </div>
    
// //     </div>
// //     );
// // }

// // export default TechnicianAccount;