import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'

import { InsertProduct } from '../../services/product';

function LaunchNewService() {

 
 // const [productId, setProductId] = useState('')
  const [productName, setProductName] = useState('')
  const [productDesc, setProductDesc] = useState('')
  const [productMfgDate, setProductMfgDate] = useState('')
  const [productExpDate, setProductExpDate] = useState('')
  const [productPrice, setProductPrice] = useState('')


  const navigate = useNavigate()
  

  const addNewService = async () => {
    if (productName.length == '') {
      toast.error('Please enter Product Name')
    } else if (productDesc.length == '') {
      toast.error('Please enter Product Desc')
    } else if (productMfgDate.length == '') {
      toast.error('Please enter Starting Date')
    } else if (productPrice.length == '') {
      toast.error('Please enter Product price')
    } else {
      // call register api
      const response = await InsertProduct(productName, productDesc,productMfgDate,productExpDate,productPrice)
      if(response){
        console.log(response)
        toast.success('Product is launch successfully ')
        navigate('/ProductCatalogue')
      } else {
        toast.error('Product is not added successfully')
        navigate('/ProductCatalogue')
      }
    }
  }
   
   return (
    <div>
      <h1 style={{ textAlign: 'center', margin: 10 }}>Launch New Service</h1>

      <div className='row'>
        <div className='col'></div>
        <div className='col'>
          <div className='form'>

            <div className='mb-3'>
              <label htmlFor=''>Service Name</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setProductName(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Service Description</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setProductDesc(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Service Start Date</label>
              <input
                type='date'
                className='form-control'
                onChange={(e) => {
                  setProductMfgDate(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Service End Date</label>
              <input
                type='date'
                className='form-control'
                onChange={(e) => {
                  setProductExpDate(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Service base Price</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setProductPrice(e.target.value)
                }}
              />
            </div>
            
            <div className='mb-3'>
              {/* <div className='mb-3'>
                Don't have an account? <Link to='/register'>Register here</Link>
              </div> */}
              <button onClick={addNewService} className='btn btn-success'>
                Launch
              </button>
            </div>
          </div>
        </div>
         <div className='col'></div>
      </div>
  </div>
  )
}

export default LaunchNewService;