import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'

import { insertFeedback as insertFeedbackApi } from '../../services/feedback-service ';

function AddFeedbackToOrder() {

  const {id} = useParams()
  //const [orderId,setOrderId] = useState('')
  const [rating, setRating] = useState('')
  const [remarks, setRemarks] = useState('')
  //const [feedbackDate, setFeedbackDate] = useState('')

  const navigate = useNavigate()

  const insertFeedback= async () => {
    console.log()
      // call register api
      const response = await insertFeedbackApi(id,rating, remarks)
      console.log(response)
      if(response){
        
        console.log(response)
        toast.success('feedback added successfully')
        navigate('/AllFeedbackDetails')
      } else {
        toast.info('Thanks for ypur Response. Feedback already added for this order !!')
        navigate('/AllFeedbackDetails')
      }
    
  }

  // const handleVehicleTypeChange = (e) => {
  //   setVehicleType(e.target.value);
  // };

   return (
    <div>
      <h1 style={{ textAlign: 'center', margin: 10 }}>Add feedback to order</h1>

      <div className='row'>
        <div className='col'></div>
        <div className='col'>
          <div className='form'>

            <div className='mb-3'>
              <label htmlFor=''>Rating to Vehicle Servicing</label>
              <input type='text'
                className='form-control'
                onChange={(e) => {
                  setRating(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Remarks on order</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setRemarks(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              {/* <div className='mb-3'>
                Don't have an account? <Link to='/register'>Register here</Link>
              </div> */}
              <button onClick={insertFeedback} className='btn btn-success'>
                Add
              </button>
            </div>


          </div>
        </div>
        <div className='col'></div>
      </div>
    </div>
  )
}

export default AddFeedbackToOrder;