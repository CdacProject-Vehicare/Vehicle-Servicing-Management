import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'

import { insertVehicle as insertVehicleApi } from '../../services/vehicle-service';

function AddNewVehicleToOrder() {

  const [vehicleMfg, setVehicleMfg] = useState('')
  const [vehicleName, setVehicleName] = useState('')
  const [vehicleType, setVehicleType] = useState('')
  const [vehicleNo, setVehicleNo] = useState('')


  //const [selectedOption, setSelectedOption] = useState('');


  const navigate = useNavigate()
  const { id } = useParams();

  const insertVehicle= async () => {
    if (vehicleName.length == '') {
      toast.error('Please enter Vehicle Name')
    } else if (vehicleMfg.length == '') {
      toast.error('Please enter Vehicle company')
    } else if (vehicleType.length == '') {
      toast.error('Please enter Vehicle Type')
    } else if (vehicleNo.length == '') {
      toast.error('Please Enter Vehicle Number')
    }  else {
      // call register api
      const response = await insertVehicleApi(id,vehicleMfg, vehicleName,vehicleType,vehicleNo)
      console.log(response)
      if(response){
        
        console.log(response)
        toast.success('Vehicle added successfully')
        navigate('/CustomerDashBoard')
      } else {
        toast.info('Vehicle already added ')
        navigate('/CustomerDashBoard')
      }
    }
  }



  // const handleVehicleTypeChange = (e) => {
  //   setVehicleType(e.target.value);
  // };

  const handleVehicleTypeChange = (e) => {
    setVehicleType(e.target.value);
  };



   
   return (
    <div>
      <h1 style={{ textAlign: 'center', margin: 10 }}>Add Vehicle</h1>

      <div className='row'>
        <div className='col'></div>
        <div className='col'>
          <div className='form'>

            <div className='mb-3'>
              <label htmlFor=''>Vehicle Name</label>
              <input type='text'
                className='form-control'
                onChange={(e) => {
                  setVehicleName(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Vehicle company</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setVehicleMfg(e.target.value)
                }}
              />
            </div>

            {/* <div className='mb-3'>
              <label htmlFor=''>Vehicle Type</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setVehicleType(e.target.value)
                }}
              />
            </div> */}




            {/* <div className='mb-3'>
              <label htmlFor='vehicleType'>Vehicle Type</label>
              <input
                type='text'
                id='vehicleType'
                className='form-control'
                value={vehicleType}
                onChange={handleVehicleTypeChange}
              />
            </div> */}

            <div className='mb-3'>
                <label htmlFor='vehicleOptions'>Vehicle Type</label>
                <select
                  id='vehicleOptions'
                  className='form-control'
                  value={vehicleType}
                  onChange={handleVehicleTypeChange}
                >
                  <option value=''>Select an option</option>
                  <option value='TWOWHEELER'>2W</option>
                  <option value='FOURWHEELER'>4W</option>
                </select>
            </div>


            <div className='mb-3'>
              <label htmlFor=''>Vehicle no</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setVehicleNo(e.target.value)
                }}
              />
            </div>
            
            <div className='mb-3'>
              {/* <div className='mb-3'>
                Don't have an account? <Link to='/register'>Register here</Link>
              </div> */}
              <button onClick={insertVehicle} className='btn btn-success'>
                Add Vehicle to order
              </button>
            </div>
          </div>
        </div>
        <div className='col'></div>
      </div>
    </div>
  )
}

export default AddNewVehicleToOrder;