
import React from 'react';
import { useNavigate } from 'react-router-dom'
// import { useHistory } from 'react-router-dom';
// import '../../node_modules/bootstrap/dist/css/bootstrap.css';
import '../../../node_modules/bootstrap/dist/css/bootstrap-grid.css';
import './../../CssFiles/checkbox.css'
import './../../CssFiles/backgroun.css'

function BookServiceOrder() {

  //const history = useHistory();
  const navigate = useNavigate()
  const handleButtonClick = () => {

    navigate('/Home')
    // history.push("/home");
   };

   
  //  return (
  //   <div>
  //     <h1 style={{ textAlign: 'center', margin: 10 }}>Launch New Service</h1>

  //     <div className='row'>
  //       <div className='col'></div>
  //       <div className='col'>
  //         <div className='form'>

            // <div className='mb-3'>
            //   <label htmlFor=''>Service Name</label>
            //   <input
            //     type='text'
            //     className='form-control'
            //     onChange={(e) => {
            //       setProductName(e.target.value)
            //     }}
            //   />
            // </div>

  //           <div className='mb-3'>
  //             <label htmlFor=''>Service Description</label>
  //             <input
  //               type='text'
  //               className='form-control'
  //               onChange={(e) => {
  //                 setProductDesc(e.target.value)
  //               }}
  //             />
  //           </div>

  //           <div className='mb-3'>
  //             <label htmlFor=''>Service Start Date</label>
  //             <input
  //               type='date'
  //               className='form-control'
  //               onChange={(e) => {
  //                 setProductMfgDate(e.target.value)
  //               }}
  //             />
  //           </div>

  //           <div className='mb-3'>
  //             <label htmlFor=''>Service End Date</label>
  //             <input
  //               type='date'
  //               className='form-control'
  //               onChange={(e) => {
  //                 setProductExpDate(e.target.value)
  //               }}
  //             />
  //           </div>

  //           <div className='mb-3'>
  //             <label htmlFor=''>Service base Price</label>
  //             <input
  //               type='text'
  //               className='form-control'
  //               onChange={(e) => {
  //                 setProductPrice(e.target.value)
  //               }}
  //             />
  //           </div>
            
  //           <div className='mb-3'>
  //             {/* <div className='mb-3'>
  //               Don't have an account? <Link to='/register'>Register here</Link>
  //             </div> */}
  //             <button onClick={addNewService} className='btn btn-success'>
  //               Launch
  //             </button>
  //           </div>
  //         </div>
  //       </div>
  //       <div className='col'></div>
  //     </div>
  //   </div>
  // )



    return (
    <>
   <div style={{backgroundImage:"url('../../../public/Background/pngtree-car-repair-service-image_2364299.jpg')"}} >

      
          <br/>
          <h3>Service Booking</h3>
          <hr></hr>

          <div className='row'>
               
               <div className='col'>
                        <h1> Select Services</h1>
                        <br/><br/>
                        <div>
                          <label className="container">
                          <input type="checkbox" defaultChecked={true} />
                              Denting and Painting
                          <span className="checkmark"></span>
                          </label>
                        </div> 

                        <div>
                          <label className="container">
                          <input type="checkbox" defaultChecked={true} />
                              Denting and Painting
                          <span className="checkmark"></span>
                          </label>
                        </div> 

                        <div>
                          <label className="container">
                          <input type="checkbox" defaultChecked={true} />
                              Denting and Painting
                          <span className="checkmark"></span>
                          </label>
                        </div> 
                        



        
                      </div>

                          
                        <div className='col'> 
                                      {/* <label class="container">One
                                    <input type="checkbox" checked="checked">
                                    <span class="checkmark"></span>
                                  </label>

                                  <label class="container">Two
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                  </label>

                                  <label class="container">Three
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                  </label>

                                  <label class="container">Four
                                    <input type="checkbox">
                                    <span class="checkmark"></span>
                                  </label> */}

                        
                          {/* <br/><br/>
                            <h2> Select TimeSlot</h2>
                            <br/>

                          <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                              <label class="form-check-label" for="inlineRadio1">9:00 - 11:00</label>
                            </div>

                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" />
                              <label class="form-check-label" for="inlineRadio1">11:00 - 1:00</label>
                              <label class="form-check-label" for="inlineRadio2"></label>
                            </div>

                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" />
                              <label class="form-check-label" for="inlineRadio1">2:00 - 4:00</label>
                              <label class="form-check-label" for="inlineRadio2"></label>
                            </div>

                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" />
                              <label class="form-check-label" for="inlineRadio1">4:00 - 6:00</label>
                              <label class="form-check-label" for="inlineRadio2"></label>
                            </div>

                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3" disabled />
                              <label class="form-check-label" for="inlineRadio3">6:00 - 8:00 (Service NOT available at this Slot)</label>
                            </div> */}
                          </div>
                    </div> 
                    <div className='col'>

                    <table>
                              <tbody>
                              {/* <tr>
                                  <td>ServiceType</td>
                                  <td>
                                    <input type="text" value="" />
                                  </td>
                                </tr> */}

                                <tr>
                                  <td>Date</td>
                                  <td>
                                    {/* <input type="datetime-local" value="" /> */}
                                    <input type="datetime-local" defaultValue="2023-06-01T12:00" />
                                  </td>
                                </tr>

                                {/* <tr>
                                  <td>timeslot</td>
                                  <td>
                                    <input type="text" value="" />
                                  </td>
                                </tr>*/}
                                <tr> 
                                  <td>Vehicle</td>
                                  <td>
                                  <select class="select">
                                        <option value="1">Bike 1</option>
                                        <option value="2">Bike 1</option>
                                        <option value="3">Bike 1</option>
                                        <option value="4">Car 1</option>
                                        <option value="5">car 2</option>
                                  </select>
                                  </td>
                                </tr>
                                <tr>
                                  <td colSpan="2">
                                    <button className='btn btn-success' onClick={handleButtonClick}>BookNow</button>
                                  </td>
                                </tr>

                              </tbody>
                            </table>

                    </div>
                        <br/><br/>
    </div> 
    </>
    
    );
}

export default BookServiceOrder;



{/* <div>
      <label className="container">
      <input type="checkbox" defaultChecked={true} />
        One
        <span className="checkmark"></span>
      </label>
    </div> 
*/}

    // <div className='col'></div>




//     <div class="form-check">
                                
//     <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault" style={{ marginLeft: '850px' }}/>
//     <label class="form-check-label" htmlfor="flexCheckDefault" style={{ marginRight: '900px' }}>Denting and Painting</label>

// </div>

// <div class="form-check">
// <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" style={{ marginLeft: '850px' }} />
// <label class="form-check-label" for="flexCheckChecked" style={{ marginRight: '900px' }}>AC repairs</label>
// </div>
// <div class="form-check">
// <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" style={{ marginLeft: '850px' }} />
// <label class="form-check-label" for="flexCheckChecked" style={{ marginRight: '900px' }}>Battery Replacement</label>
// </div>
// <div class="form-check">
// <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" style={{ marginLeft: '850px' }} />
// <label class="form-check-label" for="flexCheckChecked" style={{ marginRight: '900px' }}>Detailing Services</label>
// </div>

// <div class="form-check">
// <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" style={{ marginLeft: '850px' }} />
// <label class="form-check-label" for="flexCheckChecked" style={{ marginRight: '900px' }}>Car spa and Cleaning</label>
// </div>
// <div class="form-check">
// <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" style={{ marginLeft: '850px' }} />
// <label class="form-check-label" for="flexCheckChecked" style={{ marginRight: '900px' }}>Car Inspection</label>
// </div>
// <div class="form-check">
// <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" style={{ marginLeft: '850px' }} />
// <label class="form-check-label" for="flexCheckChecked" style={{ marginRight: '900px' }}>Susspension and fitment</label>
// </div>
// <div class="form-check">
// <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" style={{ marginLeft: '850px' }} />
// <label class="form-check-label" for="flexCheckChecked" style={{ marginRight: '900px' }}>Cluth and Body Repair</label>
// </div>


  