import React from 'react';
//import { useHistory } from 'react-router-dom';

import { Link, useNavigate } from 'react-router-dom'
//import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
//import '../box.css';
import '../../CssFiles/box.css';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css'
import { Container, Row, Col } from "react-bootstrap";


function CustomerAccount() {
//   const history = useHistory();
const navigate = useNavigate()

  
  const handleYoursOrdersClick = () => {
    // Handle click for "Your Assigned Orders"
    // You can navigate to a specific route or perform any other action here
    navigate("/GetAllOrdersDetailsListByCustomerId")
        //history.push("/TechnicianAssignedOrders");
      
};

const name = (sessionStorage.getItem('name'));

  const handleEditProfileClick = () => {
    // Handle click for "Edit Profile"
    // You can navigate to a specific route or perform any other action here
    navigate("/EditCustomerProfile")
    //history.push("/TechnicianRegistration");
  };

  const handleUpdateInventoryClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/Inventory")
    //history.push("/Inventory");
};
const handleToReportClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/FutureScope")
    // history.push("/piechart");
};

const handleCustomerDashBoardClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/CustomerDashBoard")
    // history.push("/piechart");
};

const handleGetAllFeedbackClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/AllFeedbackDetails")
    // history.push("/piechart");
};

const handleUpdateServicesClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/piechart")
    // history.push("/piechart");
};


const addtocart = () => {
  // Handle click for "Update Inventory"
  // You can navigate to a specific route or perform any other action here
  navigate("/productgallery");
};

return (
    <Container>
      
      <Row className="admin-dashboard">
        <Col xs={12} className="text-center"> 
        <h2 className="admin-title">Hello, {name}</h2>  
        </Col>

        <Row className="text-center"> 
          <div className="admin-options">
            <Col className="options-column">

            <Row className="admin-option" onClick={addtocart}>
                book Order
              </Row>
              
              <Row className="admin-option" onClick={handleYoursOrdersClick}>
              Your Orders
              </Row>

              {/* <Row className="admin-option" onClick={handleAddVehicleToOrderClick}>
                Add vehicle
              </Row> */}

              {/* <Row className="admin-option" onClick={handleAddFeedbackClick}>
                Add all feedback
              </Row> */}
  
              <Row className="admin-option" onClick={handleEditProfileClick}>
              Edit Profile
              </Row>

              {/* <Row className="admin-option" onClick={handleUpdateInventoryClick}>
              Update Inventory
              </Row> */}

              {/* <Row className="admin-option" onClick={handleUpdateTechnicianClick}>
                Update Technician Profile
              </Row> */}
            </Col>

            <Col className="options-column" >
              
              <Row className="admin-option" onClick={handleToReportClick}>
                Generate Report
              </Row>

              <Row className="admin-option" onClick={handleCustomerDashBoardClick}>
               Dashboard
              </Row>

              <Row className="admin-option" onClick={handleGetAllFeedbackClick}>
                Get all feedback
              </Row> 
{/* 
              <Row className="admin-option" onClick={handleGetAllFeedbackClick}>
              Total Rating
              </Row> */}

              {/* <Row className="admin-option" onClick={handleUpdateServicesClick}>
                Add feedback 
              </Row> */}

              {/* <Row className="admin-option" onClick={handleUpdateTimeSlotsClick}>
                Update Time-slots
              </Row> */}

              {/* <Row className="admin-option" onClick={handleUpdateInventoryClick}>
                Update Inventory
              </Row> */}
            </Col>
          </div>
        </Row>
      </Row>

      {/* <Row>

      </Row> */}
    </Container>
  );
}


//   return (<> 
//    <center> <h1>Your Account</h1></center>   
//     <div className="container">
//         <br/><br/>
//         <div className="box-container">
                
//             <table>
//                 <tr>
//                     <td>
//                         <div className="box" onClick={handleAssignedOrdersClick}>
//                     Your Assigned Orders
//                         </div>

                        
//                     </td>
//                     <td>
//                     <div className="box" onClick={handleEditProfileClick}>
//                     Edit Profile
//                 </div>
//                     </td>

//                     <td>
//                         <div className="box" onClick={handleUpdateInventoryClick}>
//                         Update Inventory
//                         </div>
//                     </td>
//                     </tr>


//                     <tr>
//                     <td>
//                     <div className="box" onClick={handleToReortClick}>
//                     Generate Report
//                 </div>
//                     </td>
//                     <td>
//                     <div className="box" onClick={handleUpdateInventoryClick}>
//                     Work-LogIn
//                     </div>
//                     </td>
//                     <td>
//                     <div className="box" onClick={handleUpdateInventoryClick}>
//                     Total Rating
//                     </div>
//                     </td>

//                 </tr>
//             </table>

//         </div>
//     </div>
//     </>

//   );
// }

export default CustomerAccount;




// import React from 'react';
// import { useHistory } from 'react-router-dom';
// import '../../node_modules/bootstrap/dist/css/bootstrap.css';
// import './box.css';
// function TechnicianAccount() {
//     return (  
//         <div className="container" >
      
//         <div className="table-responsive">
//             <table className="table table-hover">
//                 <tbody>
//                     <tr>
//                         <td >
//                             Your Assignd Orders
//                         </td>
//                         <td >
//                            Edit Profile
//                         </td>
//                         <td >
//                            Update Inventory
//                            technicalaccount       </td>
//                     </tr>
//                 </tbody>
//             </table>    
//         </div>
    
//     </div>
//     );
// }

// export default TechnicianAccount;