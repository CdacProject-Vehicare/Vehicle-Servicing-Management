import React, { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import { getOrdersList } from '../../services/orders';
import { constants } from '../../utils/constants';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { getOrdersListByCustomerId } from '../../services/orders';
// import { UpdateOrderPaymentStatusApi } from '../../services/orders';
// import { UpdateOrderStatusApi } from '../../services/orders';
function GetAllOrdersDetailsListByCustomerId() {
  const [ordersDetails, setOrdersDetails] = useState([]);
  const navigate = useNavigate();
  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    try {
      const response = await getOrdersListByCustomerId(sessionStorage.getItem('id'));
      if (response) {
        const ordersData = response.data;
        
          setOrdersDetails(ordersData);
       
        
      } else {
        toast.error('Error while calling get /Orders api');
      }
    } catch (error) {
      console.error('Error while loading orders:', error);
    }
  };

  // const handleOrderUpdate = async (orderId) => {
  //   // Handle edit logic for the specific order

  //   const response = await UpdateOrderPaymentStatusApi(orderId)
  //   //if (response['status'] === 'success') {
  //     if(true){
  //       console.log("in the UpdateOrderPaymentStatusApi ");
  //       //console.log(response)
  //     //  setProducts(response.data)
  //      // console.log("products-------------"+products)

  //   } else {
  //     toast.error('Error while calling get /product api')
  //   } 
   
  //   loadOrders()




  //   console.log('OrderUpdate with ID:', orderId);
  // };


  // const loadProducts = async () => {
  //   const response = await getProductList()
  //   //if (response['status'] === 'success') {
  //     if(true){
  //       console.log("in the Product page");
  //       console.log(response)
  //       setProducts(response.data)
  //       console.log("products-------------"+products)

  //   } else {
  //     toast.error('Error while calling get /product api')
  //   }
  // }


  // const handlePaymentUpdate =  async(orderId) => {
  //   // Handle delete logic for the specific order
  //         /////////////////////////UpdateOrderStatusApi/////////////////////

  //         const response = await UpdateOrderStatusApi(orderId)
  //         //if (response['status'] === 'success') {
  //           if(true){
  //             console.log("in the UpdateOrderPaymentStatusApi ");
  //             //console.log(response)
  //           //  setProducts(response.data)
  //            // console.log("products-------------"+products)
      
  //         } else {
  //           toast.error('Error while calling get /product api')
  //         } 
         
  //         loadOrders()
      
      


  //   console.log('PaymentUpdate with ID:', orderId);
  // };


  const handleinventorydetails = (id) => {
    // Handle delete logic for the specific order
    console.log('show/Add/Remove inventory order with orderdetails ID:', id);
    navigate('/OrdersInventoryDetails/'+id)
  };

  // const handleUpdateinventoryUsed = (orderId,productId) => {
  //   // Handle delete logic for the specific order
  //   console.log('Update inventory order with orderdetails ID:'+orderId);
  //   console.log('Update inventory order with product ID:'+productId);
  //   navigate("/InventoryUsage/"+orderId+"/"+productId)
  // };

  return (
    <div>
      <h1 style={{ textAlign: 'center', margin: 10 }}>Customer Dashboard</h1>
      <table className='table table-striped table-hover' style={{ marginTop: 50 }}>
        <thead>
          <tr>
            <th>Customer First Name</th>
            <th>Customer Last Name</th>
            <th>Order ID</th>
            <th>Product ID</th>
            <th>Payment Status</th>
            <th>Order Status</th>
            <th>Price</th>
            <th>Product Name</th>
            {/* <th>Vehicle Name</th>
            <th>Vehicle Number</th> */}
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {ordersDetails.map((od) => (
            <tr key={od.orderId}>
              <td>{od.customerFirstname}</td>
              <td>{od.customerLastName}</td>
              <td>{od.orderId}</td>
              <td>{od.productId}</td>           
              <td>{od.paymentstatus}</td>
              <td>{od.status}</td>
              <td>{od.price}</td>
              <td>{od.productName}</td>
              {/* <td>{od.vehicleName}</td>
              <td>{od.vehicleNo}</td> */}
              {/* <td>
                <button
                  className='btn btn-sm btn-primary sm-2'
                  onClick={() => handleOrderUpdate(od.orderId)}
                >
                  Update Order Status
                </button>
              </td> */}
              <td>
                <button
                  className='btn btn-sm btn-warning sm-2'
                  onClick={() => navigate('/AddFeedbackToOrder/'+od.orderId)}
                >
                  Add Feedback
                </button>
               </td> 
               

              

                
                <button
                  className='btn btn-sm btn-success sm-2'
                  onClick={() => navigate('/AddNewVehicleToOrder/'+od.orderId)}
                >
                  Add Vehicle
                   {/* <Link to={`/pageB/${key}/${value}`}>get inventory details </Link>
                   */}
                </button>

                <button
                  className='btn btn-sm btn-success sm-2'
                  onClick={() => navigate('/GetVehicleDetails/'+od.orderId)}
                >
                  get Vehicle Details
                   {/* <Link to={`/pageB/${key}/${value}`}>get inventory details </Link>
                   */}
                </button>

                <button
                  className='btn btn-sm btn-info sm-2'
                  onClick={() => handleinventorydetails(od.orderId)}
                >
                  get inventory details
                   {/* <Link to={`/pageB/${key}/${value}`}>get inventory details </Link>
                   */}
                </button>
              <td>
                {/* <button
                  className='btn btn-sm btn-info sm-2'
                 
                  onClick={() => handleUpdateinventoryUsed(od.orderId, od.productId)}
              >
                  update inventory details {od.orderId} {od.productId}
                </button> */}
               </td> 
              
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default GetAllOrdersDetailsListByCustomerId;







// import { useEffect, useState } from 'react'
// import { toast } from 'react-toastify'
// import { getOrdersList }  from '../../services/orders'
// import { constants } from '../../utils/constants'
// function GetAllOrdersDetailsList() {
//   const [ordersDetails, setordersDetails] = useState([])
  
//   useEffect(() => {
//     // get the list of products from server
//     console.log("in component did mount")
//     loadOrders()
//   }, [])

//   const loadOrders = async () => {
//     const response = await getOrdersList()
//     //if (response['status'] === 'success') {
//       if(true){
//         console.log("in the Orders page");
//         console.log(response)
//         //console.log(JSON.parse(response))
//         setordersDetails(response.data)
//         console.log("Orders-------------"+ordersDetails)

//     } else {
//       toast.error('Error while calling get /Orders api')
//     }
//   }

//   return (
//     <div>
//       <h1 style={{ textAlign: 'center', margin: 10 }}>Product Gallery</h1>
//       <div className='row' style={{ marginTop: 50 }}>
//         {ordersDetails.map((od) => {
//           return (
//             <div className='col-md-3'>
//               <div className='card'>
//                 <img
//                   src={constants.serverUrl + '/'}
//                   style={{ height: 200 }}
//                   alt=''
//                 />
//                 {/* [{"productId":1,"productName":"washing","productDesc":"string","productMfgDate":"2023-08-22","productExpDate":"2023-08-22","productPrice":200.0} */}
//                 <div className='card-body'>
//                   <h5 className='card-title'></h5>
//                   <div className='card-text'>
//                     {/* <div>{product['company']}</div>
//                     <div>₹ {product['price']}</div> */}
//                         <div>{od['customerFirstname']}</div>
//                         <div>{od['customerLastName']}</div>
//                         <div>{od['orderDetailsId']}</div>
//                         <div>{od['paymentstatus']} </div>
//                         <div>{od['price']} </div>
//                         <div>{od['productName']} </div>
//                         <div>{od['vehicleName']} </div>
//                         <div>{od['vehicleNo']} </div>

                        
//                   </div>
//                 </div>
//               </div>
//             </div>
//           )
//         })}
//       </div>
//     </div>
//   )
// }
  


// export default GetAllOrdersDetailsList
// // customerFirstname
// // : 
// // "new_firstname"
// // customerLastName
// // : 
// // "string"
// // orderDetailsId
// // : 
// // 2
// // orderId
// // : 
// // 2
// // paymentstatus
// // : 
// // null
// // price
// // : 
// // 100
// // productName
// // : 
// // "string"
// // status
// // : 
// // null
// // technicianAssigned
// // : 
// // null
// // vehicleName
// // : 
// // "g6"
// // vehicleNo
// // : 
// // "mustang"

