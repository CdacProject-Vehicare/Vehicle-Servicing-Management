import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { updateCustomer as updateCustomerApi } from '../../services/customer-service'

//import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css'
//import '../../node_modules/bootstrap/dist/css/bootstrap.min.css'
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css'


import { getCustomerById } from '../../services/customer-service'

function EditCustomerProfile() {
  // const [firstName, setFirstName] = useState('')
  // const [lastName, setLastName] = useState('')
  // const [email, setEmail] = useState('')
  // const [mobile, setMobile] = useState('')
  // const [password, setPassword] = useState('')
  // const [confirmPassword, setConfirmPassword] = useState('')

  const [customerId, setId] = useState('')
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [email, setEmail] = useState('')
  const [address, setAddress] = useState('') 
  const [password, setPassword] = useState('')
  const [phone, setPhone] = useState('956049991')
  const [confirmPassword, setConfirmPassword] = useState('')

  // get the navigation object
  const navigate = useNavigate()
  useEffect(() => {
    // get the list of products from server
    console.log("in component did mount")
    fetchDetailsOfCustomer()
  }, [])

  const fetchDetailsOfCustomer = async () => {
    const response = await getCustomerById(sessionStorage.getItem('id'))
    //if (response['status'] === 'success') {
      if(true){
        console.log("in the Technician profile edit ");
        console.log(response)
        setId(sessionStorage.getItem('id'))
        setFirstName(response.data.firstName)
        setLastName(response.data.lastName)
        setEmail(response.data.email)
        setPassword(response.data.password)
        setAddress(response.data.address)
        setPhone(response.data.phone)
        setConfirmPassword(response.data.confirmPassword)
        
        //setProducts(response.data)
        console.log("Technician-------------"+response)

    } else {
      toast.error('Error while calling get /product api')
    }
  }


  const updateCustomer = async () => {
    if (firstName.length == '') {
      toast.error('Please enter first name')
    }
     else if (lastName.length == '') {
      toast.error('Please enter last name')
    } 
    else if (email.length == '') {
      toast.error('Please enter email')
    }  
    else if (password.length == '') {
      toast.error('Please enter password')
    } 
    else if (address.length == '') {
      toast.error('Please enter adress')
    }

    else if (phone.length == '') {
      toast.error('Please enter mobile No')
    }
   
    
    if (password !== confirmPassword) {
      toast.error('Password does not match')
    } else {
      // call register api
      const response = await updateCustomerApi(
        customerId,
        firstName,
        lastName,
        email,
        password,
        address,
      
        phone,
       
      )

      // parse the response
      if (response) {
        toast.success('Successfully update user profile')

        // go back to login
        navigate('/CustomerAccount')
      } else {
        toast.error('Error while registering a new user, please try again')
      }
    }
  }
  return (
    <div>
      <h1 style={{ textAlign: 'center', margin: 10 }}>Welcome, {firstName}</h1>

      <div className='row'>
        <div className='col'></div>
        <div className='col'>
          <div className='form'>

            <div className='mb-3'>
              <label htmlFor=''>First Name</label>
              <input
                type='text'
                className='form-control'
                value={firstName}
                onChange={(e) => {
                  setFirstName(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Last Name</label>
              <input
                type='text'
                className='form-control'
                value={lastName}
                onChange={(e) => {
                  setLastName(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Email</label>
              <input
                type='text'
                className='form-control'
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Password</label>
              <input
                type='password'
                className='form-control'
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Address</label>
              <input
                type='text'
                className='form-control'
                value={address}
                onChange={(e) => {
                  setAddress(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Phone Number</label>
              <input
                type='tel'
                className='form-control'
                value={phone}
                onChange={(e) => {
                  setPhone(e.target.value)
                }}
              />
            </div>

           
  


            <div className='mb-3'>
              <label htmlFor=''>Confirm Password</label>
              <input
                type='password'
                className='form-control'
                onChange={(e) => {
                  setConfirmPassword(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <button onClick={updateCustomer} className='btn btn-success'>
                Update
              </button>
            </div>
          </div>
        </div>
        <div className='col'></div>
      </div>
    </div>
  )
}

export default EditCustomerProfile;