import { useState } from 'react'
import { useDispatch } from 'react-redux'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
//import { login } from '../features/authSlice'
import { login } from '../../features/authSlice'
//import { loginTechnician as loginTechnicianApi } from '../services/user'

import { loginCustomerApi } from '../../services/customer-service'
function LoginCustomer() {
  const [email, setEmail] = useState('Pratik2014@gmail.com')
  const [password, setPassword] = useState('Pratik@1999')

  // get the navigation object
  const navigate = useNavigate()

  // get dispatcher object
  const dispatch = useDispatch()

  const loginTechnician = async () => {
    if (email.length == '') {
      toast.error('Please enter email')
    } else if (password.length == '') {
      toast.error('Please enter password')
    } else {
      // call register api
      const response = await loginCustomerApi(email, password)
      if(response){
      // parse the response
      //if (response['status'] === '200') {
        // parse the response's data and extract the token
        console.log(response)
        const {firstName} = response.data//['data']
        const {role} = response.data
        const {id} = response.data
        const {token}=response.data
        //const {role} = response.data
        // store the token for making other apis
       // sessionStorage['token'] = token
        sessionStorage['name'] = firstName
        sessionStorage['role'] = role
        sessionStorage['id'] = id
        sessionStorage['token']=token
       // sessionStorage['mobile'] = mobile
       // sessionStorage['profileImage'] = profileImage

        // update global store's authSlice with status = true
        dispatch(login())

        toast.success(`Welcome ${firstName} to store application`)
        if(role === "Customer")
        {
          navigate('/CustomerAccount')
        }
        else if(role === "Technician")
        {
          console.log('Inside Technician Condition');
          navigate('/src/components/Technician/TechnicianAccount.jsx')
          //navigate('/src/components/Technician/TechnicianAccount.jsx')



        }
        else if(role === "Admin")
        {
          navigate('/src/components/Admin/AdminAccount.jsx')
        }
        
        // go back to login
        //navigate('/product-gallery')
      } else {
        toast.error('Invalid user name or password')
        navigate('/login')
      }
    }
  }

  return (
    <div>
      <h1 style={{ textAlign: 'center', margin: 10 }}>Vehicare Customer Login Customer</h1>

      <div className='row'>
        <div className='col'></div>
        <div className='col'>
          <div className='form'>
            <div className='mb-3'>
              <label htmlFor=''>Email</label>
              <input
                type='text'
                className='form-control'
             
                onChange={(e) => {
                  setEmail(e.target.value)
                }}
              />
            </div>
            <div className='mb-3'>
              <label htmlFor=''>Password</label>
              <input
                type='password'
                className='form-control'
               
                onChange={(e) => {
                  setPassword(e.target.value)
                }}
              />
            </div>
            <div className='mb-3'>
              <div className='mb-3'>
                Don't have an account? <Link to='/RegisterUser'>Register here</Link>
              </div>
              <button onClick={loginTechnician} className='btn btn-success'>
                Login
              </button>
            </div>
          </div>
        </div>
        <div className='col'></div>
      </div>
    </div>
  )
}

export default LoginCustomer
