import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
//import { registerTechnician as registerTechnicianApi } from '../../services/user'
import { registerCustomerApi } from '../../services/customer-service'

function RegisterUser() {
  // const [firstName, setFirstName] = useState('')
  // const [lastName, setLastName] = useState('')
  // const [email, setEmail] = useState('')
  // const [mobile, setMobile] = useState('')
  // const [password, setPassword] = useState('')
  // const [confirmPassword, setConfirmPassword] = useState('')

  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [email, setEmail] = useState('')
  const [address, setAddress] = useState('') 
  const [password, setPassword] = useState('')
  const [joinDate, setJoinDate] = useState('') 
  const [phone, setPhone] = useState('')
  const [gender, setGender] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [role,setRole]=useState('')

  // get the navigation object
  const navigate = useNavigate()

  const registerUser = async () => {
    setRole('Customer')
    
    if (firstName.length == '') {
      toast.error('Please enter first name')
    }
     else if (lastName.length == '') {
      toast.error('Please enter last name')
    } 
    else if (email.length == '') {
      toast.error('Please enter email')
    }  
    else if (password.length == '') {
      toast.error('Please enter password')
    } 
    else if (address.length == '') {
      toast.error('Please enter address')
    }
    // else if (joinDate.length == '') {
    //   toast.error('Please enter Date Of Birth')
    // }
    else if (phone.length == '') {
      toast.error('Please enter mobile No')
    }
    else if (gender.length == '') {
      toast.error('Please enter Gender')
    }
    
    if (password !== confirmPassword) {
      toast.error('Password does not match')
    } else {
      // call register api
      const response = await registerCustomerApi(
        firstName,
        lastName,
        email,
        password,
        phone,
        address,
        role
      )


      // {
      //   "customerId": 0,
      //   "firstName": "string",
      //   "lastName": "string",
      //   "email": "string",
      //   "password": "string",
      //   "phone": "string",
      //   "address": "string",
      //   "role": "string"
      // }

      // parse the response
      if (response['firstName']) {
        toast.success('Successfully registered a new user')

        // go back to login
        navigate('/')
      } else {
        toast.error('Error while registering a new user, please try again')
      }
    }
  }
  return (
    <div>
      <h1 style={{ textAlign: 'center', margin: 10 }}>New User Registration</h1>

      <div className='row'>
        <div className='col'></div>
        <div className='col'>
          <div className='form'>

            <div className='mb-3'>
              <label htmlFor=''>First Name</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setFirstName(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Last Name</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setLastName(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Email</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setEmail(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Password</label>
              <input
                type='password'
                className='form-control'
                onChange={(e) => {
                  setPassword(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Address</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setAddress(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Mobile Number</label>
              <input
                type='tel'
                className='form-control'
                onChange={(e) => {
                  setPhone(e.target.value)
                }}
              />
            </div>

            {/* <div>
            <label htmlFor=''>Date of joinig</label>
              <input
                type="date"
                // value={selectedDate}
                onChange={(e) => {
                  setJoinDate(e.target.value)
                }}
              />
           </div> */}

            <div className='mb-3'>
              <label htmlFor=''>Gender</label>
              <input
                type='tel'
                className='form-control'
                onChange={(e) => {
                  setGender(e.target.value)
                }}
              />
            </div>


            <div className='mb-3'>
              <label htmlFor=''>Confirm Password</label>
              <input
                type='password'
                className='form-control'
                onChange={(e) => {
                  setConfirmPassword(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <div className='mb-3'>
                Already got an account? <Link to='/'>Login here</Link>
              </div>
              <button onClick={registerUser} className='btn btn-success'>
                Register
              </button>
            </div>
          </div>
        </div>
        <div className='col'></div>
      </div>
    </div>
  )
}

export default RegisterUser;