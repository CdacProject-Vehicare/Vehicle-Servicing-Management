import React from "react";


import '../../../node_modules/bootstrap/dist/css/bootstrap.css';

//import React from 'react';

const ShowServiceDetails = () => {
  return (
    <table style={{ minWidth: '70%', maxWidth: '75%' }}>
      <tr>
        <td>
          <div className="card mb-3" style={{ maxWidth: '800px' }}>
            <div className="row g-0">
              <div className="col-md-4">
                <img src="./Images/ACservice&repair.png" className="img-fluid rounded-start" alt="AC service and Repair" style={{height: '100%'}}/>
              </div>
              <div className="col-md-8">
                <div className="card-body">
                  <h5 className="card-title">AC service and Repair</h5>
                  <p className="card-text">It is not possible to avoid scratches when a vehicle plies on the road. However, car polish can effectively remove scratches from your car's surface that are not deep enough. It will give a smooth, even look to your car paint.</p>
                  <a href="/BookServiceOrder" className="btn btn-primary" >Book Service</a>
                 
                </div>
              </div>
            </div>
          </div>
        </td>
      </tr>

      <tr>
        <td>
          <div className="card mb-3" style={{ maxWidth: '800px' }}>
            <div className="row g-0">
              <div className="col-md-4">
                <img src="./Images/Batteries.png" className="img-fluid rounded-start" alt="Batteries" style={{height: '100%'}}/>
              </div>
              <div className="col-md-8">
                <div className="card-body">
                  <h5 className="card-title">Batteries</h5>
                  <p className="card-text">At Vehicare, the battery output will be checked, and if it is below the cranking ampere, then the car will be self-started. Using a backup battery, the alternator will be tested.</p>
                  <a href="/BookServiceOrder" className="btn btn-primary">Book Service</a>
                 
                </div>
              </div>
            </div>
          </div>
        </td>
      </tr>

      <tr>
        <td>
          <div className="card mb-3" style={{ maxWidth: '800px' }}>
            <div className="row g-0">
              <div className="col-md-4">
                <img src="./Images/Tyres.png" className="img-fluid rounded-start" alt="Tyres and Wheel alignment" style={{height: '100%'}}/>
              </div>
              <div className="col-md-8">
                <div className="card-body">
                  <h5 className="card-title">Tyres and Wheel Care</h5>
                  <p className="card-text">We maintain industry-level specifications at the recommended level and provide standard wheel alignment.</p>
                  <a href="/BookServiceOrder" className="btn btn-primary">Book Service</a>
                 
                </div>
              </div>
            </div>
          </div>
        </td>
      </tr>

      <tr>
        <td>
          <div className="card mb-3" style={{ maxWidth: '800px' }}>
            <div className="row g-0">
              <div className="col-md-4">
                <img src="./Images/Denting.png" className="img-fluid rounded-start" alt="Denting and Painting" style={{height: '100%'}}/>
              </div>
              <div className="col-md-8">
                <div className="card-body">
                  <h5 className="card-title">Denting and painting</h5>
                  <p className="card-text">At Vehicare, Denting and Painting consist of two components: One is removing dents and scratches on the vehicle's external body, which are then re-made to look like how it looked before deformation. The second is painting the body with the nearest matching paint.</p>
                  <a href="/BookServiceOrder" className="btn btn-primary">Book Service</a>
                 
                </div>
              </div>
            </div>
          </div>
        </td>
      </tr>

      <tr>
        <td>
          <div className="card mb-3" style={{ maxWidth: '800px' }}>
            <div className="row g-0">
              <div className="col-md-4">
                <img src="./Images/Detailing.png" className="img-fluid rounded-start" alt="Detailing Services" style={{height: '100%'}}/>
              </div>
              <div className="col-md-8">
                <div className="card-body">
                  <h5 className="card-title">Detailing Services</h5>
                  <p className="card-text">Car detailing is the process of improving the condition of a vehicle's interior and exterior appearance. This involves the most thorough clean possible, any enhancement to deal with minor defects such as clear coat scratches, and protection to maintain the condition.</p>
                  <a href="/BookServiceOrder" className="btn btn-primary">Book Service</a>
                 
                </div>
              </div>
            </div>
          </div>
        </td>
      </tr>

      <tr>
        <td>
          <div className="card mb-3" style={{ maxWidth: '800px' }}>
            <div className="row g-0">
              <div className="col-md-4">
                <img src="./Images/Carspa.png" className="img-fluid rounded-start" alt="Car Spa and cleaning" style={{height: '100%'}}/>
              </div>
              <div className="col-md-8">
                <div className="card-body">
                  <h5 className="card-title">Car Spa and cleaning</h5>
                  <p className="card-text">A car wash helps protect the paint on your car by clearing away acid rain, dirt, and road salt that can cause rust and corrosion to your car. Additionally, if you are concerned about reducing your carbon footprint, washing your car manually actually uses more water than at a car wash.</p>
                  <a href="/BookServiceOrder" className="btn btn-primary">Book Service</a>
                 
                </div>
              </div>
            </div>
          </div>
        </td>
      </tr>

      <tr>
        <td>
          <div className="card mb-3" style={{ maxWidth: '800px' }}>
            <div className="row g-0">
              <div className="col-md-4">
                <img src="./Images/Carinspection.png" className="img-fluid rounded-start" alt="car inspection" style={{height: '100%'}}/>
              </div>
              <div className="col-md-8">
                <div className="card-body">
                  <h5 className="card-title">car inspection</h5>
                  <p className="card-text">A detailed inspection of a car comprising nearly 24 checkpoints</p>
                  <a href="/BookServiceOrder" className="btn btn-primary">Book Service</a>
                 
                </div>
              </div>
            </div>
          </div>
        </td>
      </tr>
    </table>
  );
};

export default ShowServiceDetails;
