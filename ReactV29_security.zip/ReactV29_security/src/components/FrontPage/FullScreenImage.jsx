import React from 'react';

const FullScreenImage = () => {
  const containerStyle = {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    zIndex: -1, // Place the image behind other content
    overflow: 'hidden',
  };

  const imageStyle = {
    width: '100%',
    height: '100%',
    objectFit: 'cover', // Ensure the image covers the entire container
  };

  return (
    <div style={containerStyle}>
      <img 
            // src={}
            src={require("./../../assets/img/header.jpg")}
            alt="Full Screen" style={imageStyle} />
    </div>
  );
};

export default FullScreenImage;
