
function FutureScope() {

 

  return (
  <center> <h1> Future scope</h1></center>
  );
}

export default FutureScope;