// import '../../node_modules/bootstrap/dist/css/bootstrap.css';
import '../../../node_modules/bootstrap/dist/css/bootstrap.css';
import React from "react";
//import { useHistory } from 'react-router-dom';      // Put url in 
// import Carousel from './HomeComponent/Carousel';
import Carousel from '../../Screen/FrontPage/Carousel';
import Navbar from './HomeComponent/Navbar'
import CardGrid from './HomeComponent/CardGrid';
// import AllServices1 from './FrontPage/ALlService1';
import Footer from './HomeComponent/Footer';
import Sidebar from './HomeComponent/Sidebar';
import ProductGallery from '../Admin/ServiceCatalogue';
// *******************************************************************************************************************
import IndexNavbar from './HomeComponent/NavBars/IndexNavbar';
import IndexHeader from './HomeComponent/Headers/IndexHeader';
import AllServices1 from './HomeComponent/ALlService1';
import AllServiceDetails from './HomeComponent/AllServiceDetails';

// ****************************************************************
import Images from './views/index-sections/Images'
import CarouselSection from './views/index-sections/Carousel';
import FullScreenImage from './FullScreenImage';
import HeaderHome from './HomeComponent/HeaderHome';

function Home() {

    React.useEffect(() => {

        document.body.classList.add("index-page");
        document.body.classList.add("sidebar-collapse");
        document.documentElement.classList.remove("nav-open");
        window.scrollTo(0, 0);
        document.body.scrollTop = 0;

        return function cleanup() {
          document.body.classList.remove("index-page");
          document.body.classList.remove("sidebar-collapse");
        };
      });
  
    return (<>
                <IndexNavbar />
                <div className="wrapper">
                {/* <IndexHeader /> */}
                    < div className="body-limited">
                   
                        {/* <Images />   */}
                       <center> <HeaderHome></HeaderHome></center>
                       <br/><br/><br/><br/><br/><br/><br/>
                       <br/><br/><br/><br/><br/><br/><br/>
                       <br/><br/><br/><br/><br/><br/><br/>
                       <br/><br/><br/><br/><br/><br/><br/>
                       <br/><br/><br/><br/><br/><br/><br/>
                       <center><Carousel></Carousel></center>
                        {/* <CarouselSection /> */}
                        {/* <AllServices1></AllServices1> */}
                        {/* <BasicElements /> */}
                        <AllServiceDetails/>
                        <CardGrid></CardGrid>
                        {/* <ProductGallery></ProductGallery> */}
                    </div>
                </div>

             
            </>
       

     );
}

export default Home;





{/* <Sidebar></Sidebar>
                        
<Navbar></Navbar>

<hr></hr>




<ProductGallery></ProductGallery>

<div>
<CardGrid></CardGrid>
</div>
<br/><br/>      
</div>
<Footer></Footer> */}