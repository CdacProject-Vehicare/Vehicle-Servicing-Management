



import React from 'react';
import { useNavigate } from 'react-router-dom';
import './../../../assets/css/AllServiceDetails.css'; // Import your custom CSS file for styling

function AllServiceDetails() {
  const navigate = useNavigate();

  const handleOnClick = () => {
    navigate('/productgallery');
  };

  const handleOnClickShowDetails = () => {
    navigate('/');
  };

  return (
    <div className="all-services-container">
      <center>
        <h1>Services</h1>
      </center>
      <div className="container">
        <div className="row">
          {/* Repeat this structure for each service */}
          <div className="col-lg-4 col-md-6 col-sm-12">
            <div className="service-box" onClick={handleOnClick}>
              <img
                src="http://localhost:3000/ImageFolder/ACServices.png"
                alt="AC Services"
              />
              <div className="service-title">AC Services</div>
            </div>
          </div>

          <div className="col-lg-4 col-md-6 col-sm-12" >
            <div className="service-box" onClick={handleOnClick}>
              <img
                src="http://localhost:3000/ImageFolder/Batteries.png"
                alt="Batteries"
              />
              <div className="service-title">Batteries</div>
            </div>
          </div>

          <div className="col-lg-4 col-md-6 col-sm-12">
            <div className="service-box" onClick={handleOnClick}>
              <img
                src="http://localhost:3000/ImageFolder/CarSpaService.png"
                alt="AC Services"
              />
              <div className="service-title">Car Spa Service</div>
            </div>
          </div>
        </div>
        
        <div className="row">
          <div className="col-lg-4 col-md-6 col-sm-12">
            <div className="service-box" onClick={handleOnClick}>
              <img
                src="http://localhost:3000/ImageFolder/CarInspectionService.png"
                alt="Batteries"
              />
              <div className="service-title">Batteries</div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 col-sm-12">
            <div className="service-box" onClick={handleOnClick}>
              <img
                src="http://localhost:3000/ImageFolder/CLutchService.png"
                alt="Batteries"
              />
              <div className="service-title">Batteries</div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 col-sm-12">
            <div className="service-box" onClick={handleOnClick}>
              <img
                src="http://localhost:3000/ImageFolder/DentingService.png"
                alt="Batteries"
              />
              <div className="service-title">Batteries</div>
            </div>
          </div>
        </div>

        <div className="row">
          <div className="col-lg-4 col-md-6 col-sm-12">
            <div className="service-box" onClick={handleOnClick}>
              <img
                src="http://localhost:3000/ImageFolder/CarInspectionService.png"
                alt="Batteries"
              />
              <div className="service-title">Batteries</div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 col-sm-12">
            <div className="service-box" onClick={handleOnClick}>
              <img
                src="http://localhost:3000/ImageFolder/CarInspectionService.png"
                alt="Batteries"
              />
              <div className="service-title">Batteries</div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 col-sm-12">
            <div className="service-box" onClick={handleOnClick}>
              <img
                src="http://localhost:3000/ImageFolder/CarInspectionService.png"
                alt="Batteries"
              />
              <div className="service-title">Batteries</div>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-lg-4 col-md-6 col-sm-12">
            <div className="service-box" onClick={handleOnClick}>
              <img
                src="http://localhost:3000/ImageFolder/CarInspectionService.png"
                alt="Batteries"
              />
              <div className="service-title">Batteries</div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 col-sm-12">
            <div className="service-box" onClick={handleOnClick}>
              <img
                src="http://localhost:3000/ImageFolder/CarInspectionService.png"
                alt="Batteries"
              />
              <div className="service-title">Batteries</div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 col-sm-12">
            <div className="service-box" onClick={handleOnClick}>
              <img
                src="http://localhost:3000/ImageFolder/CarInspectionService.png"
                alt="Batteries"
              />
              <div className="service-title">Batteries</div>
            </div>
          </div>
        </div>
      </div>

      {/* Example of a button to show details */}
      {/* <div className="center-button">
        <button
          type="button"
          className="btn btn-danger show-details-button"
          onClick={handleOnClickShowDetails}
        >
          Show Details
        </button>
      </div> */}
    </div>
  );
}

export default AllServiceDetails;
















// import React from 'react';
// import '../../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
// import { useNavigate } from 'react-router-dom'


// function AllServices1() {
//   const navigate = useNavigate()

//   const handleOnClick = () => {
//    navigate('/BookServiceOrder')
//   };
//   const handleOnClickShowDetails = () => {
   
//     navigate('/')

//   };


  
//   return (
//     <>
//       <center>
//         <h1>Services</h1>
//       </center>
//       <div className="container" style={{display : 'flex', justifyContent : 'space-evenly' }}>
//         <br /><br />
//         <div className="box-container1">
//           <div className="row row- 2 cols-3 g-1">
            
//               <div className="col">
//                 <div className="box1" onClick={()=>{navigate('/BookServiceOrder')}} >
//                   <img  src="http://localhost:3000/ImageFolder/ACServices.png" alt="Image"/>
//                 </div>
//               </div>

//             <div className="col" >
//               <div className="box1" onClick={handleOnClick}>
//                 <img  src="http://localhost:3000/ImageFolder/Batteries.png" className="img-responsive" alt="Image" />
//               </div>
//             </div>

//             <div className="col">
//               <div className="box1" onClick={handleOnClick}>
//                 <img  src="http://localhost:3000/ImageFolder/CarInspectionService.png" className="img-responsive" alt="Image" />
//               </div>
//             </div>

//             <div className="col" >
//               <div className="box1" onClick={handleOnClick}>
//               <img  src="http://localhost:3000/ImageFolder/CarSpaService.png" className="img-responsive" alt="Image" />

//               </div>
//             </div>

//             <div className="col"style= {{margin:10}}>
//               <div className="box1" onClick={handleOnClick}>
//               <img  src="http://localhost:3000/ImageFolder/CLutchService.png" className="img-responsive" alt="Image" />

//               </div>
//             </div>

//             <div className="col" >
//               <div className="box1" onClick={handleOnClick}>
//               <img  src="http://localhost:3000/ImageFolder/DentingService.png" className="img-responsive" alt="Image" />
              
//               </div>
//             </div>

//             <div className="col">
//               <div className="box1" onClick={handleOnClick}>
//               <img src="http://localhost:3000/ImageFolder/DetailingService.png" className="img-responsive" alt="Image" />

//               </div>
//             </div>

//             <div className="col">
//               <div className="box1" onClick={handleOnClick}>
//               <img src="http://localhost:3000/ImageFolder/InsuranceClaims.png" className="img-responsive" alt="Image" />

//               </div>
//             </div>

//             <div className="col">
//               <div className="box1 hover" onClick={handleOnClick}>
//               <img src="http://localhost:3000/ImageFolder/PaintingService.png" className="img-responsive" alt="Image" />

//                 </div>
//             </div>

//             <div className="col">
//               <div className="box1 hover" onClick={handleOnClick}>
//               <img src="http://localhost:3000/ImageFolder/SuspensionService.png" className="img-responsive" alt="Image" />
//                 </div>
//             </div>


//             <button
//                 type="button"
//                 className="btn btn-lg btn-danger"
//                 data-bs-toggle="popover"
//                 title='heeloo allllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll'
//                 data-bs-content="And here's some amazing content. It's very engaging. Right?"
//                 onClick={handleOnClickShowDetails}
//               >
//                 show details
//              </button>
             
            
//           </div>
//         </div>
//       </div>
//     </>
//   );
// }

// export default AllServices1;


















// import React from 'react';
// import { useHistory} from 'react-router-dom';
// import {useEffect, useState} from 'react';
// // import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
// import '../../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
// // import '../FrontPage/boxService.css';
// // import './../../FrontPage/bo';
// // import '../boxImage.css';
// import ShowServiceDetails from './ShowServiceDetails';

// function AllServices1() {
//   const history = useHistory();
  

//   const handleOnClick = () => {
//     // Handle click for "Your Assigned Orders"
//     // You can navigate to a specific route or perform any other action here
//     history.push("/BookServiceOrder");
//   };
//   const handleOnClickShowDetails = () => {
//     // Handle click for "Your Assigned Orders"
//     // You can navigate to a specific route or perform any other action here
//     history.push("/ShowServiceDetails");
//   };


  
//   return (
//     <>
//       <center>
//         <h1>Services</h1>
//       </center>
//       <div className="container" style={{display : 'flex', justifyContent : 'space-evenly' }}>
//         <br /><br />
//         <div className="box-container1">
//           <div className="row row- 2 cols-3 g-1">
            
//               <div className="col">
//                 <div className="box1" onClick={handleOnClick} >
//                   <img  src="http://localhost:3000/ImageFolder/ACServices.png" alt="Image"/>
//                 </div>
//               </div>

//             <div className="col" >
//               <div className="box1" onClick={handleOnClick}>
//                 <img  src="http://localhost:3000/ImageFolder/Batteries.png" className="img-responsive" alt="Image" />
//               </div>
//             </div>

//             <div className="col">
//               <div className="box1" onClick={handleOnClick}>
//                 <img  src="http://localhost:3000/ImageFolder/CarInspectionService.png" className="img-responsive" alt="Image" />
//               </div>
//             </div>

//             <div className="col" >
//               <div className="box1" onClick={handleOnClick}>
//               <img  src="http://localhost:3000/ImageFolder/CarSpaService.png" className="img-responsive" alt="Image" />

//               </div>
//             </div>

//             <div className="col"style= {{margin:10}}>
//               <div className="box1" onClick={handleOnClick}>
//               <img  src="http://localhost:3000/ImageFolder/CLutchService.png" className="img-responsive" alt="Image" />

//               </div>
//             </div>

//             <div className="col" >
//               <div className="box1" onClick={handleOnClick}>
//               <img  src="http://localhost:3000/ImageFolder/DentingService.png" className="img-responsive" alt="Image" />
              
//               </div>
//             </div>

//             <div className="col">
//               <div className="box1" onClick={handleOnClick}>
//               <img src="http://localhost:3000/ImageFolder/DetailingService.png" className="img-responsive" alt="Image" />

//               </div>
//             </div>

//             <div className="col">
//               <div className="box1" onClick={handleOnClick}>
//               <img src="http://localhost:3000/ImageFolder/InsuranceClaims.png" className="img-responsive" alt="Image" />

//               </div>
//             </div>

//             <div className="col">
//               <div className="box1 hover" onClick={handleOnClick}>
//               <img src="http://localhost:3000/ImageFolder/PaintingService.png" className="img-responsive" alt="Image" />

//                 </div>
//             </div>

//             <div className="col">
//               <div className="box1 hover" onClick={handleOnClick}>
//               <img src="http://localhost:3000/ImageFolder/SuspensionService.png" className="img-responsive" alt="Image" />
//                 </div>
//             </div>


//             <button
//                 type="button"
//                 className="btn btn-lg btn-danger"
//                 data-bs-toggle="popover"
//                 title='heeloo allllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll'
//                 data-bs-content="And here's some amazing content. It's very engaging. Right?"
//                 onClick={handleOnClickShowDetails}
//               >
//                 show details
//              </button>
             
            
//           </div>
//         </div>
//       </div>
//     </>
//   );
// }

// export default AllServices1;
