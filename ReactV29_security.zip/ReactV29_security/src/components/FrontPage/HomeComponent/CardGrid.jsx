import React from 'react';

const Card = ({ imgSrc, alt, title, text, timestamp }) => {
  return (
    <div className="col">
      <div className="card h-100">
        <img src={imgSrc} className="card-img-top" alt={alt} />
        <div className="card-body">
          <h5 className="card-title">{title}</h5>
          <p className="card-text">{text}</p>
        </div>
        <div className="card-footer">
          <small className="text-body-secondary">Last updated {timestamp} ago</small>
        </div>
      </div>
    </div>
  );
};

const CardGrid = () => {
  return (<>
  <br/><br/><br/>
  <center>
  <h1>Testimonials</h1>
  </center>
  <br/><br/>
  <div>
      <div className="row row-cols-1 row-cols-md-4 g-4">
        <Card
          imgSrc="http://localhost:3000/ImageFolder/Testimonial2.jpg"
          alt="Card 1"
          title="Nilesh Thakre"
          text="Immense Car Detailing and Care, Classic Craftsmanship and skilled resources!"
          timestamp="3 mins"
        />
        
        <Card
          imgSrc="http://localhost:3000/ImageFolder/Testimonial2.jpg"
          alt="Card 2"
          title="Nilesh Thakre"
          text="Immense Car Detailing and Care, Classic Craftsmanship and skilled resources!"
          timestamp="5 mins"
        />
        <Card
          imgSrc="http://localhost:3000/ImageFolder/Testimonial3.avif"
          alt="Card 2"
          title="Nilesh Thakre"
          text="Immense Car Detailing and Care, Classic Craftsmanship and skilled resources!"
          timestamp="5 mins"
        />
        <Card
          imgSrc="http://localhost:3000/ImageFolder/Testimonial3.avif"
          alt="Card 2"
          title="Nilesh Thakre"
          text="This card has suppoImmense Car Detailing and Care, Classic Craftsmanship and skilled resources!"
          timestamp="5 mins"
        />
        {/* Add more Card components here for the remaining cards */}
      </div>
      <div className="row row-cols-1 row-cols-md-5 g-4">
        {/* Add more rows of Card components here if needed */}
      </div>
    </div>

  </>
      );
};

export default CardGrid;
