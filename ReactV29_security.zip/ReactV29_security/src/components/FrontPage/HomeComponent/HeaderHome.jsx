import React from 'react';
// import people from '../../assets/people.png';
// import ai2 from '../../assets/ai2.png';
import './HeaderHome.css';
import logo from '../../logo.jpeg'
import { Navigate, useNavigate } from 'react-router-dom';
const HeaderHome = () => {

  const navigate = useNavigate();

  return (
    <>
    <br/> <br/> <br/> <br/> <br/> <br/> <br/> <br/>
    <div className="gpt3_header section_padding" id="home">
      <div className="gpt3__header-content">
        <h1 className="gradient__text">Vehicare
        </h1>
        <button
                    className='btn btn-sm btn-warning btn-hover sm-2'
                   
                    onClick={() =>{navigate('/LoginCustomer')} }
                >
                   Customer Login
          </button>

          <button
                    className='btn btn-sm btn-success btn-hover sm-2'
                   
                    onClick={() =>{navigate('/LoginTechnician')} }
                >
                   Organization Login
          </button>
          {/* <button
                    className='btn btn-sm btn-info sm-2'
                   
                    onClick={() => handleUpdateinventoryUsed(od.orderId, od.productId)}
                >
                    update inventory details {od.orderId} {od.productId}
          </button> */}
        <p>
        <h5 style={{fontSize: '10', fontWeight: 'bold'}}>
        VehiCare is a leading company dedicated to providing comprehensive and efficient solutions for vehicle maintenance and servicing. With a strong commitment to excellence, we specialize in streamlining the entire process of vehicle care, from routine maintenance to complex repairs. Our team of experienced technicians and state-of-the-art facilities ensure that every vehicle entrusted to us receives the highest level of attention and expertise. 
        We pride ourselves on offering a wide range of services, including regular inspections, oil changes, tire rotations, and advanced diagnostics. Our customer-centric approach means that we prioritize convenience and satisfaction, offering online scheduling, transparent pricing, and timely updates on service progress.
        Whether it's a personal car or a fleet of commercial vehicles, VehiCare is dedicated to keeping vehicles running smoothly while minimizing downtime and maximizing performance.      
        </h5>
        </p>
        {/* <div className="gpt3_header-content_input">
          <input type="email" placeholder="Your Email Address" />
          <button type="button">Get Started</button>
        </div> */}
  
        {/* <div className="gpt3_header-content_people">
          <img src={people} />
          <p>1,600 people requested access a visit in last 24 hours</p>
        </div> */}
      </div>
  
      {/* <div className="gpt3__header-image">
        <img src={logo} />
      </div> */}
    </div>
    
    </>
  
  );
};

export default HeaderHome;