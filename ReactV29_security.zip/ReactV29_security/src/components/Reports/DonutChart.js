import React, {  useEffect, useRef } from 'react';
import { Chart } from 'chart.js';


function DoughnutChart() {
    const chartRef = useRef(null);
  
    useEffect(() => {
      // Create the chart instance
      const chart = new Chart(chartRef.current, {
        type: "doughnut",
        data: {
          labels: ["Social", "Search Engines", "Direct", "Other"],
          datasets: [
            {
              data: [260, 125, 54, 146],
              backgroundColor: [
                window.theme.primary,
                window.theme.success,
                window.theme.warning,
                "#dee2e6"
              ],
              borderColor: "transparent"
            }
          ]
          
        },
        options: {
          maintainAspectRatio: false,
          cutoutPercentage: 65
        }
      });
  
      // Clean up the chart instance on component unmount
      return () => {
        chart.destroy();
      };
    }, []);
  
    return <canvas ref={chartRef} />;
  }

  export default DoughnutChart;
  