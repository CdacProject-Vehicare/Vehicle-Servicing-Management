import React, { useEffect, useRef } from 'react';
import ApexCharts from 'apexcharts';

function PieChart() {
  const chartRef = useRef(null);

  useEffect(() => {
    const options = {
      chart: {
        height: 350,
        type: "pie",
      },
      dataLabels: {
        enabled: false
      },
      series: [44, 55, 13, 33]
    };

    if (chartRef.current) {
      const chart = new ApexCharts(chartRef.current, options);
      chart.render();
    }

    // Cleanup the chart on component unmount
    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, []);

  return <div id="apexcharts-pie" ref={chartRef} />;
}

export default PieChart;
