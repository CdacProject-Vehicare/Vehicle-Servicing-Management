import React from "react";
import { useNavigate } from "react-router-dom";
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../../CssFiles/box.css';
//import { Link } from "react-router-dom";
import { Container, Row, Col } from "react-bootstrap";
import adminDashboard from "../../CssFiles/adminDashboard.css";

function TechnicianAccount() {

  const navigate = useNavigate()

  const handleYourAssignedOrdersClick = () => {
    // Handle click for "Your Assigned Orders"
    // You can navigate to a specific route or perform any other action here
    
        navigate("/GetAllOrdersDetailsListByTechnician");
      
  };

  const handleEditProfileClick = () => {
    // Handle click for "Edit mProfile"
    // You can navigate to a specific route or perform any other action here
    navigate("/EditTechnicianProfile");
  };

  const handleUpdateTechnicianClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/EditTechnicianProfile");
  };

  const handleTechnicianDashBoardClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/TechnicianDashBoard");
  };

  const handleWorkLogClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/empdropdown");
  };

  const handleUpdateServicesClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/");
  };

  const handleUpdateTimeSlotsClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/servicecatalogue");
  };
  const handleAddVehicleToOrderClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/AddNewVehicleToOrder");
  };


  const handleUpdateInventoryClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
  //  navigate("/Inventory");
    navigate('/InventoryDetails')
  };

  const handleGetAllRatingClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
  //  navigate("/Inventory");
  //To be written
    navigate('/AllFeedbackDetails')
  };

  const handleAddFeedbackClick = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
  //  navigate("/Inventory");
    navigate('/AddFeedbackToOrder')
  };


  const addtocart = () => {
    // Handle click for "Update Inventory"
    // You can navigate to a specific route or perform any other action here
    navigate("/productgallery");
  };

  return (
    <Container>
      
      <Row className="admin-dashboard">
        <Col xs={12} className="text-center"> 
        <h2 className="admin-title">Welcome Technician!</h2>  
        </Col>

        <Row className="text-center"> 
          <div className="admin-options">
            <Col className="options-column">
              
              {/* <Row className="admin-option" onClick={addtocart}>
                book Order
              </Row> */}

              {/* <Row className="admin-option" onClick={handleAddVehicleToOrderClick}>
                Add vehicle
              </Row> */}

              {/* <Row className="admin-option" onClick={handleAddFeedbackClick}>
                Add all feedback
              </Row> */}
  
              <Row className="admin-option" onClick={handleYourAssignedOrdersClick}>
                Your Assigned Orders
              </Row>

              <Row className="admin-option" onClick={handleEditProfileClick}>
                update Profile
              </Row>

              {/* <Row className="admin-option" onClick={handleUpdateTechnicianClick}>
               Update Inventory 
              </Row> */}
            </Col>

            <Col className="options-column" >
              
              <Row className="admin-option" onClick={handleTechnicianDashBoardClick}>
                Technician DashBoard
              </Row>

              {/* <Row className="admin-option" onClick={handleWorkLogClick}>
                Work-Log
              </Row> */}

              <Row className="admin-option" onClick={handleGetAllRatingClick}>
                Get all rating
              </Row>
              {/* 
              <Row className="admin-option" onClick={handleUpdateServicesClick}>
                Get all service 
              </Row>*/}

              {/* <Row className="admin-option" onClick={handleUpdateTimeSlotsClick}>
                Update Time-slots
              </Row> */}

              {/* <Row className="admin-option" onClick={handleUpdateInventoryClick}>
                Update Inventory
              </Row> */}
            </Col>
          </div>
        </Row>
      </Row>

      {/* <Row>

      </Row> */}
    </Container>
  );
}

export default TechnicianAccount;






// import React from 'react';
// //import { useHistory } from 'react-router-dom';

// import { Link, useNavigate } from 'react-router-dom'
// //import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
// //import '../box.css';
// import '../../CssFiles/box.css';
// import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css'

// function TechnicianAccount() {
// //   const history = useHistory();
// const navigate = useNavigate()

  
//   const handleAssignedOrdersClick = () => {
//     // Handle click for "Your Assigned Orders"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/TechnicianAssignedOrders")
//         //history.push("/TechnicianAssignedOrders");
      
// };

//   const handleEditProfileClick = () => {
//     // Handle click for "Edit Profile"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/src/components/Technician/EditTechnicianProfile.jsx")
//     //history.push("/TechnicianRegistration");
//   };

//   const handleUpdateInventoryClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/Inventory")
//     //history.push("/Inventory");
// };
// const handleToReortClick = () => {
//     // Handle click for "Update Inventory"
//     // You can navigate to a specific route or perform any other action here
//     navigate("/piechart")
//     // history.push("/piechart");
// };


//   return (<> 
//    <center> <h1>Your Account</h1></center>   
//     <div className="container">
//         <br/><br/>
//         <div className="box-container">
                
//             <table>
//                 <tr>
//                     <td>
//                         <div className="box" onClick={handleAssignedOrdersClick}>
//                     Your Assigned Orders
//                         </div>

                        
//                     </td>
//                     <td>
//                     <div className="box" onClick={handleEditProfileClick}>
//                     Edit Profile
//                 </div>
//                     </td>

//                     <td>
//                         <div className="box" onClick={handleUpdateInventoryClick}>
//                         Update Inventory
//                         </div>
//                     </td>
//                     </tr>


//                     <tr>
//                     <td>
//                     <div className="box" onClick={handleToReortClick}>
//                     Generate Report
//                 </div>
//                     </td>
//                     <td>
//                     <div className="box" onClick={handleUpdateInventoryClick}>
//                     Work-LogIn
//                     </div>
//                     </td>
//                     <td>
//                     <div className="box" onClick={handleUpdateInventoryClick}>
//                     Total Rating
//                     </div>
//                     </td>

//                 </tr>
//             </table>

//         </div>
//     </div>
//     </>

//   );
// }

// export default TechnicianAccount;




// import React from 'react';
// import { useHistory } from 'react-router-dom';
// import '../../node_modules/bootstrap/dist/css/bootstrap.css';
// import './box.css';
// function TechnicianAccount() {
//     return (  
//         <div className="container" >
      
//         <div className="table-responsive">
//             <table className="table table-hover">
//                 <tbody>
//                     <tr>
//                         <td >
//                             Your Assignd Orders
//                         </td>
//                         <td >
//                            Edit Profile
//                         </td>
//                         <td >
//                            Update Inventory
//                            technicalaccount       </td>
//                     </tr>
//                 </tbody>
//             </table>    
//         </div>
    
//     </div>
//     );
// }

// export default TechnicianAccount;