import React, { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import { getOrdersList } from '../../services/orders';
import { constants } from '../../utils/constants';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { getOrdersListByTechnicianId } from '../../services/orders';
import { UpdateWorkLog } from '../../services/orderTechnicianDetails';
// import { UpdateOrderPaymentStatusApi } from '../../services/orders';
// import { UpdateOrderStatusApi } from '../../services/orders';
function TechnicianDashBoard() {
  const [ordersDetails, setOrdersDetails] = useState([]);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [orderIdInput, setOrderIdInput] = useState('');
  const [textInput, setTextInput] = useState('');

  const navigate = useNavigate();
  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    try {
      const response = await getOrdersListByTechnicianId(sessionStorage.getItem('id'));
      if (response) {
        const ordersData = response.data;
        console.log(ordersData)
       
          setOrdersDetails(ordersData);
       

        
      } else {
        toast.error('Error while calling get /Orders api');
       navigate("/401")
      }
    } catch (error) {
      console.error('Error while loading orders:', error);
    }
  };

  // const handleOrderUpdate = async (orderId) => {
  //   // Handle edit logic for the specific order

  //   const response = await UpdateOrderPaymentStatusApi(orderId)
  //   //if (response['status'] === 'success') {
  //     if(true){
  //       console.log("in the UpdateOrderPaymentStatusApi ");
  //       //console.log(response)
  //     //  setProducts(response.data)
  //      // console.log("products-------------"+products)

  //   } else {
  //     toast.error('Error while calling get /product api')
  //   } 
   
  //   loadOrders()




  //   console.log('OrderUpdate with ID:', orderId);
  // };


  // const loadProducts = async () => {
  //   const response = await getProductList()
  //   //if (response['status'] === 'success') {
  //     if(true){
  //       console.log("in the Product page");
  //       console.log(response)
  //       setProducts(response.data)
  //       console.log("products-------------"+products)

  //   } else {
  //     toast.error('Error while calling get /product api')
  //   }
  // }


  // const handlePaymentUpdate =  async(orderId) => {
  //   // Handle delete logic for the specific order
  //         /////////////////////////UpdateOrderStatusApi/////////////////////

  //         const response = await UpdateOrderStatusApi(orderId)
  //         //if (response['status'] === 'success') {
  //           if(true){
  //             console.log("in the UpdateOrderPaymentStatusApi ");
  //             //console.log(response)
  //           //  setProducts(response.data)
  //            // console.log("products-------------"+products)
      
  //         } else {
  //           toast.error('Error while calling get /product api')
  //         } 
         
  //         loadOrders()
      
      


  //   console.log('PaymentUpdate with ID:', orderId);
  // };

  const handlePopUpSubmit = () => {
    // Call another function and pass the values
    anotherFunction(orderIdInput, textInput);
    
    // Close the modal
   // closeModal();
  };

  const anotherFunction = async (orderId, inputValue) => {
    // Do something with the values
    console.log('Order ID in another function:', orderId);
    console.log('Input Value in another function:', inputValue);

    const response= await UpdateWorkLog(textInput, orderIdInput);
    if (response) {
      console.log('Work log updated successfully:', response);
      loadOrders()
      // Perform any actions after successful update
    } else {
      console.error('Failed to update work log');
      // Handle error scenario
    }
  };

  

  const handleOrderInputChange = (e) => {
    setOrderIdInput(e.target.value);
  };

  const handleTextInputChange = (e) => {
    setTextInput(e.target.value);
  };

  const handleinventorydetails = (id) => {
    // Handle delete logic for the specific order
    console.log('show/Add/Remove inventory order with orderdetails ID:', id);
    navigate('/OrdersInventoryDetails/'+id)
  };

  const handleUpdateinventoryUsed = (orderId,productId) => {
    // Handle delete logic for the specific order
    console.log('Update inventory order with orderdetails ID:'+orderId);
    console.log('Update inventory order with product ID:'+productId);
    navigate("/InventoryUsage/"+orderId+"/"+productId)
  };

  return (
    <div>
      <h1 style={{ textAlign: 'center', margin: 10 }}>Technician WorkLog  Activity Tracker</h1>
      <h2>Activity Tracker</h2>
        <div className="col-md-2">
          <label>Order ID:</label>
          <input type='text' className="form-control" value={orderIdInput} onChange={handleOrderInputChange} />
        </div>
        <div className="col-md-2">
          <label>Input Text:</label>
          <input type='text'className="form-control" value={textInput} onChange={handleTextInputChange} />
        </div>
        <button className="btn btn-sm btn-success btn-hover sm-2" onClick={handlePopUpSubmit}>Submit</button>
        
      <table className='table table-striped table-hover' style={{ marginTop: 50 }}>
        <thead>
          <tr>
            <th>Expected Completion Date</th>
            <th>Order Id</th>
            <th>Technician Id</th>
            <th>Technician Name</th>
            <th>Work-log</th>
                      
          </tr>
        </thead>
        {/* expectedCompletionDate
: 
"2023-08-27"
orderId
: 
8
technicianId
: 
1
technicianName
: 
"david"
worklog
: 
"demo Update worklog  : \"text updated\" : 2023-08-27 Update worklog  : \"text updated 1\" : 2023-08-27 Update worklog  : \"text updated 2\" : 2023-08-27 Update worklog  : \"text updated 3\" : 2023-08-27 Status Updated  -> work completed : 2023-08-27" */}


        <tbody>


          {ordersDetails.map((od) => (
            <tr key={od.orderId}>
              <td>{od.expectedCompletionDate}</td>
              <td>{od.orderId}</td>
              <td>{od.technicianId}</td>           
              <td>{od.technicianName}</td>
              <td>{od.worklog}</td>
              {/* <td>
                <button
                  className='btn btn-sm btn-primary sm-2'
                  onClick={() => handleOrderUpdate(od.orderId)}
                >
                  Update Order Status
                </button>
              </td> */}
              {/* <td>
                <button
                  className='btn btn-sm btn-warning sm-2'
                  onClick={() => navigate('/AddFeedbackToOrder/'+od.orderId)}
                >
                  Add Feedback
                </button>
               </td>  */}
               

              

                
                <button
                  className='btn btn-sm btn-success sm-2'
                  onClick={() => navigate('/GetVehicleDetails/'+od.orderId)}
                >
                  get Vehicle Details
                   {/* <Link to={`/pageB/${key}/${value}`}>get inventory details </Link>
                   */}
                </button>
              
                <button
                  className='btn btn-sm btn-success sm-2'
                  onClick={() => handleinventorydetails(od.orderId)}
                >
                  get inventory details
                   {/* <Link to={`/pageB/${key}/${value}`}>get inventory details </Link>
                   */}
                </button>
              {/* <td>
                <button
                  className='btn btn-sm btn-info sm-2'
                 
                  onClick={() => handleUpdateinventoryUsed(od.orderId, od.productId)}
              >
                  update inventory details {od.orderId} {od.productId}
                </button>
               </td>  */}
              
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default TechnicianDashBoard;







// import { useEffect, useState } from 'react'
// import { toast } from 'react-toastify'
// import { getOrdersList }  from '../../services/orders'
// import { constants } from '../../utils/constants'
// function GetAllOrdersDetailsList() {
//   const [ordersDetails, setordersDetails] = useState([])
  
//   useEffect(() => {
//     // get the list of products from server
//     console.log("in component did mount")
//     loadOrders()
//   }, [])

//   const loadOrders = async () => {
//     const response = await getOrdersList()
//     //if (response['status'] === 'success') {
//       if(true){
//         console.log("in the Orders page");
//         console.log(response)
//         //console.log(JSON.parse(response))
//         setordersDetails(response.data)
//         console.log("Orders-------------"+ordersDetails)

//     } else {
//       toast.error('Error while calling get /Orders api')
//     }
//   }

//   return (
//     <div>
//       <h1 style={{ textAlign: 'center', margin: 10 }}>Product Gallery</h1>
//       <div className='row' style={{ marginTop: 50 }}>
//         {ordersDetails.map((od) => {
//           return (
//             <div className='col-md-3'>
//               <div className='card'>
//                 <img
//                   src={constants.serverUrl + '/'}
//                   style={{ height: 200 }}
//                   alt=''
//                 />
//                 {/* [{"productId":1,"productName":"washing","productDesc":"string","productMfgDate":"2023-08-22","productExpDate":"2023-08-22","productPrice":200.0} */}
//                 <div className='card-body'>
//                   <h5 className='card-title'></h5>
//                   <div className='card-text'>
//                     {/* <div>{product['company']}</div>
//                     <div>₹ {product['price']}</div> */}
//                         <div>{od['customerFirstname']}</div>
//                         <div>{od['customerLastName']}</div>
//                         <div>{od['orderDetailsId']}</div>
//                         <div>{od['paymentstatus']} </div>
//                         <div>{od['price']} </div>
//                         <div>{od['productName']} </div>
//                         <div>{od['vehicleName']} </div>
//                         <div>{od['vehicleNo']} </div>

                        
//                   </div>
//                 </div>
//               </div>
//             </div>
//           )
//         })}
//       </div>
//     </div>
//   )
// }
  


// export default GetAllOrdersDetailsList
// // customerFirstname
// // : 
// // "new_firstname"
// // customerLastName
// // : 
// // "string"
// // orderDetailsId
// // : 
// // 2
// // orderId
// // : 
// // 2
// // paymentstatus
// // : 
// // null
// // price
// // : 
// // 100
// // productName
// // : 
// // "string"
// // status
// // : 
// // null
// // technicianAssigned
// // : 
// // null
// // vehicleName
// // : 
// // "g6"
// // vehicleNo
// // : 
// // "mustang"

