
import React, {  useState, useEffect } from 'react';
import { getAllInventoryDetails } from '../../services/Inventory-Service';
import { useParams } from 'react-router-dom';
import { toast } from 'react-toastify'
import { orderinventoryUsedUpdateService } from '../../services/orderInventoryUsedUpdate-service';
function InventoryUsage(){
  
  const [inventoryList, setInventoryList] = useState([]);
  const [selectedItem, setSelectedItem] = useState('');
  const [quantityUsed, setQuantityUsed] = useState('');
  const { orderId,productId} = useParams();
 
  useEffect(() => {
    fetchInventory();
  }, []);
 
 
  async function fetchInventory() {
    const inventoryData = await getAllInventoryDetails();
    console.log(inventoryData);
    setInventoryList(inventoryData.data);
  }

  const handleItemChange = (event) => {
    setSelectedItem(event.target.value);
  };

  const handleQuantityChange = (event) => {
    setQuantityUsed(event.target.value);
  };

  const handlePrint = async () => {
    console.log('Selected Item ID:'+ selectedItem); // Assuming ID is present in the inventory data
    console.log('Quantity Used:'+ quantityUsed);
    console.log('order Id :'+orderId)
    console.log('productId :'+productId)
    const UpdateInventoryUsedresponse=  await orderinventoryUsedUpdateService(orderId,productId,selectedItem,quantityUsed);
    if(UpdateInventoryUsedresponse)
    {
      toast.success('inventory details usage updated')
    }
    else{
      toast.error('something went wrong')
    }

  };

  return (
    <div>
      <h1>Inventory Usage Form {orderId} {productId}</h1>
      <div>
        <label>Select Inventory:</label>
        <select value={selectedItem} onChange={handleItemChange}>
          <option value="">Select an item</option>
          {inventoryList.map((item) => (
            <option key={item.inventoryId} value={item.inventoryId}>
            {item.inventoryName}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label>Quantity Used:</label>
        <input
          type="number"
          value={quantityUsed}
          onChange={handleQuantityChange}
        />
      </div>
      <button onClick={handlePrint}>Submit</button>
      {/* ... rest of the component ... */}
    </div>
  );
}



export default InventoryUsage;

// import { useState, useEffect } from 'react'
// import { Link, useNavigate } from 'react-router-dom'
// import { toast } from 'react-toastify'
// import { updateTechnician as updateTechnicianApi } from '../../services/user'

// //import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css'
// //import '../../node_modules/bootstrap/dist/css/bootstrap.min.css'
// import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css'


// import { getTechnicianById } from '../../services/user'

// function UpdateInventoryUsedDetails() {
//   // const [firstName, setFirstName] = useState('')
//   // const [lastName, setLastName] = useState('')
//   // const [email, setEmail] = useState('')
//   // const [mobile, setMobile] = useState('')
//   // const [password, setPassword] = useState('')
//   // const [confirmPassword, setConfirmPassword] = useState('')

//   const [technicianId, setId] = useState('')
//   const [firstName, setFirstName] = useState('')
//   const [lastName, setLastName] = useState('')
  

//   // get the navigation object
//   const navigate = useNavigate()
//   useEffect(() => {
//     // get the list of products from server
//     console.log("in component did mount")
//     UpdateDetailsOfInventory()
//   }, [])

//   const UpdateDetailsOfInventory = async () => {
//     const response = await getTechnicianById(sessionStorage.getItem('id'))
//     //if (response['status'] === 'success') {
//       if(true){
//         console.log("in the Technician profile edit ");
//         console.log(response)
//         setId(sessionStorage.getItem('id'))
//         setFirstName(response.data.firstName)
//         setLastName(response.data.lastName)
                
//         //setProducts(response.data)
//         console.log("Technician-------------"+response)

//     } else {
//       toast.error('Error while calling get /product api')
//     }
//   }


//   const updateTechnician = async () => {
//     if (firstName.length == '') {
//       toast.error('Please enter first name')
//     }
//      else if (lastName.length == '') {
//       toast.error('Please enter last name')
//     } 
//     else if (email.length == '') {
//       toast.error('Please enter email')
//     }  
//     else if (password.length == '') {
//       toast.error('Please enter password')
//     } 
//     else if (address.length == '') {
//       toast.error('Please enter adress')
//     }
//     else if (joinDate.length == '') {
//       toast.error('Please enter Date Of Birth')
//     }
//     else if (mobileNo.length == '') {
//       toast.error('Please enter mobile No')
//     }
//     else if (gender.length == '') {
//       toast.error('Please enter Gender')
//     }
    
//     if (password !== confirmPassword) {
//       toast.error('Password does not match')
//     } else {
//       // call register api
//       const response = await updateTechnicianApi(
//         technicianId,
//         firstName,
//         lastName,
//         email,
//         password,
//         address,
//         joinDate,
//         mobileNo,
//         gender
//       )

//       // parse the response
//       if (response) {
//         toast.success('Successfully update user profile')

//         // go back to login
//         navigate('/src/Screen/Technician/TechnicianAccount.js')
//       } else {
//         toast.error('Error while registering a new user, please try again')
//       }
//     }
//   }
//   return (
//     <div>
//       <h1 style={{ textAlign: 'center', margin: 10 }}>Update Technician</h1>

//       <div className='row'>
//         <div className='col'></div>
//         <div className='col'>
//           <div className='form'>

//             <div className='mb-3'>
//               <label htmlFor=''>First Name</label>
//               <input
//                 type='text'
//                 className='form-control'
//                 value={firstName}
//                 onChange={(e) => {
//                   setFirstName(e.target.value)
//                 }}
//               />
//             </div>

//             <div className='mb-3'>
//               <label htmlFor=''>Last Name</label>
//               <input
//                 type='text'
//                 className='form-control'
//                 value={lastName}
//                 onChange={(e) => {
//                   setLastName(e.target.value)
//                 }}
//               />
//             </div>

//             <div className='mb-3'>
//               <label htmlFor=''>Email</label>
//               <input
//                 type='text'
//                 className='form-control'
//                 value={email}
//                 onChange={(e) => {
//                   setEmail(e.target.value)
//                 }}
//               />
//             </div>

//             <div className='mb-3'>
//               <label htmlFor=''>Password</label>
//               <input
//                 type='password'
//                 className='form-control'
//                 value={password}
//                 onChange={(e) => {
//                   setPassword(e.target.value)
//                 }}
//               />
//             </div>

//             <div className='mb-3'>
//               <label htmlFor=''>Address</label>
//               <input
//                 type='text'
//                 className='form-control'
//                 value={address}
//                 onChange={(e) => {
//                   setAddress(e.target.value)
//                 }}
//               />
//             </div>

//             <div className='mb-3'>
//               <label htmlFor=''>Mobile Number</label>
//               <input
//                 type='tel'
//                 className='form-control'
//                 value={mobileNo}
//                 onChange={(e) => {
//                   setMobileNo(e.target.value)
//                 }}
//               />
//             </div>

//             <div>
//             <label htmlFor=''>Date of joinig</label>
//               <input
//                 type="date"
//                 value={joinDate}
//                 onChange={(e) => {
//                   setJoinDate(e.target.value)
//                 }}
//               />
//            </div>

//             <div className='mb-3'>
//               <label htmlFor=''>Gender</label>
//               <input
//                 type='text'
//                 className='form-control'
//                 value={gender}
//                 onChange={(e) => {
//                   setGender(e.target.value)
//                 }}
//               />
//             </div>


//             <div className='mb-3'>
//               <label htmlFor=''>Confirm Password</label>
//               <input
//                 type='password'
//                 className='form-control'
//                 onChange={(e) => {
//                   setConfirmPassword(e.target.value)
//                 }}
//               />
//             </div>

//             <div className='mb-3'>
//               <button onClick={updateTechnician} className='btn btn-success'>
//                 Update
//               </button>
//             </div>
//           </div>
//         </div>
//         <div className='col'></div>
//       </div>
//     </div>
//   )
// }

// export default UpdateInventoryUsedDetails;