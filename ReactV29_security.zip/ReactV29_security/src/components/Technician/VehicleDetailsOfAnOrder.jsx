import React from 'react';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';

import { useNavigate, useParams } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import { getAllInventoryDetails } from '../../services/Inventory-Service';

import '../../CssFiles/box.css'
import { GetVehicleDetailsById } from '../../services/vehicle-service';
function VehicleDetails() {
   const navigate = useNavigate()
    const {orderId} =useParams();
    
    
  const [VehicleList, setVehicle] = useState('')

    var index = 0;

    useEffect(() => {
        console.log("in component did mount")
        loadData()
      }, [])

      const loadData = async () => {
        const response = await  GetVehicleDetailsById(orderId);
        //if (response['status'] === 'success') {
          if(response){
            console.log("in the Inventory page");
            console.log(response)
            setVehicle(response.data)
            console.log("Inventory-------------"+VehicleList)
    
        } else {
          toast.info('Currently vehicle is not added kindly click on  ADD VEHICLE')
        //  navigate('/CustomerDashBoard')
        }
      }


    // const handleEditClick = () => {
    //     history.push('/InventoryUpdate');
    // };

    // const handleAddClick = () => {
    //     history.push('/AddNewProductinInventory');
    //  };

    // const handleDeleteClick = () => {
    //      alert('Records Deleted!!');
    // };

    return(

        <div>
          <h1 style={{ textAlign: 'center', margin: 10 }}>Vehicle Details</h1>
          {/* <button className="btn btn-info" 
                onClick={()=>{navigate('/AddNewItemInInventory')}}>Add New Items</button>
                    */}
          <table className='table table-bordered'>
          {/* <thead>
                  <tr >
                    <th>Sr. No</th>
                    <th>Item Id</th>
                    <th>Item Name</th>
                    <th>Safety Stock</th>
                    <th>Available stock</th>
                    <th>item Price</th>
                    <th>Edit</th>
                    <th>Delete</th> 
                  </tr>
                </thead> */}
                {/* {
  "vehicleId": 1,
  "vehicleMfg": "totoya",
  "vehicleName": "verna",
  "vehicleType": "FOURWHEELER",
  "vehicleNo": "bc234"
} */}
                <thead>
                <tr>
                  <th className="column-header">Sr. No</th>
                  <th className="column-header">order Id</th>
                  <th className="column-header">vehicleMfg</th>
                  <th className="column-header">vehicle Name</th>
                  <th className="column-header">vehicle Type</th>
                  <th className="column-header">vehicle No</th>
                  {/* <!-- <th>Edit</th>
                  <th>Delete</th> --> */}
                </tr>
              </thead>
              
            <tbody>
              
                   
                
                    <tr key={VehicleList.vehicleId}>
                    <td className="column-field">{index+1}</td>
                    <td className="column-field">{VehicleList.vehicleId}</td>
                    <td className="column-field">{VehicleList.vehicleMfg}</td>
                    <td className="column-field">{VehicleList.vehicleName}</td>
                    <td className="column-field">{VehicleList.vehicleType}</td>
                    <td className="column-field">{VehicleList.vehicleNo}</td>
                    {/* <td>
                      <button classNameName="btn btn-warning" onClick={()=>{navigatToEditService(product.productId)}}>Edit</button>
                    </td>
                    <td>
                      <button classNameName="btn btn-danger" onClick={()=>{removeService(product.productId)}}>Delete</button>
                    </td> */}

                    {/* <td>
                      <button classNameName="btn btn-danger" onClick={()=>{removeTechnician(technician.technicianId)}}>Delete</button>
                    </td> */}
                  </tr>
              
            
            </tbody>
          </table>
        </div>
        )
}

export default VehicleDetails;