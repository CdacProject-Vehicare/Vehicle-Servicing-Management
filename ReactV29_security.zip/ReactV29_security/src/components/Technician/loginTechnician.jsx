import { useState } from 'react'
import { useDispatch } from 'react-redux'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
//import { login } from '../features/authSlice'
import { login } from '../../features/authSlice'
//import { loginTechnician as loginTechnicianApi } from '../services/user'
import React from 'react';
import {
  MDBBtn,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBInput
}
from 'mdb-react-ui-kit';

import { loginTechnician as loginTechnicianApi} from '../../services/user'
function LoginTechnician() {
  const [email, setEmail] = useState('Pratik2014@gmail.com')
  const [password, setPassword] = useState('Pratik@1999')

  // get the navigation object
  const navigate = useNavigate()

  // get dispatcher object
  const dispatch = useDispatch()

const toRegistration = () => {
  navigate('/register')
}


  const loginTechnician = async () => {
    if (email.length == '') {
      toast.error('Please enter email')
    } else if (password.length == '') {
      toast.error('Please enter password')
    } else {
      // call register api
      const response = await loginTechnicianApi(email, password)
      if(response){
      // parse the response
      //if (response['status'] === '200') {
        // parse the response's data and extract the token
        console.log(response)
        const {firstName} = response.data//['data']
        const {role} = response.data
        const {id} = response.data
        const {token}=response.data
        //const {role} = response.data
        // store the token for making other apis
       // sessionStorage['token'] = token
        sessionStorage['name'] = firstName
        sessionStorage['role'] = role
        sessionStorage['id'] = id
        sessionStorage['token']=token
       // sessionStorage['mobile'] = mobile
       // sessionStorage['profileImage'] = profileImage

        // update global store's authSlice with status = true
        dispatch(login())

        toast.success(`Welcome ${firstName} to store application`)
        if(role === "Customer")
        {
          navigate('./src/components/CustomerHome.js')
        }
        else if(role === "Technician")
        {
          console.log('Inside Technician Condition');
          navigate('/TechnicianAccount')
          //navigate('/src/components/Technician/TechnicianAccount.jsx')



        }
        else if(role === "Admin")
        {
          navigate('/AdminAccount')
        }
        
        // go back to login
        //navigate('/product-gallery')
      } else {
        toast.error('Invalid user name or password')
        navigate('/login')
      }
    }
  }

  return (
    < div className="body-limited">
    <MDBContainer className="my-5 gradient-form">

      <MDBRow>

        <MDBCol col='6' className="mb-5">
          <div className="d-flex flex-column ms-5">

             {/* <div className="text-center">
              <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/lotus.webp"
                style={{width: '185px'}} alt="logo" />
              <h4 className="mt-1 mb-5 pb-1">Your Vehicle, Our Responsibility </h4>
            </div> */}
           {/* <img src="http://localhost:3000/ImageFolder/image4.png" style={{height:'80%',width:'80%' } }  className="d-block w-100" alt="..."/>
   */}
            <div className="text-center">
            <img src="http://localhost:3000/logo/logo1.jpeg"  
              style={{width: '185px'}} alt="logo" />
            <h4 className="mt-1 mb-5 pb-1">Your Vehicle, Our Responsibility </h4>
          </div>

            <p>Please login to your account</p>


            <MDBInput wrapperClass='mb-4' label='Email address' id='form1' 
                      type='email' onChange={(e) => { setEmail(e.target.value)}} />
            <MDBInput wrapperClass='mb-4' label='Password' id='form2' type='password'
                       onChange={(e) => { setPassword(e.target.value)}}/>


            <div className="text-center pt-1 mb-5 pb-1">
              <MDBBtn className="mb-4 w-100 gradient-custom-2" onClick={loginTechnician} >Sign in</MDBBtn>
              {/* <a className="text-muted" href="#!">Forgot password?</a> */}
            </div>

            <div className="d-flex flex-row align-items-center justify-content-center pb-4 mb-4">
              <p className="mb-0">Don't have an account?  </p> 
               <MDBBtn outline className='mx-2' color='success'  onClick={toRegistration} >
              Register here
              </MDBBtn>     
              {/* <Link to='/register'>Register here</Link> */}
              
            </div>

          </div>

        </MDBCol>



        <MDBCol col='6' className="mb-5">
          <div className="d-flex flex-column  justify-content-center gradient-custom-2 h-100 mb-4">

            <div className="text-white px-3 py-4 p-md-5 mx-md-4">
              <h4 class="mb-4">We are more than just a company</h4>
              <p class="small mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
              </p>
            </div>

          </div>

        </MDBCol>

      </MDBRow>

    </MDBContainer>
    </div>
  );

}

export default LoginTechnician








////////////////////Pratik//////////////////////////////////////////////////
// import { useState } from 'react'
// import { useDispatch } from 'react-redux'
// import { Link, useNavigate } from 'react-router-dom'
// import { toast } from 'react-toastify'
// //import { login } from '../features/authSlice'
// import { login } from '../../features/authSlice'
// //import { loginTechnician as loginTechnicianApi } from '../services/user'

// import { loginTechnician as loginTechnicianApi} from '../../services/user'
// function LoginTechnician() {
//   const [email, setEmail] = useState('Pratik2014@gmail.com')
//   const [password, setPassword] = useState('Pratik@1999')

//   // get the navigation object
//   const navigate = useNavigate()

//   // get dispatcher object
//   const dispatch = useDispatch()

//   const loginTechnician = async () => {
//     if (email.length == '') {
//       toast.error('Please enter email')
//     } else if (password.length == '') {
//       toast.error('Please enter password')
//     } else {
//       // call register api
//       const response = await loginTechnicianApi(email, password)
//       if(response){
//       // parse the response
//       //if (response['status'] === '200') {
//         // parse the response's data and extract the token
//         console.log(response)
//         const {firstName} = response.data//['data']
//         const {role} = response.data
//         const {id} = response.data
//         //const {role} = response.data
//         // store the token for making other apis
//        // sessionStorage['token'] = token
//         sessionStorage['name'] = firstName
//         sessionStorage['role'] = role
//         sessionStorage['id'] = id
//        // sessionStorage['mobile'] = mobile
//        // sessionStorage['profileImage'] = profileImage

//         // update global store's authSlice with status = true
//         dispatch(login())

//         toast.success(`Welcome ${firstName} to store application`)
//         if(role === "Customer")
//         {
//           navigate('./src/components/CustomerHome.js')
//         }
//         else if(role === "Technician")
//         {
//           console.log('Inside Technician Condition');
//           navigate('/src/components/Technician/TechnicianAccount.jsx')
//           //navigate('/src/components/Technician/TechnicianAccount.jsx')



//         }
//         else if(role === "Admin")
//         {
//           navigate('/src/components/Admin/AdminAccount.jsx')
//         }
        
//         // go back to login
//         //navigate('/product-gallery')
//       } else {
//         toast.error('Invalid user name or password')
//         navigate('/login')
//       }
//     }
//   }

//   return (
//     <div>
//       <h1 style={{ textAlign: 'center', margin: 10 }}>Login</h1>

//       <div className='row'>
//         <div className='col'></div>
//         <div className='col'>
//           <div className='form'>
//             <div className='mb-3'>
//               <label htmlFor=''>Email</label>
//               <input
//                 type='text'
//                 className='form-control'
             
//                 onChange={(e) => {
//                   setEmail(e.target.value)
//                 }}
//               />
//             </div>
//             <div className='mb-3'>
//               <label htmlFor=''>Password</label>
//               <input
//                 type='password'
//                 className='form-control'
               
//                 onChange={(e) => {
//                   setPassword(e.target.value)
//                 }}
//               />
//             </div>
//             <div className='mb-3'>
//               <div className='mb-3'>
//                 Don't have an account? <Link to='/register'>Register here</Link>
//               </div>
//               <button onClick={loginTechnician} className='btn btn-success'>
//                 Login
//               </button>
//             </div>
//           </div>
//         </div>
//         <div className='col'></div>
//       </div>
//     </div>
//   )
// }

// export default LoginTechnician
