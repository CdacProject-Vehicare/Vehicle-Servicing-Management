
import React, { useState } from 'react';
import { toast } from 'react-toastify';
import { registerTechnician as registerTechnicianApi } from '../../services/user';
import './../../CssFiles/registerTechnician.css';
import { Link, useNavigate } from 'react-router-dom'

function RegisterTechnician() {

  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [email, setEmail] = useState('')
  const [address, setAddress] = useState('') 
  const [password, setPassword] = useState('')
  const [joinDate, setJoinDate] = useState('') 
  const [mobileNo, setMobileNo] = useState('')
  const [gender, setGender] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  

  const navigate = useNavigate() 
  const registerTechnician = async () => {
    if (firstName.length == '') {
      toast.error('Please enter first name')
    }
     else if (lastName.length == '') {
      toast.error('Please enter last name')
    } 
    else if (email.length == '') {
      toast.error('Please enter email')
    }  
    else if (password.length == '') {
      toast.error('Please enter password')
    } 
    else if (address.length == '') {
      toast.error('Please enter adress')
    }
    else if (joinDate.length == '') {
      toast.error('Please enter Date Of Birth')
    }
    else if (mobileNo.length == '') {
      toast.error('Please enter mobile No')
    }
    else if (gender.length == '') {
      toast.error('Please enter Gender')
    }
    
    if (password !== confirmPassword) {
      toast.error('Password does not match')
    } else {
      // call register api
      const response = await registerTechnicianApi(
        firstName,
        lastName,
        email,
        password,
        address,
        joinDate,
        mobileNo,
        gender
      )

      // parse the response
      if (response) {
        toast.success('Successfully registered a new user')

        // go back to login
        navigate('/')
      } else {
        toast.error('Error while registering a new user, please try again')
      }
    }
  }


  return (
    <section className="h-100 bg-transparent">
      <div className="container py-5 h-100">
        <div className="row d-flex justify-content-center align-items-center h-100">
          
          <div className="col">
            <div className="card card-registration my-4">
              <div className="row g-0">
                
                <div className="col-xl-6 d-none d-xl-block">
                  <img
                    src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/img4.webp"
                    alt="Sample photo"
                    className="img-fluid"
                    style={{
                      borderTopLeftRadius: '.15rem',
                      borderBottomLeftRadius: '.15rem',
                    }}
                  />
                </div>

                <div className="col-xl-6">

                  <div className="card-body p-md-5 text-black">

                    <h3 className="mb-5 text-uppercase">Technician Registration Form</h3>
                    <div class="row">
                    {/* Form input fields */}
                        <div className="col-md-6 mb-4">
                          <label htmlFor="firstName" className="form-label">
                            First Name
                          </label>
                          <input
                            type="text"
                            id="firstName"
                            name="firstName"
                            className="form-control form-control-lg"
                            value={firstName}
                            onChange={(e) => {setFirstName(e.target.value)}}
                          />
                        </div>

                        <div className="col-md-6 mb-4">
                          <label htmlFor="lastName" className="form-label">
                            Last Name
                          </label>
                          <input
                            type="text"
                            id="lastName"
                            name="lastName"
                            className="form-control form-control-lg"
                            value={lastName}
                            onChange={(e) => {setLastName(e.target.value)}}
                          />
                        </div>
                    </div>

                    <div class="row"> 
                      <div className="mb-4">
                            <label htmlFor="email" className="form-label">
                              Email
                            </label>
                            <input
                              type="email"
                              id="email"
                              name="email"
                              className="form-control form-control-lg"
                              value={email}
                              onChange={(e) => {setEmail(e.target.value)}}
                            />
                          </div>
                    </div>

                     <div class="row">
                    {/* Form input fields */}
                        <div className="col-md-6 mb-4">
                          <label htmlFor="password" className="form-label">
                          Password 
                          </label>
                          <input
                            type="password"
                            id="password"
                            name="password"
                            className="form-control form-control-lg"
                            value={password}
                            onChange={(e) => {setPassword(e.target.value)}}
                          />
                        </div>

                        <div className="col-md-6 mb-4">
                          <label htmlFor="password" className="form-label">
                            Confirm Password
                          </label>
                          <input
                            type="password"
                            id="confirmPassword"
                            name="confirmPassword"
                            className="form-control form-control-lg"
                            value={confirmPassword}
                            onChange={(e) => {setConfirmPassword(e.target.value)}}
                          />
                        </div>
                    </div>

                    <div class="row">
                    {/* Form input fields */}
                        <div className="col-md-6 mb-4">
                          <label htmlFor="mobileNo" className="form-label">
                            Mobile No
                          </label>
                          <input
                            type="text"
                            id="mobileNo"
                            name="mobileNo"
                            className="form-control form-control-lg"
                            value={mobileNo}
                            onChange={(e) => {setMobileNo(e.target.value)}}
                          />
                        </div>

                        <div className="col-md-6 mb-4">
                          <label htmlFor="joinDate" className="form-label">
                           Joining Date
                          </label>
                          <input
                            type="date"
                            id="joinDate"
                            name="joinDate"
                            className="form-control form-control-lg"
                            value={joinDate}
                            onChange={(e) => {setJoinDate(e.target.value)}}
                          />
                        </div>
                    </div>

                    <div class="row"> 
                      <div className="mb-4">
                            <label htmlFor="location" className="form-label">
                            Location
                            </label>
                            <input
                              type="text"
                              id="location"
                              name="location"
                              className="form-control form-control-lg"
                              value={address}
                              onChange={(e) => {setAddress(e.target.value)}}
                            />
                          </div>
                    </div>
                    

                    
      
                    <div className="d-md-flex justify-content-start align-items-center mb-4 py-2">
                      <h6 className="mb-0 me-4">Gender:</h6>
                      <div className="form-check form-check-inline mb-0 me-4">
                        <input
                          type="radio"
                          name="gender"
                          id="femaleGender"
                          value="F"
                          onChange={(e) => {setGender(e.target.value)}}
                        />
                        <label className="form-check-label" htmlFor="femaleGender">
                          F
                        </label>
                      </div>
                      <div className="form-check form-check-inline mb-0 me-4">
                        <input
                          type="radio"
                          name="gender"
                          id="maleGender"
                          value="M"
                          onChange={(e) => {setGender(e.target.value)}}
                        />
                        <label className="form-check-label" htmlFor="maleGender">
                          M
                        </label>
                      </div>

                      <div className="form-check form-check-inline mb-0">
                        <input
                          type="radio"
                          name="gender"
                          id="otherGender"
                          value="O"
                          onChange={(e) => {setGender(e.target.value)}}
                        />
                        <label className="form-check-label" htmlFor="otherGender">
                          O
                        </label>
                      </div>
                    </div>

                    {/* Form submit buttons */}
                    <div className="d-flex justify-content-end pt-3">
                      {/* <button
                        type="button"
                        className="btn btn-light btn-lg"
                        onClick={() => setFormData({})}
                      >
                        Reset all
                      </button> */}

                      <button
                        type="button"
                        className="btn btn-warning btn-lg ms-2"
                        onClick={registerTechnician}
                      >
                        Submit form
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default RegisterTechnician;





//////////////////////pratik Code///////////////////////////////
// import { useState } from 'react'
// import { Link, useNavigate } from 'react-router-dom'
// import { toast } from 'react-toastify'
// import { registerTechnician as registerTechnicianApi } from '../../services/user'


// function RegisterTechnician() {
//   // const [firstName, setFirstName] = useState('')
//   // const [lastName, setLastName] = useState('')
//   // const [email, setEmail] = useState('')
//   // const [mobile, setMobile] = useState('')
//   // const [password, setPassword] = useState('')
//   // const [confirmPassword, setConfirmPassword] = useState('')

//   const [firstName, setFirstName] = useState('')
//   const [lastName, setLastName] = useState('')
//   const [email, setEmail] = useState('')
//   const [address, setAddress] = useState('') 
//   const [password, setPassword] = useState('')
//   const [joinDate, setJoinDate] = useState('') 
//   const [mobileNo, setMobileNo] = useState('')
//   const [gender, setGender] = useState('')
//   const [confirmPassword, setConfirmPassword] = useState('')

//   // get the navigation object
//   const navigate = useNavigate()

//   const registerTechnician = async () => {
//     if (firstName.length == '') {
//       toast.error('Please enter first name')
//     }
//      else if (lastName.length == '') {
//       toast.error('Please enter last name')
//     } 
//     else if (email.length == '') {
//       toast.error('Please enter email')
//     }  
//     else if (password.length == '') {
//       toast.error('Please enter password')
//     } 
//     else if (address.length == '') {
//       toast.error('Please enter adress')
//     }
//     else if (joinDate.length == '') {
//       toast.error('Please enter Date Of Birth')
//     }
//     else if (mobileNo.length == '') {
//       toast.error('Please enter mobile No')
//     }
//     else if (gender.length == '') {
//       toast.error('Please enter Gender')
//     }
    
//     if (password !== confirmPassword) {
//       toast.error('Password does not match')
//     } else {
//       // call register api
//       const response = await registerTechnicianApi(
//         firstName,
//         lastName,
//         email,
//         password,
//         address,
//         joinDate,
//         mobileNo,
//         gender
//       )

//       // parse the response
//       if (response['firstName']) {
//         toast.success('Successfully registered a new user')

//         // go back to login
//         navigate('/')
//       } else {
//         toast.error('Error while registering a new user, please try again')
//       }
//     }
//   }
//   return (
//     <div>
//       <h1 style={{ textAlign: 'center', margin: 10 }}>Register Technician</h1>

//       <div className='row'>
//         <div className='col'></div>
//         <div className='col'>
//           <div className='form'>

//             <div className='mb-3'>
//               <label htmlFor=''>First Name</label>
//               <input
//                 type='text'
//                 className='form-control'
//                 onChange={(e) => {
//                   setFirstName(e.target.value)
//                 }}
//               />
//             </div>

//             <div className='mb-3'>
//               <label htmlFor=''>Last Name</label>
//               <input
//                 type='text'
//                 className='form-control'
//                 onChange={(e) => {
//                   setLastName(e.target.value)
//                 }}
//               />
//             </div>

//             <div className='mb-3'>
//               <label htmlFor=''>Email</label>
//               <input
//                 type='text'
//                 className='form-control'
//                 onChange={(e) => {
//                   setEmail(e.target.value)
//                 }}
//               />
//             </div>

//             <div className='mb-3'>
//               <label htmlFor=''>Password</label>
//               <input
//                 type='password'
//                 className='form-control'
//                 onChange={(e) => {
//                   setPassword(e.target.value)
//                 }}
//               />
//             </div>

//             <div className='mb-3'>
//               <label htmlFor=''>Address</label>
//               <input
//                 type='text'
//                 className='form-control'
//                 onChange={(e) => {
//                   setAddress(e.target.value)
//                 }}
//               />
//             </div>

//             <div className='mb-3'>
//               <label htmlFor=''>Mobile Number</label>
//               <input
//                 type='tel'
//                 className='form-control'
//                 onChange={(e) => {
//                   setMobileNo(e.target.value)
//                 }}
//               />
//             </div>

//             <div>
//             <label htmlFor=''>Date of joinig</label>
//               <input
//                 type="date"
//                 // value={selectedDate}
//                 onChange={(e) => {
//                   setJoinDate(e.target.value)
//                 }}
//               />
//            </div>

//             <div className='mb-3'>
//               <label htmlFor=''>Gender</label>
//               <input
//                 type='tel'
//                 className='form-control'
//                 onChange={(e) => {
//                   setGender(e.target.value)
//                 }}
//               />
//             </div>


//             <div className='mb-3'>
//               <label htmlFor=''>Confirm Password</label>
//               <input
//                 type='password'
//                 className='form-control'
//                 onChange={(e) => {
//                   setConfirmPassword(e.target.value)
//                 }}
//               />
//             </div>

//             <div className='mb-3'>
//               <div className='mb-3'>
//                 Already got an account? <Link to='/'>Login here</Link>
//               </div>
//               <button onClick={registerTechnician} className='btn btn-success'>
//                 Register
//               </button>
//             </div>
//           </div>
//         </div>
//         <div className='col'></div>
//       </div>
//     </div>
//   )
// }

// export default RegisterTechnician;