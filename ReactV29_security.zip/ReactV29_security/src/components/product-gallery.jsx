// import { useEffect, useState } from 'react'
// import { toast } from 'react-toastify'
// import { getProductList } from '../services/product'
// import { constants } from '../utils/constants'

// function ProductGallery1() {
//   const [products, setProducts] = useState([])

//   useEffect(() => {
//     // get the list of products from server
//     console.log("in component did mount")
//     loadProducts()
//   }, [])

//   const loadProducts = async () => {
//     const response = await getProductList()
//     //if (response['status'] === 'success') {
//       if(true){
//         console.log("in the Product page");
//         console.log(response)
//         setProducts(response.data)
//         console.log("products-------------"+products)

//     } else {
//       toast.error('Error while calling get /product api')
//     }
//   }

//   return (
//     <div>
//       <h1 style={{ textAlign: 'center', margin: 10 }}>Product Gallery</h1>
//       <div className='row' style={{ marginTop: 50 }}>
//         {products.map((product) => {
//           return (
//             <div className='col-md-3'>
//               <div className='card'>
//                 <img
//                   src={constants.serverUrl + '/' + product['image']}
//                   style={{ height: 200 }}
//                   alt=''
//                 />
//                 {/* [{"productId":1,"productName":"washing","productDesc":"string","productMfgDate":"2023-08-22","productExpDate":"2023-08-22","productPrice":200.0} */}
//                 <div className='card-body'>
//                   <h5 className='card-title'>{product['title']}</h5>
//                   <div className='card-text'>
//                     {/* <div>{product['company']}</div>
//                     <div>₹ {product['price']}</div> */}
//                         <div>{product['productId']}</div>
//                         <div>{product['productName']}</div>
//                         <div>{product['productDesc']}</div>
//                         <div>{product['productMfgDate']} </div>
//                         <div>{product['productExpDate']} </div>
//                         <div>{product['productPrice']} </div>
                        
//                   </div>
//                 </div>
//               </div>
//             </div>
//           )
//         })}
//       </div>
//     </div>
//   )
// }

// export default ProductGallery1
