import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { registerUser as registerUserApi } from '../services/user'

function RegisterUser() {
  // const [firstName, setFirstName] = useState('')
  // const [lastName, setLastName] = useState('')
  // const [email, setEmail] = useState('')
  // const [mobile, setMobile] = useState('')
  // const [password, setPassword] = useState('')
  // const [confirmPassword, setConfirmPassword] = useState('')

  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [email, setEmail] = useState('')
  const [address, setAddress] = useState('') 
  const [password, setPassword] = useState('')
  const [joinDate, setJoinDate] = useState('') 
  const [mobileNo, setMobileNo] = useState('')
  const [gender, setGender] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')

  // get the navigation object
  const navigate = useNavigate()

  const registerUser = async () => {
    if (firstName.length == '') {
      toast.error('Please enter first name')
    }
     else if (lastName.length == '') {
      toast.error('Please enter last name')
    } 
    else if (email.length == '') {
      toast.error('Please enter email')
    }  
    else if (password.length == '') {
      toast.error('Please enter password')
    } 
    else if (address.length == '') {
      toast.error('Please enter adress')
    }
    else if (joinDate.length == '') {
      toast.error('Please enter Date Of Birth')
    }
    else if (mobileNo.length == '') {
      toast.error('Please enter mobile No')
    }
    else if (gender.length == '') {
      toast.error('Please enter Gender')
    }
    
    if (password !== confirmPassword) {
      toast.error('Password does not match')
    } else {
      // call register api
      const response = await registerUserApi(
        firstName,
        lastName,
        email,
        password,
        address,
        joinDate,
        mobileNo,
        gender
      )

      // parse the response
      if (response['firstName']) {
        toast.success('Successfully registered a new user')

        // go back to login
        navigate('/')
      } else {
        toast.error('Error while registering a new user, please try again')
      }
    }
  }
  return (
    <div>
      <h1 style={{ textAlign: 'center', margin: 10 }}>Register Technician</h1>

      <div className='row'>
        <div className='col'></div>
        <div className='col'>
          <div className='form'>

            <div className='mb-3'>
              <label htmlFor=''>First Name</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setFirstName(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Last Name</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setLastName(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Email</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setEmail(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Password</label>
              <input
                type='password'
                className='form-control'
                onChange={(e) => {
                  setPassword(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Address</label>
              <input
                type='text'
                className='form-control'
                onChange={(e) => {
                  setAddress(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <label htmlFor=''>Mobile Number</label>
              <input
                type='tel'
                className='form-control'
                onChange={(e) => {
                  setMobileNo(e.target.value)
                }}
              />
            </div>

            <div>
            <label htmlFor=''>Date of joinig</label>
              <input
                type="date"
                // value={selectedDate}
                onChange={(e) => {
                  setJoinDate(e.target.value)
                }}
              />
           </div>

            <div className='mb-3'>
              <label htmlFor=''>Gender</label>
              <input
                type='tel'
                className='form-control'
                onChange={(e) => {
                  setGender(e.target.value)
                }}
              />
            </div>


            <div className='mb-3'>
              <label htmlFor=''>Confirm Password</label>
              <input
                type='password'
                className='form-control'
                onChange={(e) => {
                  setConfirmPassword(e.target.value)
                }}
              />
            </div>

            <div className='mb-3'>
              <div className='mb-3'>
                Already got an account? <Link to='/'>Login here</Link>
              </div>
              <button onClick={registerUser} className='btn btn-success'>
                Register
              </button>
            </div>
          </div>
        </div>
        <div className='col'></div>
      </div>
    </div>
  )
}

export default RegisterUser;