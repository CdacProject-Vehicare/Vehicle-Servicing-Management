// import axios from 'axios'
// import { createUrl, log } from '../utils/utils'



// // POST: technician/signup
// export async function registerTechnician(firstName,lastName,email,password,address,joinDate,mobileNo,gender) 
// {
//   const url = createUrl('/technician/signup/')
//   const body = {firstName,lastName,email,password,address,joinDate,mobileNo,gender}

//   // wait till axios is making the api call and getting response from server
//   try {
//     const response = await axios.post(url, body)
//     log(response.data)
//     return response.data
//   } catch (ex) {
//     log(ex)
//     return null
//   }
// }

// //    POST: technician/signIn
// export async function loginTechnician(email, password) {
//   const url = createUrl('/technician/signIn')
//   const body = {email,password }

//   // wait till axios is making the api call and getting response from server
//   try {
//     const response = await axios.post(url, body)
//     log(response.data)

//     return response
//   } catch (ex) {
//     log(ex)
//     return null
//   }
// }