import axios from 'axios'
import { createUrl, log } from '../utils/utils'

// export async function getOrdersList() {
//  // const url = createUrl('/product')
 
//     const url= createUrl('/orderDetailscontroller/getAllOrderDetails')
//   try {
//     // get the current user's token from session storage
//   //  const { token } = sessionStorage
//     console.log("in OrdersDetails............")
//     // create a header to send the token
//     const header = {
//       headers: {
//         //token,
//       },
//     }

//     // make the api call using the token in the header
//     const response = await axios.get(url, header)
//     log("in log............"+response.data)
//    // return response.data
//        console.log( "in cosnole log------------"+ response)
//       return response;
//   } catch (ex) {
//     log(ex)
//     return null
//   }
// }

export async function GetListOfItemsinCart(customId) {
  
     const url= createUrl('/carts/'+customId)
   try {
         console.log("in getListOfItemsinCart............")    
     const header = {
       headers: {
         //token,
       },
     }

     /////////bearer token//////////////
      
     const config = {
      headers: {
       'authorization' : 'Bearer '+sessionStorage.getItem('token')
      }
    } 

     ///////////////////////////////////////
 
     // make the api call using the token in the header
     const response = await axios.get(url,config)
     log("in log............"+response.data)
    // return response.data
    console.log(response)
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }
 
 export async function AddToCartApi(productId) {
  //var status='COMPLETED'
 // const url= createUrl('/ordercontroller/updateOrderPaymentStatus/'+orderId+'/'+status)
 console.log("in AddToCartApi............")  
 const url= createUrl('/carts')
 try {
      console.log("in AddToCartApi............")    
  const header = {
    headers: {
      //token,
    },
  }

   /////////bearer token//////////////
      
   const config = {
    headers: {
     'authorization' : 'Bearer '+sessionStorage.getItem('token')
    }
  } 

   ///////////////////////////////////////

  var customerId=sessionStorage.getItem('id');
  var qty=1;

  const body = {
    customerId,
    productId,
    qty
  }

  // {
  //   "customerId": 0,
  //   "productId": 0,
  //   "qty": 0
  // }
  // make the api call using the token in the header
  const response = await axios.post(url,body,config)
  log("in log............"+response.data)
 // return response.data
 console.log(response)
     console.log( "in cosnole log------------"+ response)
    return response;
} catch (ex) {
  log(ex)
  return null
}
}

 

// export async function UpdateOrderStatusApi(orderId) {
//   var status='COMPLETED'
//   const url= createUrl('/ordercontroller/updateOrderStatus/'+orderId+'/'+status)
// try {
//       console.log("in UpdateOrderStatus............")    
//   const header = {
//     headers: {
//       //token,
//     },
//   }

//   // make the api call using the token in the header
//   const response = await axios.put(url, header)
//   log("in log............"+response.data)
//  // return response.data
//  console.log(response)
//      console.log( "in cosnole log------------"+ response)
//     return response;
// } catch (ex) {
//   log(ex)
//   return null
// }
// }




