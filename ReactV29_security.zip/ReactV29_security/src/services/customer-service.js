import axios from 'axios'
import { createUrl, log } from '../utils/utils'

export async function registerCustomerApi(
  firstName,
        lastName,
        email,
        password,
        phone,
        address,
        role
) {
  const url = createUrl('/Customer/signup')
  const body = {
    firstName,
    lastName,
    email,
    password,
    phone,
    address,
    role
  }

  // wait till axios is making the api call and getting response from server
  try {
    const response = await axios.post(url, body)
    log(response.data)
    debugger
    return response.data

  } catch (ex) {
    log(ex)
    return null
  }
}




// pending 
export async function loginCustomerApi(email, password) {
  //const url = createUrl('/Customer/signIn')
   const url=createUrl('/auth/customer/signin')
  const body = {
    email,
    password
  }

  // wait till axios is making the api call and getting response from server
  try {
    const response = await axios.post(url, body)
    log(response.data)
    return response
  } catch (ex) {
    log(ex)
    return null
  }
}


// Update Technician Profile
export async function updateCustomer(customerId,
  firstName,
  lastName,
  email,
  password,
  address,

  phone,) 
{
  const url = createUrl('/Customer')
 // var technicianId=sessionStorage.getItem.id;
 console.log("technician Id =" +customerId)
  const body = {customerId,
    firstName,
    lastName,
    email,
    password,
    address,
    phone}
  console.log(body)

  const config = {
    headers: {
     'authorization' : 'Bearer '+sessionStorage.getItem('token')
    }
  } 
  



  // wait till axios is making the api call and getting response from server
  try {
    const response = await axios.put(url,body, config)
    log(response.data)
    return response
  } catch (ex) {
    log(ex)
    return null
  }
}

//GET : Technician Details by Id (Store in Session Storage)
export async function getCustomerById(id) {
  // const url = createUrl('/product')
  
     const url= createUrl('/Customer/'+ id )
   try {
     // get the current user's token from session storage
   //  const { token } = sessionStorage
     console.log("in get customer By Id............")
     // create a header to send the token
     const config = {
       headers: {
        'authorization' : 'Bearer '+sessionStorage.getItem('token')
       },
       body:{
          // 'user':'prateek'
       }
     }
     // make the api call using the token in the header
     const response = await axios.get(url, config)
     log("in log............"+response.data)
    // return response.data
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }


