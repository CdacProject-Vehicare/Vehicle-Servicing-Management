import axios from 'axios'
import { createUrl, log } from '../utils/utils'



// POST : Insert New Service to showroom  (Admin functionality)
export async function insertFeedback(orderId,rating, remarks) {
  
  const url = createUrl('/feedback/'+orderId)
  const body = {orderId,rating, remarks}
  // wait till axios is making the api call and getting response from server

  const config = {
    headers: {
     'authorization' : 'Bearer '+sessionStorage.getItem('token')
    }
  } 

  try {
    const response = await axios.post(url, body,config)
    console.log('')
    log(response.data)
    return response
  } catch (ex) {
    log(ex)
    return null
  }
}

//GET : get All Inventory Details for admin
export async function getAllFeedbackDetails() {

     const url= createUrl('/feedback' )
   try {
     // get the current user's token from session storage
   //  const { token } = sessionStorage
     console.log("in get all feedback-service`............")
     // create a header to send the token
     const header = {
       headers: {
         //token,
       },
     }

     const config = {
      headers: {
       'authorization' : 'Bearer '+sessionStorage.getItem('token')
      }
    } 

     // make the api call using the token in the header
     const response = await axios.get(url,config)
     log("in log............"+response.data)
    // return response.data
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// //GET : Technician Details by Id (Store in Session Storage)
// export async function getTechnicianById(id) {
//   // const url = createUrl('/product')
  
//      const url= createUrl('/technician/'+ id )
//    try {
//      // get the current user's token from session storage
//    //  const { token } = sessionStorage
//      console.log("in get Technician By Id............")
//      // create a header to send the token
//      const header = {
//        headers: {
//          //token,
//        },
//      }
//      // make the api call using the token in the header
//      const response = await axios.get(url, header)
//      log("in log............"+response.data)
//     // return response.data
//         console.log( "in cosnole log------------"+ response)
//        return response;
//    } catch (ex) {
//      log(ex)
//      return null
//    }
//  }

//   // Update Technician Profile
//  export async function updateTechnician(technicianId,firstName,lastName,email,password,address,joinDate,mobileNo,gender) 
// {
//   const url = createUrl('/technician')
//  // var technicianId=sessionStorage.getItem.id;
//  console.log("technician Id =" +technicianId)
//   const body = {technicianId,firstName,lastName,email,password,address,joinDate,mobileNo,gender}
//   console.log(body)
//   // wait till axios is making the api call and getting response from server
//   try {
//     const response = await axios.put(url, body)
//     log(response.data)
//     return response
//   } catch (ex) {
//     log(ex)
//     return null
//   }
// }


// //Delete : deleteTechnician by Id (functionality : Admin )
// export async function removeTechnicianById(id) {
//   // const url = createUrl('/product')
  
//      const url= createUrl('/technician/'+ id )
//    try {
//      // get the current user's token from session storage
//      //  const { token } = sessionStorage
//      console.log("in get Technician By Id............")
//      // create a header to send the token
//      const header = {
//        headers: {
//          //token,
//        },
//      }
//      // make the api call using the token in the header
//      const response = await axios.delete(url, header)
//      log("in log............"+response.data)
//     // return response.data
//         console.log( "in cosnole log------------"+ response)
//        return response;
//    } catch (ex) {
//      log(ex)
//      return null
//    }
//  }



