import axios from 'axios'
import { createUrl, log } from '../utils/utils'

// export async function GetOrderTechnicianList() {
//  // const url = createUrl('/product')
 
//     const url= createUrl('/products/getallProducts')
//   try {
//     // get the current user's token from session storage
//   //  const { token } = sessionStorage
//     console.log("in getProductList............")
//     // create a header to send the token
//     const header = {
//       headers: {
//         //token,
//       },
//     }

//     // make the api call using the token in the header
//     const response = await axios.get(url, header)
//     log("in log............"+response.data)
//    // return response.data
//        console.log( "in cosnole log------------"+ response)
//       return response;
//   } catch (ex) {
//     log(ex)
//     return null
//   }
// }


export async function GetOrderTechnicianDetailsList() {
  // const url = createUrl('/product')
  
     const url= createUrl('/orderTechnicianDetailscontroller')
   try {
     // get the current user's token from session storage
   //  const { token } = sessionStorage
     console.log("in GetOrderTechnicianDetailsList............")
     // create a header to send the token
    //  const header = {
    //    headers: {
    //      //token,
    //    },
    //  }
 
     const config = {
      headers: {
       'authorization' : 'Bearer '+sessionStorage.getItem('token')
      }
    } 

     // make the api call using the token in the header
     const response = await axios.get(url, config)
     log("in log............"+response.data)
    // return response.data
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }


 export async function UpdateWorkLog(text,orderId) {
  // const url = createUrl('/product')
  
     const url= createUrl('/orderTechnicianDetailscontroller/'+orderId)

     const body = {
      text       
    }


   try {
     // get the current user's token from session storage
   //  const { token } = sessionStorage
     console.log("in GetOrderTechnicianDetailsList............")
     // create a header to send the token
     const header = {
       headers: {
         //token,
       },
     }

     const config = {
      headers: {
       'authorization' : 'Bearer '+sessionStorage.getItem('token')
      }
    } 
 
     // make the api call using the token in the header
     const response = await axios.put(url, body,config)
     log("in log............"+response.data)
    // return response.data
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }