import axios from 'axios'
import { createUrl, log } from '../utils/utils'


export async function AssignOrderToTechnicianApi(technicianId,orderId) {
  // const url = createUrl('/product')
   
    const body={technicianId,orderId}
     const url= createUrl('/orderTechnicianDetailscontroller')
   try {
     // get the current user's token from session storage
   //  const { token } = sessionStorage
     console.log("in orderTechnicianDetailscontroller............")
     // create a header to send the token
    //  const header = {
    //    headers: {
    //      //token,
    //    },
    //  }
   
     /////////bearer token//////////////
      
     const config = {
      headers: {
       'authorization' : 'Bearer '+sessionStorage.getItem('token')
      }
    } 

     ///////////////////////////////////////


     const response = await axios.post(url, body,config)
     log("in log............"+response.data)
    // return response.data
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }




export async function getAllOrdersListApi() {
  // const url = createUrl('/product')
  
     const url= createUrl('/ordercontroller')
   try {
     // get the current user's token from session storage
   //  const { token } = sessionStorage
     console.log("in OrdersDetails............")
     // create a header to send the token
     const header = {
       headers: {
         //token,
       },
     }

      /////////bearer token//////////////
      
      const config = {
        headers: {
         'authorization' : 'Bearer '+sessionStorage.getItem('token')
        }
      } 
  
       ///////////////////////////////////////
     const response = await axios.get(url, config)
     log("in log............"+response.data)
    // return response.data
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }


 export async function getOrdersStatusListApi() {
  // const url = createUrl('/product')
  
     const url= createUrl('/ordercontroller/orderstatistics')
   try {
     // get the current user's token from session storage
   //  const { token } = sessionStorage
     console.log("in OrdersStatusDetails............")
     // create a header to send the token

       /////////bearer token//////////////
      
       const config = {
        headers: {
         'authorization' : 'Bearer '+sessionStorage.getItem('token')
        }
      } 
  
       ///////////////////////////////////////
      


     const header = {
       headers: {
         //token,
       },
     }
 
     // make the api call using the token in the header
     const response = await axios.get(url, config)
     log("in log............"+response.data)
    // return response.data
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }

export async function getOrdersList() {
 // const url = createUrl('/product')
 
    const url= createUrl('/orderDetailscontroller/getAllOrderDetails')
  try {
    // get the current user's token from session storage
  //  const { token } = sessionStorage
    console.log("in OrdersDetails............")
    // create a header to send the token
    const header = {
      headers: {
        //token,
      },
    }

     /////////bearer token//////////////
      
     const config = {
      headers: {
       'authorization' : 'Bearer '+sessionStorage.getItem('token')
      }
    } 

     ///////////////////////////////////////


    // make the api call using the token in the header
    const response = await axios.get(url, config)
    log("in log............"+response.data)
   // return response.data
       console.log( "in cosnole log------------"+ response)
      return response;
  } catch (ex) {
    log(ex)
    return null
  }
}


export async function getAllOrdersDetailsListByTechnicianId(id) {
  // const url = createUrl('/product')
     console.log(id)
     const url= createUrl('/technician/AllOrderDetailsTechnician/'+id)
   try {
     // get the current user's token from session storage
   //  const { token } = sessionStorage
     console.log("in OrdersDetails............")
     // create a header to send the token
     const header = {
       headers: {
         //token,
       },
     }
 
      /////////bearer token//////////////
      
      const config = {
        headers: {
         'authorization' : 'Bearer '+sessionStorage.getItem('token')
        }
      } 
  
       ///////////////////////////////////////

     // make the api call using the token in the header
     const response = await axios.get(url, config)
     log("in log............"+response.data)
    // return response.data
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }


export async function getOrdersListByCustomerId(customerid) {
     const url= createUrl('/Customer/customerDashBoard/'+customerid)
   try {
     // get the current user's token from session storage
   //  const { token } = sessionStorage
     console.log("in OrdersDetails............")
     // create a header to send the token
     const header = {
       headers: {
         //token,
       },
     }
 
      /////////bearer token//////////////
      
      const config = {
        headers: {
         'authorization' : 'Bearer '+sessionStorage.getItem('token')
        }
      } 
  
       ///////////////////////////////////////

     // make the api call using the token in the header
     const response = await axios.get(url, config)
     log("in log............"+response.data)
    // return response.data
        console.log( "in cosnole log------------"+ response)
        return response;
       
       
   } catch (ex) {
     log(ex)
     return null
   }
 }


 export async function getOrdersListByTechnicianId(technicianId) {
  // const url = createUrl('/product')
  
     const url= createUrl('/orderTechnicianDetailscontroller/technician/'+technicianId)
   try {
     // get the current user's token from session storage
   //  const { token } = sessionStorage
     console.log("in OrdersDetailsByTechnicianId............")
     // create a header to send the token
     const header = {
       headers: {
         //token,
       },
     }
 
     /////////bearer token//////////////
      
     const config = {
      headers: {
       'authorization' : 'Bearer '+sessionStorage.getItem('token')
      }
    } 

     ///////////////////////////////////////


     // make the api call using the token in the header
     const response = await axios.get(url, config)
     log("in log............"+response.data)
    // return response.data
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }





export async function getOrdersInventoryList(orderId) {
  
     const url= createUrl('/orderInventoryDetailscontroller/'+orderId)
   try {
         console.log("in OrdersInventoryDetails............")    
     const header = {
       headers: {
         //token,
       },
     }
 
      /////////bearer token//////////////
      
      const config = {
        headers: {
         'authorization' : 'Bearer '+sessionStorage.getItem('token')
        }
      } 
  
       ///////////////////////////////////////


     // make the api call using the token in the header
     const response = await axios.get(url, config)
     log("in log............"+response.data)
    // return response.data
    console.log(response)
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }
 
 export async function UpdateOrderPaymentStatusApi(orderId) {
  var status='COMPLETED'
  const url= createUrl('/ordercontroller/updateOrderPaymentStatus/'+orderId+'/'+status)
try {
      console.log("in UpdateOrderStatus............")    
  // const header = {
  //   headers: {
  //     //token,
  //   },
  // }
   
    /////////bearer token//////////////
      
    const config = {
      headers: {
       'authorization' : 'Bearer '+sessionStorage.getItem('token')
      }
    } 

     ///////////////////////////////////////


  // make the api call using the token in the header
  const response = await axios.put(url, config)
  log("in log............"+response.data)
 // return response.data
 console.log(response)
     console.log( "in cosnole log------------"+ response)
    return response;
} catch (ex) {
  log(ex)
  return null
}
}

 

export async function UpdateOrderStatusApi(orderId) {
  var status='COMPLETED'
  const url= createUrl('/ordercontroller/updateOrderStatus/'+orderId+'/'+status)
try {
      console.log("in UpdateOrderStatus............")    
  // const header = {
  //   headers: {
  //     //token,
  //   },
  // }

   /////////bearer token//////////////
      
   const config = {
    headers: {
     'authorization' : 'Bearer '+sessionStorage.getItem('token')
    }
  } 

   ///////////////////////////////////////

  // make the api call using the token in the header
  const response = await axios.put(url, config)
  log("in log............"+response.data)
 // return response.data
 console.log(response)
     console.log( "in cosnole log------------"+ response)
    return response;
} catch (ex) {
  log(ex)
  return null
}
}


export async function PlaceOrderApi(customerId) {
  
 const body= {
    
    customerId
   
  }
console.log(customerId)
 const url= createUrl('/ordercontroller')
try {
      console.log("in PlaceOrderApi............")    
  const header = {
    headers: {
      //token,
    },
  }
  
   /////////bearer token//////////////
      
   const config = {
    headers: {
     'authorization' : 'Bearer '+sessionStorage.getItem('token')
    }
  } 

   ///////////////////////////////////////


  // make the api call using the token in the header
  const response = await axios.post(url, body,config)
  log("in log............"+response.data)
 // return response.data
 console.log(response)
     console.log( "in cosnole log------------"+ response)
    return response;
} catch (ex) {
  log(ex)
  return null
}
}




