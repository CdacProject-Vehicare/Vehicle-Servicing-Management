import axios from 'axios'
import { createUrl, log } from '../utils/utils'

//POST : Insert New Service to showroom  (Admin functionality)
export async function InsertProduct(productName, productDesc,productMfgDate,productExpDate,productPrice) {
  const url = createUrl('/products')
  const body = {productName, productDesc,productMfgDate,productExpDate,productPrice}

  // wait till axios is making the api call and getting response from server

   /////////bearer token//////////////
      
   const config = {
    headers: {
     'authorization' : 'Bearer '+sessionStorage.getItem('token')
    }
  } 

   ///////////////////////////////////////
  try {
    const response = await axios.post(url, body,config)
    log(response.data)

    return response
  } catch (ex) {
    log(ex)
    return null
  }
}

// GET : a get all products (Admin Functionality)
export async function getProductList() {
 // const url = createUrl('/product')
    const url= createUrl('/products/getallProducts')

   /////////bearer token//////////////
      
   const config = {
    headers: {
     'authorization' : 'Bearer '+sessionStorage.getItem('token')
    }
  } 

   ///////////////////////////////////////

  try {
    // get the current user's token from session storage
  //  const { token } = sessionStorage
    console.log("in getProductList............")
    // create a header to send the token
    // const header = {
    //   headers: {
    //     //token,
    //   },
    // }
    // make the api call using the token in the header
    const response = await axios.get(url, config)
    log("in log............"+response.data)
   // return response.data
      console.log( "in cosnole log------------"+ response)
      return response;
  } catch (ex) {
    log(ex)
    return null
  }
}

//GET : Service Details by Id (Store in Session Storage)
export async function getProductById(productId) {
  // const url = createUrl('/product')
    console.log(productId)
     const url= createUrl('/products/'+ productId )
   try {
     // get the current user's token from session storage
   //  const { token } = sessionStorage
     console.log("in get product By Id in services............")
     console.log(productId)
     // create a header to send the token
     const header = {headers: { //token,
                                },
                    }
     // make the api call using the token in the header

     /////////bearer token//////////////
      
     const config = {
      headers: {
       'authorization' : 'Bearer '+sessionStorage.getItem('token')
      }
    } 

     ///////////////////////////////////////

     const response = await axios.get(url, config)
     console.log('in response data')
     console.log(response.data)
     console.log('in response')
     console.log(response.data)
    // return response.data
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }

// Update Service Details
export async function updateProductDetails(productId,productName,productDesc,
                                           productMfgDate,productExpDate,productPrice) 
{
  const url = createUrl('/products/'+ productId)
 // var technicianId=sessionStorage.getItem.id;
 console.log("product Id =" +productId)
  const body = {productId,productName,productDesc,productMfgDate,productExpDate,productPrice}
  console.log(body)
  // wait till axios is making the api call and getting response from server

  /////////bearer token//////////////
      
  const config = {
    headers: {
     'authorization' : 'Bearer '+sessionStorage.getItem('token')
    }
  } 

   ///////////////////////////////////////

  try {
    const response = await axios.put(url, body,config)
    log(response.data)
    return response
  } catch (ex) {
    log(ex)
    return null
  }
}

//Delete : delete Service by Id (functionality : Admin )
export async function removeServiceById(id) {
  // const url = createUrl('/product')
  
     const url= createUrl('/products/'+ id )
   try {
     // get the current user's token from session storage
     //  const { token } = sessionStorage
     console.log("in get Product By Id............")
     // create a header to send the token
     const header = {
       headers: {
         //token,
       },
     }

     /////////bearer token//////////////
      
     const config = {
      headers: {
       'authorization' : 'Bearer '+sessionStorage.getItem('token')
      }
    } 

     ///////////////////////////////////////

     const response = await axios.delete(url, config)
     log("in log............"+response.data)
    // return response.data
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }









// import axios from 'axios'
// import { createUrl, log } from '../utils/utils'

export async function GetProductList() {
 // const url = createUrl('/product')
 
    const url= createUrl('/products/getallProducts')
  try {
    // get the current user's token from session storage
  //  const { token } = sessionStorage
    console.log("in getProductList............")
    // create a header to send the token
    const header = {
      headers: {
        //token,
      },
    }

    /////////bearer token//////////////
      
    const config = {
      headers: {
       'authorization' : 'Bearer '+sessionStorage.getItem('token')
      }
    } 

     ///////////////////////////////////////

    // make the api call using the token in the header
    const response = await axios.get(url, config)
    log("in log............"+response.data)
   // return response.data
       console.log( "in cosnole log------------"+ response)
      return response;
  } catch (ex) {
    log(ex)
    return null
  }
}
