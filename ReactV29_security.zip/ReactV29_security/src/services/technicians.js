import axios from 'axios'
import { createUrl, log } from '../utils/utils'

export async function GetTechnicianListApi() {
 // const url = createUrl('/product')
 
    const url= createUrl('/technician')
  try {
    // get the current user's token from session storage
  //  const { token } = sessionStorage
    console.log("in technician............")
    // create a header to send the token

    const config = {
      headers: {
       'authorization' : 'Bearer '+sessionStorage.getItem('token')
      }
    } 
    // const header = {
    //   headers: {
    //     //token,
    //   },
    // }

    // make the api call using the token in the header
    const response = await axios.get(url,config)
    log("in log............"+response.data)
   // return response.data
       console.log( "in cosnole log------------"+ response)
      return response;
  } catch (ex) {
    log(ex)
    return null
  }
}
