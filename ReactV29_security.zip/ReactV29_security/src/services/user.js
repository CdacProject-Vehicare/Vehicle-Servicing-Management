import axios from 'axios'
import { createUrl, log } from '../utils/utils'

// POST: technician/signup
export async function registerTechnician(firstName,lastName,email,password,address,joinDate,mobileNo,gender) 
{
  const url = createUrl('/technician/signup/')
  const body = {firstName,lastName,email,password,address,joinDate,mobileNo,gender}

  // wait till axios is making the api call and getting response from server
  try {
    const response = await axios.post(url, body)
    log(response.data)
    return response.data
  } catch (ex) {
    log(ex)
    return null
  }
}

//    POST: technician/signIn
export async function loginTechnician(email, password) {
 // const url = createUrl('/technician/signIn')
 const url = createUrl('/auth/tehcnician/signin')
  
 const body = {email,password }

  // wait till axios is making the api call and getting response from server
  try {
    const response = await axios.post(url, body)
    log(response.data)

    return response
  } catch (ex) {
    log(ex)
    return null
  }
}

//GET : get All Technician Details for admin
export async function getAllTechnicianDetails() {
  // const url = createUrl('/product')
  
     const url= createUrl('/technician' )
   try {
     // get the current user's token from session storage
   //  const { token } = sessionStorage
     console.log("in get all Technician detailsx`............")
     // create a header to send the token
     const header = {
       headers: {
         //token,
       },
     }
     // make the api call using the token in the header
     const response = await axios.get(url, header)
     log("in log............"+response.data)
    // return response.data
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }



//GET : Technician Details by Id (Store in Session Storage)
export async function getTechnicianById(id) {
  // const url = createUrl('/product')
  
     const url= createUrl('/technician/'+ id )
   try {
     // get the current user's token from session storage
   //  const { token } = sessionStorage
     console.log("in get Technician By Id............")
     // create a header to send the token
     const header = {
       headers: {
         //token,
       },
     }
     // make the api call using the token in the header
     const response = await axios.get(url, header)
     log("in log............"+response.data)
    // return response.data
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }

  // Update Technician Profile
 export async function updateTechnician(technicianId,firstName,lastName,email,password,address,joinDate,mobileNo,gender,salary) 
{
  const url = createUrl('/technician')
 // var technicianId=sessionStorage.getItem.id;
 console.log("technician Id =" +technicianId)
  const body = {technicianId,firstName,lastName,email,password,address,joinDate,mobileNo,gender,salary}
  console.log(body)
  // wait till axios is making the api call and getting response from server
  try {
    const response = await axios.put(url, body)
    log(response.data)
    return response
  } catch (ex) {
    log(ex)
    return null
  }
}

export async function removeTechnicianById(id) {
  // const url = createUrl('/product')
  
     const url= createUrl('/technician/'+ id )
   try {
     // get the current user's token from session storage
     //  const { token } = sessionStorage
     console.log("in get Technician By Id............")
     // create a header to send the token
     const header = {
       headers: {
         //token,
       },
     }
     // make the api call using the token in the header
     const response = await axios.delete(url, header)
     log("in log............"+response.data)
    // return response.data
        console.log( "in cosnole log------------"+ response)
       return response;
   } catch (ex) {
     log(ex)
     return null
   }
 }



