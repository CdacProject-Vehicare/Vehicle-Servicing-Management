export const constants = {
 // serverUrl: 'http://192.168.1.13:9999'
  serverUrl: 'http://localhost:9998'
}
